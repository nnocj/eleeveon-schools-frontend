"use client";
import {createPortal} from "react-dom";

/**
 * app/branch-admin/modules/Branchsettings.tsx
 * ---------------------------------------------------------
 * BRANCH ADMIN — BRANCH SETTINGS
 * ---------------------------------------------------------
 *
 * Built from the old schoolBranchSettings.tsx functionality.
 *
 * Same functional areas:
 * - school identity
 * - branch identity
 * - academic defaults
 * - current academic structure
 * - current academic period
 * - theme / color / font
 * - dashboard images
 * - portal images
 * - report card branding
 * - record-based gallery highlights using the Portal Highlights architecture
 * - report card templates and display controls
 *
 * Branch-admin difference:
 * - No school switching.
 * - No branch switching.
 * - Everything is locked to the assigned active school + branch.
 *
 * UI difference:
 * - Students.tsx golden compact layout
 * - no hero, summary strip, or dashboard cards
 * - Save + Filter + More top row
 * - settings grouped into compact bottom sheets
 *
 * Workspace + media upgrade:
 * - reads eleeveon_open_workspace from /select-role first, then active membership,
 *   then ActiveBranchContext/settings so branch settings cannot use stale role context
 * - image uploads now use mediaAssets/mediaBlobs through saveImageAsset(...)
 * - school/branch/settings records keep only small media IDs and safe fallback strings
 * - unsaved branch-settings uploads use ownerTempKey and are attached after save
 * - old Base64 fields are preserved only as fallback display values, not new storage
 *
 * Sync utility alignment:
 * - create/update actions now use createLocal(...) and updateLocal(...)
 * - active lookup tables use listActiveLocal(...) where appropriate
 * - softDeleteLocal is imported with the standard local-first CRUD toolkit, although
 *   this settings module has no delete action in the current UI
 *
 * LocalSettings theme alignment:
 * - light mode now applies the exact same old Eleeveon CSS variable values as
 *   app/components/role-portals/LocalSettings.tsx
 * - dark mode now also applies the complete variable set used by LocalSettings
 * - keeps branch settings as the protected source for branch color/font/theme while
 *   rendering with the same light/dark surface, input, card and shell tokens
 *
 * Theme + primary-colour atomic save fix:
 * - opening the Branch Settings tab is passive and never changes the active app theme
 * - Save, Save All, sheet saves and the More modal never mutate document theme variables
 * - schoolBranchSettings commits go through SettingsContext.updateSettings(...)
 * - unrelated section saves preserve the committed primary colour/theme/typography
 * - only Appearance and Save All may publish edited appearance values
 * - the old post-save refresh race can no longer replace the primary colour with a fallback
 * - successful settings commits still publish schoolBranchSettings through syncEvents
 * - global theme application remains outside this page
 *
 * Media removal fix:
 * - clicking Remove clears the preview, fallback string field and saved mediaId field immediately
 * - removals are tracked by owner identity, not only by mediaId
 * - Save soft-deletes every active mediaAsset for ownerTable + ownerId + fieldKey
 * - this handles records resolved through getOwnerFieldMediaAsset(...) even when the form has no mediaId
 * - owner records are saved with empty string fallbacks and null media IDs so old links cannot survive merge updates
 * - removed mediaAssets and their mediaBlobs are soft-deleted locally and marked pending sync
 * - Save All performs all writes first, then reloads once so removed images cannot rehydrate mid-save
 * - gallery items use portalHighlights records with placement='gallery'
 * - Portal Highlights and Gallery items can opt into source-driven website publishing
 * - MediaSheet, SchoolSheet and BranchSheet receive clearImage as props so remove actions are in scope
 *
 * Report card template/settings upgrade:
 * - keeps all existing branch settings exactly as they are
 * - adds a dedicated Report Card Template & Display Controls section
 * - reads/writes reportCardTemplates, reportCardTemplateSettings and
 *   reportCardTemplateAssignments as local-first Dexie/sync records
 * - supports show/hide controls without leaving blank table/report areas
 * - stores template assignment separately from branding media so more templates
 *   can be added later without rewriting schoolBranchSettings
 */

import React, { useEffect, useMemo, useRef, useState } from "react";

import { useAccount } from "../../context/account-context";
import { useSettings } from "../../context/settings-context";
import { useActiveBranch } from "../../context/active-branch-context";
import { useActiveMembership } from "../../context/active-membership-context";

import {
  db,
  AcademicPeriod,
  AcademicStructure,
  Branch,
  School,
  SchoolBranchSetting,
} from "../../lib/db/db";

import {
  commitMediaAssetsToOwner,
  createMediaSessionKey as createSharedMediaSessionKey,
  MediaFieldKeys,
  MediaOwners,
  resolveOwnerMediaUrl,
  revokeMediaObjectUrl,
  saveImageAsset,
  savePortalHighlightMedia,
  savePortalHighlightPoster,
  commitPortalHighlightMedia,
  softDeletePortalHighlightMedia,
} from "../../lib/media/mediaAssetUtils";

import {
  resolveMediaAssetUrlById,
  revokeResolvedMediaUrl,
} from "../../lib/media/mediaAssetResolver";

import {
  createLocal,
  updateLocal,
  softDeleteLocal,
  listActiveLocal,
} from "../../lib/sync/syncUtils";

import { publishBranchSettingsSaved } from "../../lib/sync/syncEvents";

import {
  STUDENT_REPORT_TEMPLATE_REGISTRY,
  getStudentReportTemplateRegistryItem,
} from "./reports/student-report-templates";

import {
  CUMULATIVE_TRANSCRIPT_TEMPLATE_REGISTRY,
  getCumulativeTranscriptTemplateRegistryItem,
} from "./reports/cumulative-transcript-templates";

import {
  BROADSHEET_TEMPLATE_REGISTRY,
  getBroadsheetTemplateRegistryItem,
} from "./reports/broadsheet-templates";

import StudentReportCard from "./reports/components/StudentReportCard";
import CumulativeReportBook from "./reports/components/CumulativeReportBook";
import CumulativeTranscriptCard from "./reports/components/CumulativeTranscriptCard";
import BroadsheetCard from "./reports/components/BroadsheetCard";
import CredentialDesignSettings from "./identity/CredentialDesignSettings";
import IdentityIssuanceSettings from "./identity/IdentityIssuanceSettings";
import WebsiteSettingsSheet from "../../lib/websites/builder/settings/WebsiteSettingsSheet";

import { useDataRevision } from "../../hooks/useDataRevision";
import { useBackgroundLoader } from "../../hooks/useBackgroundLoader";
import { useBranchWorkspaceScope } from "../../hooks/useBranchWorkspaceScope";
import { useRegisterBranchWorkspaceToolbar } from "../../components/role-portals/shell/BranchWorkspaceToolbar";
import { printBranchTable } from "../../components/role-portals/shell/BranchTablePrint";


/** Render all sheets, editors and previews above the portal chrome. */
const eleeveonFullscreenOverlayCss = String.raw`
.eleeveon-modal-root{position:fixed;inset:0;z-index:2147483000;pointer-events:none;isolation:isolate}
.eleeveon-modal-root>.ba-sheet-backdrop,
.eleeveon-modal-root>.ba-modal-backdrop,
.eleeveon-modal-root>.cs-overlay {
 position:fixed!important;inset:0!important;top:0!important;left:0!important;right:0!important;bottom:0!important;
 width:100vw!important;height:100dvh!important;min-width:0!important;max-width:none!important;max-height:none!important;
 margin:0!important;padding:max(10px,env(safe-area-inset-top)) max(10px,env(safe-area-inset-right)) max(10px,env(safe-area-inset-bottom)) max(10px,env(safe-area-inset-left))!important;
 box-sizing:border-box!important;z-index:1!important;pointer-events:auto!important;
 display:flex!important;align-items:center!important;justify-content:center!important;overflow:hidden!important;
 background:rgba(10,18,32,.66)!important;backdrop-filter:blur(8px)!important;-webkit-backdrop-filter:blur(8px)!important;
}
.eleeveon-modal-root>.ba-sheet-backdrop>.ba-sheet,
.eleeveon-modal-root>.ba-modal-backdrop>.ba-modal,
.eleeveon-modal-root>.ba-modal-backdrop>.ba-camera-modal,
.eleeveon-modal-root>.cs-overlay>.cs-modal,
.eleeveon-modal-root>.cs-overlay>.cs-sheet {
 position:relative!important;z-index:2!important;display:block!important;box-sizing:border-box!important;
 top:auto!important;left:auto!important;right:auto!important;bottom:auto!important;margin:0!important;
 width:min(1100px,100%)!important;max-width:100%!important;min-width:0!important;
 height:auto!important;max-height:calc(100dvh - 24px)!important;min-height:0!important;
 overflow-x:hidden!important;overflow-y:auto!important;overscroll-behavior:contain!important;
 border-radius:18px!important;border:1px solid var(--border,rgba(148,163,184,.24))!important;
 color:var(--text,#111827)!important;background:var(--card-bg,var(--surface,#fff))!important;
 box-shadow:0 24px 75px rgba(0,0,0,.34)!important;scrollbar-width:thin;
}
.eleeveon-modal-root>.ba-sheet-backdrop>.ba-sheet.small,
.eleeveon-modal-root>.ba-sheet-backdrop>.ba-sheet.compact,
.eleeveon-modal-root>.cs-overlay>.cs-sheet {width:min(680px,100%)!important}
.eleeveon-modal-root :is(.ba-sheet-head,.ba-modal-head,.cs-sheet-head){
 position:sticky!important;top:0!important;z-index:9!important;flex-shrink:0!important;
 padding-top:9px!important;padding-bottom:11px!important;
 background:var(--card-bg,var(--surface,#fff))!important;
 border-bottom:1px solid var(--border,rgba(148,163,184,.18))!important;
}
.eleeveon-modal-root :is(.ba-sheet-actions,.ba-modal-actions,.ba-sheet-footer,.cs-sheet-actions,.cs-modal-actions){
 position:sticky!important;bottom:0!important;z-index:9!important;
 padding:12px 4px max(10px,env(safe-area-inset-bottom))!important;
 margin-top:16px!important;background:var(--card-bg,var(--surface,#fff))!important;
 border-top:1px solid var(--border,rgba(148,163,184,.18))!important;
}
/* Shared footer actions: explicit layout and contrast in all branch-settings sheets. */
.eleeveon-modal-root :is(.ba-sheet-footer,.ba-sheet-actions,.ba-modal-actions,.cs-sheet-actions,.cs-modal-actions){
 display:flex!important;flex-direction:row!important;flex-wrap:wrap!important;
 align-items:center!important;justify-content:flex-end!important;gap:12px!important;
 width:100%!important;box-sizing:border-box!important;
}
.eleeveon-modal-root :is(.ba-sheet-footer,.ba-sheet-actions,.ba-modal-actions,.cs-sheet-actions,.cs-modal-actions)>button{
 appearance:none!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;
 min-width:112px!important;min-height:44px!important;padding:10px 18px!important;
 border:1px solid var(--border,#94a3b8)!important;border-radius:11px!important;
 background:var(--input-bg,var(--card-bg,var(--surface,#fff)))!important;color:var(--text,#111827)!important;
 font-size:13px!important;font-weight:800!important;line-height:1.25!important;
 cursor:pointer!important;white-space:nowrap!important;
}
.eleeveon-modal-root :is(.ba-sheet-footer,.ba-sheet-actions,.ba-modal-actions,.cs-sheet-actions,.cs-modal-actions)>button.primary{
 background:var(--ba-primary,var(--primary-color,#2563eb))!important;
 border-color:var(--ba-primary,var(--primary-color,#2563eb))!important;
 color:#fff!important;
}
.eleeveon-modal-root :is(.ba-sheet-footer,.ba-sheet-actions,.ba-modal-actions,.cs-sheet-actions,.cs-modal-actions)>button:disabled{
 opacity:.55!important;cursor:not-allowed!important;
}
.eleeveon-modal-root .ba-sheet-head>button{
 background:var(--card-bg,var(--surface,#fff))!important;
 color:var(--text,#111827)!important;
 border:1px solid var(--border,#94a3b8)!important;
}
.eleeveon-modal-root .admission-sequence-note{
 display:grid;gap:6px;padding:13px 14px;border-radius:12px;
 border:1px solid var(--border,#94a3b8);
 background:var(--card-bg,var(--surface,#fff));color:var(--text,#111827);
}
.eleeveon-modal-root .admission-sequence-note strong{font-size:13px;line-height:1.4}
.eleeveon-modal-root .admission-sequence-note span,
.eleeveon-modal-root .admission-sequence-caption{font-size:12px;line-height:1.5;color:var(--muted,#64748b)}
.eleeveon-modal-root :is(.ba-sheet,.ba-modal,.cs-modal,.cs-sheet) :is(input,select,textarea,button){max-width:100%}
.eleeveon-modal-root :is(.ba-sheet,.ba-modal,.cs-modal,.cs-sheet){font-family:var(--font-family,system-ui,sans-serif);font-size:13px}
.eleeveon-modal-root :is(.ba-sheet,.ba-modal,.cs-modal,.cs-sheet) :is(input:not([type="checkbox"]):not([type="radio"]):not([type="file"]),select,textarea){
 box-sizing:border-box;min-height:41px;max-width:100%;padding:9px 11px;border-radius:10px;
 color:var(--text,#111827);background:var(--input-bg,var(--surface,#fff));
 border:1px solid var(--input-border,var(--border,rgba(148,163,184,.3)));font:inherit;
}
.eleeveon-modal-root :is(.ba-sheet,.ba-modal,.cs-modal,.cs-sheet) :is(textarea){min-height:90px;resize:vertical}
.eleeveon-modal-root :is(.ba-sheet,.ba-modal,.cs-modal,.cs-sheet) :is(input[type="file"]){width:100%;padding:9px}
.eleeveon-modal-root :is(.ba-sheet,.ba-modal,.cs-modal,.cs-sheet) :is(button){cursor:pointer}
.eleeveon-modal-root :is(.ba-sheet,.ba-modal,.cs-modal,.cs-sheet) :is(button,input,select,textarea):focus-visible{outline:2px solid var(--ba-primary,var(--primary-color,#2563eb));outline-offset:2px}
.eleeveon-modal-root :is(.ba-modal-head,.ba-sheet-head,.cs-sheet-head) button {flex-shrink:0;min-width:36px;min-height:36px}
.eleeveon-modal-root .cs-overlay>.cs-backdrop {position:absolute!important;inset:0!important;z-index:0!important;background:transparent!important}
.eleeveon-modal-root>.cs-menu-overlay>.cs-menu{
 position:relative!important;z-index:2!important;inset:auto!important;top:auto!important;left:auto!important;right:auto!important;
 transform:none!important;display:grid!important;gap:5px!important;box-sizing:border-box!important;
 width:min(460px,100%)!important;max-width:100%!important;max-height:calc(100dvh - 24px)!important;overflow-y:auto!important;
 padding:14px!important;border-radius:18px!important;background:var(--card-bg,var(--surface,#fff))!important;
 box-shadow:0 24px 75px rgba(0,0,0,.34)!important;
}
@media(max-width:640px){
 .eleeveon-modal-root>.ba-sheet-backdrop,.eleeveon-modal-root>.ba-modal-backdrop,.eleeveon-modal-root>.cs-overlay{padding:0!important}
 .eleeveon-modal-root>.ba-sheet-backdrop>.ba-sheet,
 .eleeveon-modal-root>.ba-modal-backdrop>.ba-modal,
 .eleeveon-modal-root>.ba-modal-backdrop>.ba-camera-modal,
 .eleeveon-modal-root>.cs-overlay>.cs-modal,
 .eleeveon-modal-root>.cs-overlay>.cs-sheet{
  width:100vw!important;height:100dvh!important;max-height:100dvh!important;max-width:100vw!important;
  padding:12px!important;border-radius:0!important;
 }
 .eleeveon-modal-root>.cs-menu-overlay>.cs-menu{width:calc(100vw - 20px)!important}
 .eleeveon-modal-root :is(.ba-sheet-actions,.ba-modal-actions,.ba-sheet-footer,.cs-sheet-actions,.cs-modal-actions){
  display:flex!important;flex-wrap:wrap!important;justify-content:flex-end!important;gap:8px!important
 }
 .eleeveon-modal-root :is(.ba-sheet-actions,.ba-modal-actions,.ba-sheet-footer,.cs-sheet-actions,.cs-modal-actions)>button{flex:1 1 125px;min-height:42px}
}
`;
function EleeveonFullscreenOverlay({children}:{children:React.ReactNode}){
 const [target,setTarget]=React.useState<HTMLElement|null>(null);
 const [theme,setTheme]=React.useState<React.CSSProperties>({});
 React.useEffect(()=>{
  const page=document.querySelector<HTMLElement>(".role-shell .app-content .ba-page, .role-shell .app-content .cs-page, .role-shell .app-content .subject-setup-root, .ba-page, .cs-page");
  if(page){const cs=window.getComputedStyle(page);const vars:Record<string,string>={};
   for(const key of ["--ba-primary","--cs-primary","--cs-surface","--cs-text","--cs-border"]){const v=cs.getPropertyValue(key).trim();if(v)vars[key]=v;}
   setTheme(vars as React.CSSProperties);
  }
  setTarget(document.body);
  const previous=document.body.style.overflow;document.body.style.overflow="hidden";
  return()=>{document.body.style.overflow=previous;};
 },[]);
 return target?createPortal(<div className="eleeveon-modal-root" style={theme}><style>{eleeveonFullscreenOverlayCss}</style>{children}</div>,target):null;
}

const TemplatePreviewStudentReportCard =
  StudentReportCard as React.ComponentType<any>;
const TemplatePreviewCumulativeReportBook =
  CumulativeReportBook as React.ComponentType<any>;
const TemplatePreviewCumulativeTranscriptCard =
  CumulativeTranscriptCard as React.ComponentType<any>;
const TemplatePreviewBroadsheetCard =
  BroadsheetCard as React.ComponentType<any>;

// ======================================================
// COLOR UTILITIES
// ======================================================

function getContrastTextColor(hex: string) {
  let col = (hex || "#ffffff").replace("#", "");

  if (col.startsWith("rgb")) return "#fff";

  if (col.length === 3) {
    col = col
      .split("")
      .map((c) => c + c)
      .join("");
  }

  const num = parseInt(col, 16);

  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;

  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  return brightness > 140 ? "#111" : "#fff";
}

// ======================================================
// OPTIONS + TYPES
// ======================================================

const fontOptions = [
  { label: "System Default", value: "system-ui, -apple-system, sans-serif" },
  { label: "Arial", value: "Arial, sans-serif" },
  { label: "Helvetica", value: "Helvetica, sans-serif" },
  { label: "Verdana", value: "Verdana, sans-serif" },
  { label: "Tahoma", value: "Tahoma, sans-serif" },
  { label: "Trebuchet MS", value: "'Trebuchet MS', sans-serif" },
  { label: "Segoe UI", value: "'Segoe UI', sans-serif" },
  { label: "Roboto", value: "Roboto, sans-serif" },
  { label: "Poppins", value: "Poppins, sans-serif" },
  { label: "Inter", value: "Inter, sans-serif" },
  { label: "Montserrat", value: "Montserrat, sans-serif" },
  { label: "Open Sans", value: "'Open Sans', sans-serif" },
  { label: "Lato", value: "Lato, sans-serif" },
  { label: "Nunito", value: "Nunito, sans-serif" },
  { label: "Ubuntu", value: "Ubuntu, sans-serif" },
  { label: "Merriweather", value: "Merriweather, serif" },
  { label: "Georgia", value: "Georgia, serif" },
  { label: "Times New Roman", value: "'Times New Roman', serif" },
  { label: "Garamond", value: "Garamond, serif" },
  { label: "Palatino", value: "'Palatino Linotype', serif" },
  { label: "Courier New", value: "'Courier New', monospace" },
  { label: "Consolas", value: "Consolas, monospace" },
  { label: "Monaco", value: "Monaco, monospace" },
];

const generatedDateLabelOptions = [
  "Generated",
  "Report Generated",
  "Date Generated",
  "Printed On",
  "Report Issued",
];

type ToastTone = "success" | "error" | "info";
type SettingsDisplayMode = "cards" | "table";
type ReportTemplateReportType =
  | "student_report"
  | "cumulative_book"
  | "cumulative_transcript"
  | "subject_broadsheet"
  | "class_broadsheet"
  | "annual_broadsheet";
type SettingsSection =
  | "admissionNumbers"
  | "academic"
  | "school"
  | "branch"
  | "appearance"
  | "dashboardMedia"
  | "portalHighlights"
  | "reportMedia"
  | "reportTemplates"
  | "idCards"
  | "website"
  | "gallery";

type ImageField =
  | "logo"
  | "reportCardBackgroundImage"
  | "reportCardWatermark"
  | "reportCardSignatureImage"
  | "dashboardHeroImage"
  | "dashboardBannerImage"
  | "studentPortalImage"
  | "teacherPortalImage"
  | "classroomPlaceholderImage"
  | "subjectPlaceholderImage";

type SettingsForm = {
  id?: string;
  schoolId?: string;
  branchId?: string;
  mode: string;
  fontFamily: string;
  fontSize: number;
  primaryColor: string;
  theme: "light" | "dark";
  currentTerm: string;
  academicYear: string;
  currentAcademicStructureId?: string;
  currentAcademicPeriodId?: string;
  logo: string;
  logoMediaId?: string;
  reportCardBackgroundImage: string;
  reportCardBackgroundImageMediaId?: string;
  reportCardWatermark: string;
  reportCardWatermarkMediaId?: string;
  reportCardSignatureImage: string;
  reportCardSignatureImageMediaId?: string;
  dashboardHeroImage: string;
  dashboardHeroImageMediaId?: string;
  dashboardBannerImage: string;
  dashboardBannerImageMediaId?: string;
  studentPortalImage: string;
  studentPortalImageMediaId?: string;
  teacherPortalImage: string;
  teacherPortalImageMediaId?: string;
  classroomPlaceholderImage: string;
  classroomPlaceholderImageMediaId?: string;
  subjectPlaceholderImage: string;
  subjectPlaceholderImageMediaId?: string;
};

type PortalAudience =
  | "all"
  | "branch_admin"
  | "admin"
  | "teacher"
  | "student"
  | "parent"
  | "accountant";

type PortalHighlightRow = {
  id?: string;
  accountId?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  title: string;
  subtitle?: string | null;
  description?: string | null;
  mediaType: "image" | "video";
  placement: "hero" | "gallery";
  mediaAssetId?: string | null;
  posterMediaAssetId?: string | null;
  fallbackImageUrl?: string | null;
  audiences: PortalAudience[];
  actionType: "none" | "portal_route" | "external_url" | "announcement" | "calendar_event";
  actionLabel?: string | null;
  actionValue?: string | null;
  displayOrder?: number;
  startAt?: number | null;
  endAt?: number | null;
  durationSeconds?: number | null;
  autoplay?: boolean;
  loop?: boolean;
  muted?: boolean;
  transition?: "fade" | "slide" | "crossfade";
  status?: "draft" | "scheduled" | "published" | "expired" | "archived";
  publishedAt?: number | null;
  active?: boolean;
  isDeleted?: boolean;

  publishToWebsite?: boolean;
  websitePublicationStatus?: "draft" | "scheduled" | "published" | "hidden" | "archived";
  websiteFeatured?: boolean;
  websiteDisplayOrder?: number;
  websiteStartAt?: number | null;
  websiteEndAt?: number | null;
  websitePublishedAt?: number | null;

  metadata?: Record<string, unknown> | null;
  _mediaUrl?: string;
  _posterUrl?: string;
};

type PortalHighlightDraft = {
  id?: string;
  ownerTempKey: string;
  title: string;
  subtitle: string;
  description: string;
  mediaType: "image" | "video";
  placement: "hero" | "gallery";
  mediaAssetId: string;
  mediaUrl: string;
  posterMediaAssetId: string;
  posterUrl: string;
  audiences: PortalAudience[];
  actionType: PortalHighlightRow["actionType"];
  actionLabel: string;
  actionValue: string;
  displayOrder: number;
  startAtInput: string;
  endAtInput: string;
  durationSeconds: number;
  autoplay: boolean;
  loop: boolean;
  muted: boolean;
  transition: "fade" | "slide" | "crossfade";
  status: "draft" | "scheduled" | "published";
  active: boolean;

  publishToWebsite: boolean;
  websiteFeatured: boolean;
};

function newPortalHighlightDraft(): PortalHighlightDraft {
  return {
    ownerTempKey: createSharedMediaSessionKey(MediaOwners.PORTAL_HIGHLIGHTS),
    title: "",
    subtitle: "",
    description: "",
    mediaType: "image",
    placement: "hero",
    mediaAssetId: "",
    mediaUrl: "",
    posterMediaAssetId: "",
    posterUrl: "",
    audiences: ["all"],
    actionType: "none",
    actionLabel: "",
    actionValue: "",
    displayOrder: 0,
    startAtInput: "",
    endAtInput: "",
    durationSeconds: 7,
    autoplay: true,
    loop: false,
    muted: true,
    transition: "fade",
    status: "published",
    active: true,

    publishToWebsite: false,
    websiteFeatured: false,
  };
}

type TenantRow = {
  accountId?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  isDeleted?: boolean;
};

type SchoolForm = {
  id?: string;
  name?: string;
  motto?: string;
  logo?: string;
  logoMediaId?: string;
  address?: string;
  location?: string;
  email?: string;
  phone?: string;
  website?: string;
  galleryImages?: string[];
  bannerImage?: string;
  bannerImageMediaId?: string;
  active?: boolean;
};

type BranchForm = {
  id?: string;
  schoolId?: string;
  name?: string;
  code?: string;
  address?: string;
  location?: string;
  city?: string;
  email?: string;
  phone?: string;
  website?: string;
  logo?: string;
  logoMediaId?: string;
  bannerImage?: string;
  bannerImageMediaId?: string;
  active?: boolean;
};

type ReportTemplateForm = {
  templateId?: string;
  templateSettingsId?: string;
  assignmentId?: string;

  reportType: ReportTemplateReportType;

  templateName: string;
  templateCode: string;
  layoutKey: string;
  orientation: "portrait" | "landscape";
  paperSize: "A4" | "Letter";
  density: "compact" | "comfortable" | "spacious";

  showSubjectPosition: boolean;
  showClassPosition: boolean;
  showNumberOnRoll: boolean;
  showAttendance: boolean;
  showAttendancePercent: boolean;
  showStudentPhoto: boolean;
  showTeacherNames: boolean;
  showCurrentAcademicPeriodEnd: boolean;
  showNextAcademicPeriod: boolean;
  showPromotionStatus: boolean;
  showGPA: boolean;
  showAverage: boolean;
  showTotal: boolean;
  showGrade: boolean;
  showSubjectRemarks: boolean;
  showWatermark: boolean;
  showParentSignature: boolean;
  showGeneratedDate: boolean;

  showAssessmentBreakdown: boolean;
  assessmentHierarchyDisplay:
    | "item_rules"
    | "parents_only"
    | "children_only"
    | "parents_and_children"
    | "compact";
  showAssessmentParentItems: boolean;
  showAssessmentChildItems: boolean;
  showCalculatedAssessmentItems: boolean;
  indentAssessmentChildren: boolean;
  showAssessmentGroupHeaders: boolean;
  flattenSingleChildAssessmentGroups: boolean;
  assessmentMaximumVisibleDepth: number | null;
  showAssessmentMaximumScores: boolean;
  showAssessmentWeights: boolean;
  showAssessmentRawScores: boolean;
  showAssessmentWeightedScores: boolean;
  showAssessmentHierarchyPath: boolean;

  broadsheetAssessmentHierarchyDisplay:
    | "item_rules"
    | "parents_only"
    | "children_only"
    | "parents_and_children"
    | "compact";
  broadsheetShowAssessmentGroupHeaders: boolean;
  broadsheetMaximumAssessmentDepth: number | null;

  showBookFrontCover: boolean;
  showBookStudentProfilePage: boolean;
  showBookAcademicJourneyPage: boolean;
  showBookSummaryPage: boolean;
  showBookBackCover: boolean;

  showTranscriptTermBreakdown: boolean;
  showTranscriptYearAverage: boolean;
  showTranscriptCumulativeAverage: boolean;
  showTranscriptCumulativePosition: boolean;
  showTranscriptGPAProgression: boolean;
  showTranscriptFinalRecommendation: boolean;

  showBroadsheetLogo: boolean;
  showBroadsheetWatermark: boolean;
  showBroadsheetGeneratedDate: boolean;
  showBroadsheetPageNumber: boolean;
  showBroadsheetSignatures: boolean;
  showBroadsheetSummary: boolean;
  showBroadsheetStatistics: boolean;
  showBroadsheetStudentPhoto: boolean;
  showBroadsheetAssessmentBreakdown: boolean;
  showBroadsheetWeightedTotal: boolean;
  showBroadsheetPercentage: boolean;
  showBroadsheetGrade: boolean;
  showBroadsheetRemark: boolean;
  showBroadsheetGPA: boolean;
  showBroadsheetPosition: boolean;
  showBroadsheetHighestScore: boolean;
  showBroadsheetLowestScore: boolean;
  showBroadsheetClassAverage: boolean;
  showBroadsheetSubjectScores: boolean;
  showBroadsheetSubjectGrades: boolean;
  showBroadsheetTotal: boolean;
  showBroadsheetAverage: boolean;
  showBroadsheetClassPosition: boolean;
  showBroadsheetAttendance: boolean;
  showBroadsheetClassHighestAverage: boolean;
  showBroadsheetClassLowestAverage: boolean;
  showBroadsheetPeriodScores: boolean;
  showBroadsheetAnnualAverage: boolean;
  showBroadsheetAnnualGPA: boolean;
  showBroadsheetAnnualPosition: boolean;
  showBroadsheetTrend: boolean;
  showBroadsheetPromotionDecision: boolean;
  showBroadsheetBestPeriod: boolean;
  showBroadsheetLatestPeriod: boolean;

  classTeacherLabel: string;
  headTeacherLabel: string;
  parentLabel: string;
  principalLabel: string;
  currentAcademicPeriodEndLabel: string;
  nextAcademicPeriodLabel: string;
  numberOnRollLabel: string;
  classPositionLabel: string;
  subjectPositionLabel: string;
  generatedDateLabel: string;
  bookTitleLabel: string;
  bookSubtitleLabel: string;
  studentNameLabel: string;
  admissionNumberLabel: string;
  genderLabel: string;
  classLabel: string;
  academicStructureLabel: string;
  academicPeriodLabel: string;
  subjectLabel: string;
  totalLabel: string;
  averageLabel: string;
  gradeLabel: string;
  gpaLabel: string;
  footerText: string;
  broadsheetTitleLabel: string;
  broadsheetGeneratedDateLabel: string;
  broadsheetFooterText: string;
  studentColumnLabel: string;
  admissionNumberColumnLabel: string;
  positionColumnLabel: string;
  gradeColumnLabel: string;
  remarkColumnLabel: string;

  active: boolean;
};

type ReportTemplateRow = {
  id?: string;
  accountId?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  name?: string;
  code?: string;
  layoutKey?: string;
  reportType?: ReportTemplateReportType | string;
  orientation?: string;
  paperSize?: string;
  density?: string;
  description?: string | null;
  active?: boolean;
  isDefault?: boolean;
  isDeleted?: boolean;
};

type ReportTemplateSettingsRow = {
  id?: string;
  accountId?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  templateId?: string | string | null;
  reportType?: ReportTemplateReportType | string;
  active?: boolean;
  isDeleted?: boolean;
  [key: string]: any;
};

type ReportTemplateAssignmentRow = {
  id?: string;
  accountId?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  templateId?: string | string | null;
  templateSettingsId?: string | string | null;
  reportType?: ReportTemplateReportType | string;
  scopeType?: string | null;
  scopeId?: string | null;
  isDefault?: boolean;
  active?: boolean;
  isDeleted?: boolean;
  [key: string]: any;
};

type PendingMediaRemoval = {
  assetId?: string | null;
  ownerTable: string;
  fieldKey: string;
  accountId?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  ownerId?: string | null;
  ownerTempKey?: string | null;
};

type SaveOptions = {
  silent?: boolean;
  reloadAfterSave?: boolean;
  persistRemovals?: boolean;

  /**
   * Only the Appearance sheet or Save All may publish theme/colour/typography.
   * Every unrelated settings save preserves the currently committed appearance.
   */
  includeAppearance?: boolean;
};

const defaultForm = (
  schoolId?: string | null,
  branchId?: string | null,
): SettingsForm => ({
  schoolId: schoolId || undefined,
  branchId: branchId || undefined,
  mode: "manual",
  fontFamily: "system-ui, -apple-system, sans-serif",
  fontSize: 16,
  primaryColor: "#2f6fed",
  theme: "light",
  currentTerm: "Term 1",
  academicYear: "",
  currentAcademicStructureId: undefined,
  currentAcademicPeriodId: undefined,
  logo: "",
  reportCardBackgroundImage: "",
  reportCardWatermark: "",
  reportCardSignatureImage: "",
  dashboardHeroImage: "",
  dashboardBannerImage: "",
  studentPortalImage: "",
  teacherPortalImage: "",
  classroomPlaceholderImage: "",
  subjectPlaceholderImage: "",
});

function studentReportTemplateDefinitionOptions(): ReportTemplateRow[] {
  return STUDENT_REPORT_TEMPLATE_REGISTRY.map((item: any, index: number) => ({
    name: item.name,
    code: item.code,
    layoutKey: item.layoutKey,
    reportType: "student_report",
    orientation: item.orientation || "portrait",
    paperSize: item.paperSize || "A4",
    density: item.density || "compact",
    description: item.description || "Student report card template.",
    active: item.active !== false,
    isDefault: item.isDefault === true || index === 0,
  }));
}

function cumulativeBookTemplateDefinitionOptions(): ReportTemplateRow[] {
  return STUDENT_REPORT_TEMPLATE_REGISTRY.map((item: any, index: number) => ({
    name: `${item.name} Book`,
    code: item.code,
    layoutKey: item.layoutKey,
    reportType: "cumulative_book",
    orientation: item.orientation || "portrait",
    paperSize: item.paperSize || "A4",
    density: item.density || "compact",
    description: `Cumulative report book using ${item.name} for every period snapshot.`,
    active: item.active !== false,
    isDefault: item.isDefault === true || index === 0,
  }));
}

function cumulativeTranscriptTemplateDefinitionOptions(): ReportTemplateRow[] {
  return CUMULATIVE_TRANSCRIPT_TEMPLATE_REGISTRY.map(
    (item: any, index: number) => ({
      name: item.name,
      code: item.code,
      layoutKey: item.layoutKey,
      reportType: "cumulative_transcript",
      orientation: item.orientation || "portrait",
      paperSize: item.paperSize || "A4",
      density: item.density || "compact",
      description: item.description || "Cumulative transcript template.",
      active: item.active !== false,
      isDefault: item.isDefault === true || index === 0,
    }),
  );
}

function broadsheetTemplateDefinitionOptions(
  reportType: "subject_broadsheet" | "class_broadsheet" | "annual_broadsheet",
): ReportTemplateRow[] {
  return BROADSHEET_TEMPLATE_REGISTRY.map((item: any, index: number) => ({
    name: item.name,
    code: item.code,
    layoutKey: item.layoutKey,
    reportType,
    orientation: item.orientation || "landscape",
    paperSize: item.paperSize || "A4",
    density: item.density || "compact",
    description: item.description || "Configurable broadsheet template.",
    active: item.active !== false,
    isDefault: item.isDefault === true || index === 0,
  }));
}

function reportTemplateDefinitionOptions(
  reportType?: ReportTemplateReportType,
): ReportTemplateRow[] {
  const all = [
    ...studentReportTemplateDefinitionOptions(),
    ...cumulativeBookTemplateDefinitionOptions(),
    ...cumulativeTranscriptTemplateDefinitionOptions(),
    ...broadsheetTemplateDefinitionOptions("subject_broadsheet"),
    ...broadsheetTemplateDefinitionOptions("class_broadsheet"),
    ...broadsheetTemplateDefinitionOptions("annual_broadsheet"),
  ];

  return reportType
    ? all.filter((item: any) => item.reportType === reportType)
    : all;
}

function defaultReportTemplateDefinition(
  reportType: ReportTemplateReportType = "student_report",
) {
  return (
    reportTemplateDefinitionOptions(reportType)[0] ||
    reportTemplateDefinitionOptions("student_report")[0]
  );
}

function reportTemplateFormFromDefinition(
  template?: Partial<ReportTemplateRow> | null,
  reportType: ReportTemplateReportType = "student_report",
): ReportTemplateForm {
  const fallback = defaultReportTemplateDefinition(reportType);
  const selected = template || fallback;
  const selectedReportType = ((selected as any).reportType ||
    reportType ||
    "student_report") as ReportTemplateReportType;

  return {
    reportType: selectedReportType,
    templateName: selected.name || fallback.name || "Classic Formal",
    templateCode: selected.code || fallback.code || "classic_formal",
    layoutKey: selected.layoutKey || fallback.layoutKey || "classic_formal",
    orientation: (selected.orientation ||
      fallback.orientation ||
      "portrait") as "portrait" | "landscape",
    paperSize: (selected.paperSize || fallback.paperSize || "A4") as
      | "A4"
      | "Letter",
    density: (selected.density || fallback.density || "compact") as
      | "compact"
      | "comfortable"
      | "spacious",

    showSubjectPosition: true,
    showClassPosition: true,
    showNumberOnRoll: false,
    showAttendance: true,
    showAttendancePercent: true,
    showStudentPhoto: true,
    showTeacherNames: true,
    showCurrentAcademicPeriodEnd: true,
    showNextAcademicPeriod: true,
    showPromotionStatus: false,
    showGPA: true,
    showAverage: true,
    showTotal: true,
    showGrade: true,
    showSubjectRemarks: true,
    showWatermark: true,
    showParentSignature: true,
    showGeneratedDate: selectedReportType !== "student_report",

    showAssessmentBreakdown: true,
    assessmentHierarchyDisplay: "item_rules",
    showAssessmentParentItems: true,
    showAssessmentChildItems: true,
    showCalculatedAssessmentItems: true,
    indentAssessmentChildren: true,
    showAssessmentGroupHeaders: true,
    flattenSingleChildAssessmentGroups: false,
    assessmentMaximumVisibleDepth: null,
    showAssessmentMaximumScores: true,
    showAssessmentWeights: false,
    showAssessmentRawScores: true,
    showAssessmentWeightedScores: true,
    showAssessmentHierarchyPath: false,

    broadsheetAssessmentHierarchyDisplay: "parents_only",
    broadsheetShowAssessmentGroupHeaders: true,
    broadsheetMaximumAssessmentDepth: null,

    showBookFrontCover: true,
    showBookStudentProfilePage: true,
    showBookAcademicJourneyPage: true,
    showBookSummaryPage: true,
    showBookBackCover: true,

    showTranscriptTermBreakdown: true,
    showTranscriptYearAverage: true,
    showTranscriptCumulativeAverage: true,
    showTranscriptCumulativePosition: true,
    showTranscriptGPAProgression: true,
    showTranscriptFinalRecommendation: true,

    showBroadsheetLogo: true,
    showBroadsheetWatermark: true,
    showBroadsheetGeneratedDate: true,
    showBroadsheetPageNumber: true,
    showBroadsheetSignatures: true,
    showBroadsheetSummary: true,
    showBroadsheetStatistics: true,
    showBroadsheetStudentPhoto: false,
    showBroadsheetAssessmentBreakdown: true,
    showBroadsheetWeightedTotal: true,
    showBroadsheetPercentage: true,
    showBroadsheetGrade: true,
    showBroadsheetRemark: true,
    showBroadsheetGPA: true,
    showBroadsheetPosition: true,
    showBroadsheetHighestScore: true,
    showBroadsheetLowestScore: true,
    showBroadsheetClassAverage: true,
    showBroadsheetSubjectScores: true,
    showBroadsheetSubjectGrades: true,
    showBroadsheetTotal: true,
    showBroadsheetAverage: true,
    showBroadsheetClassPosition: true,
    showBroadsheetAttendance: true,
    showBroadsheetClassHighestAverage: true,
    showBroadsheetClassLowestAverage: true,
    showBroadsheetPeriodScores: false,
    showBroadsheetAnnualAverage: true,
    showBroadsheetAnnualGPA: true,
    showBroadsheetAnnualPosition: true,
    showBroadsheetTrend: true,
    showBroadsheetPromotionDecision: true,
    showBroadsheetBestPeriod: true,
    showBroadsheetLatestPeriod: true,

    classTeacherLabel: "Class Teacher",
    headTeacherLabel: "Headteacher / Principal",
    parentLabel: "Parent / Guardian",
    principalLabel: "Principal",
    currentAcademicPeriodEndLabel: "This Academic Period Ends",
    nextAcademicPeriodLabel: "Next Academic Period Begins",
    numberOnRollLabel: "Number On Roll",
    classPositionLabel: "Class Position",
    subjectPositionLabel:
      selectedReportType === "cumulative_transcript" ? "Rank" : "Position",
    generatedDateLabel: "Generated",
    bookTitleLabel: "Cumulative Academic Report Book",
    bookSubtitleLabel: "Student Academic Journey",
    studentNameLabel: "Student",
    admissionNumberLabel: "Student ID",
    genderLabel: "Gender",
    classLabel:
      selectedReportType === "cumulative_transcript"
        ? "Programme / Class"
        : "Class",
    academicStructureLabel: "Academic Structure",
    academicPeriodLabel:
      selectedReportType === "cumulative_transcript"
        ? "Academic Period"
        : "Academic Period",
    subjectLabel:
      selectedReportType === "cumulative_transcript"
        ? "Course / Subject"
        : "Subject",
    totalLabel: "Total",
    averageLabel: "Average",
    gradeLabel: "Grade",
    gpaLabel: "GPA",
    footerText: "Official academic document generated by Eleeveon Schools.",
    broadsheetTitleLabel:
      selectedReportType === "subject_broadsheet"
        ? "Subject Broadsheet"
        : selectedReportType === "class_broadsheet"
          ? "Class Broadsheet"
          : selectedReportType === "annual_broadsheet"
            ? "Annual Cumulative Broadsheet"
            : "Broadsheet",
    broadsheetGeneratedDateLabel: "Generated",
    broadsheetFooterText:
      "Official academic broadsheet generated by Eleeveon Schools.",
    studentColumnLabel: "Student",
    admissionNumberColumnLabel: "Admission No.",
    positionColumnLabel: "Position",
    gradeColumnLabel: "Grade",
    remarkColumnLabel: "Remark",

    active: true,
  };
}

const defaultReportTemplateForm = (): ReportTemplateForm =>
  reportTemplateFormFromDefinition(
    defaultReportTemplateDefinition("student_report"),
    "student_report",
  );

function reportTemplatePreviewSettingsFromForm(
  form: ReportTemplateForm,
  template?: Partial<ReportTemplateRow> | null,
) {
  const selected = template || null;

  return {
    ...form,
    reportType:
      (selected as any)?.reportType || form.reportType || "student_report",
    templateName: selected?.name || form.templateName,
    templateCode: selected?.code || form.templateCode,
    layoutKey: selected?.layoutKey || form.layoutKey,
    orientation: (form.orientation || selected?.orientation || "portrait") as
      | "portrait"
      | "landscape",
    paperSize: (form.paperSize || selected?.paperSize || "A4") as
      | "A4"
      | "Letter",
    density: form.density || selected?.density || "compact",
  };
}

function selectReportTemplateIntoForm(
  template: Partial<ReportTemplateRow> | null | undefined,
  updateField: (key: keyof ReportTemplateForm, value: any) => void,
  reportType?: ReportTemplateReportType,
) {
  const resolvedReportType = ((template as any)?.reportType ||
    reportType ||
    "student_report") as ReportTemplateReportType;
  const selected =
    template || defaultReportTemplateDefinition(resolvedReportType);
  const code =
    selected.code ||
    selected.layoutKey ||
    defaultReportTemplateDefinition(resolvedReportType).code ||
    "classic_formal";

  updateField("reportType", resolvedReportType);
  updateField("templateId", idOf((selected as any)?.id) || undefined);
  updateField("templateName", selected.name || "Report Template");
  updateField("templateCode", code);
  updateField("layoutKey", selected.layoutKey || code);
  updateField(
    "orientation",
    ((selected as any)?.orientation || "portrait") as "portrait" | "landscape",
  );
  updateField(
    "paperSize",
    ((selected as any)?.paperSize || "A4") as "A4" | "Letter",
  );
  updateField(
    "density",
    ((selected as any)?.density || "compact") as
      | "compact"
      | "comfortable"
      | "spacious",
  );
}

function createDummyStudentReportPreviewDataset(args: {
  schoolName?: string;
  branchName?: string;
  primaryColor?: string;
  fontFamily?: string;
  logo?: string;
  reportCardBackgroundImage?: string;
  reportCardWatermark?: string;
  reportCardSignatureImage?: string;
}) {
  const schoolName = args.schoolName || "Eleeveon International Academy";
  const branchName = args.branchName || "Main Campus";

  const currentAcademicPeriod = {
    id: 1,
    name: "Term 2, 2026",
    startDate: "2026-05-06",
    endDate: "2026-07-31",
    formattedStartDate: "May 06, 2026",
    formattedEndDate: "Jul 31, 2026",
  };

  const nextAcademicPeriod = {
    id: 2,
    name: "Term 3, 2026",
    startDate: "2026-09-10",
    endDate: "2026-12-12",
    formattedStartDate: "Sep 10, 2026",
    formattedEndDate: "Dec 12, 2026",
  };

  const assessmentColumns = [
    {
      assessmentStructureItemId: 1,
      name: "Class Score",
      maxScore: 50,
      weight: 50,
      order: 1,
    },
    {
      assessmentStructureItemId: 2,
      name: "Exam",
      maxScore: 100,
      weight: 50,
      order: 2,
    },
  ];

  const subjects = [
    ["English Language", "Ms. Abena Mensah", 42, 84, 88, "A", 2, "Excellent"],
    ["Mathematics", "Mr. Kofi Addo", 45, 90, 92, "A+", 1, "Outstanding"],
    ["Science", "Mrs. Ama Boateng", 39, 82, 84, "A", 3, "Very Good"],
    ["Social Studies", "Mr. Kwame Owusu", 40, 78, 80, "B+", 4, "Good"],
  ] as const;

  return {
    generatedAt: "2026-07-07T12:00:00.000Z",
    header: {
      schoolName,
      branchName,
      primaryColor: args.primaryColor || "#2f6fed",
      fontFamily: args.fontFamily || "system-ui, -apple-system, sans-serif",
      logo: args.logo || "",
      reportCardBackgroundImage: args.reportCardBackgroundImage || "",
      reportCardWatermark: args.reportCardWatermark || args.logo || "",
      reportCardSignatureImage: args.reportCardSignatureImage || "",
      school: {
        name: schoolName,
        motto: "Excellence, Character and Service",
        address: "P.O. Box 100, Accra",
        phone: "+233 24 000 0000",
        email: "info@school.edu.gh",
        website: "www.school.edu.gh",
        logo: args.logo || "",
      },
      branch: {
        name: branchName,
        address: "Main Campus, Accra",
        phone: "+233 24 000 0000",
        email: "branch@school.edu.gh",
        website: "www.school.edu.gh",
        logo: args.logo || "",
      },
      academicStructure: { id: 1, name: "Basic School" },
      academicStructureName: "Basic School",
      academicPeriod: currentAcademicPeriod,
      academicPeriodName: currentAcademicPeriod.name,
      classData: { id: 1, name: "Grade 6" },
      className: "Grade 6",
    },
    branding: {
      schoolName,
      branchName,
      primaryColor: args.primaryColor || "#2f6fed",
      fontFamily: args.fontFamily || "system-ui, -apple-system, sans-serif",
      logo: args.logo || "",
      reportCardBackgroundImage: args.reportCardBackgroundImage || "",
      reportCardWatermark: args.reportCardWatermark || args.logo || "",
      reportCardSignatureImage: args.reportCardSignatureImage || "",
      address: "P.O. Box 100, Accra",
      phone: "+233 24 000 0000",
      email: "info@school.edu.gh",
      website: "www.school.edu.gh",
      motto: "Excellence, Character and Service",
      branchAddress: "Main Campus, Accra",
    },
    currentAcademicPeriod,
    nextAcademicPeriod,
    student: {
      id: 1,
      name: "Jonathan Commey",
      fullName: "Jonathan Commey",
      admissionNumber: "STD-2026-014",
      gender: "Male",
      photo: "",
    },
    studentInfo: {
      studentPhoto: "",
      numberOnRoll: 38,
    },
    signatures: {
      classTeacherName: "Ms. Abena Mensah",
      headTeacherName: "Rev. Daniel Asare",
      principalName: "Rev. Daniel Asare",
      parentName: "Parent / Guardian",
      guardianName: "Parent / Guardian",
      officialSignatureImage: args.reportCardSignatureImage || "",
    },
    report: {
      studentId: 1,
      studentName: "Jonathan Commey",
      admissionNumber: "STD-2026-014",
      gender: "Male",
      className: "Grade 6",
      attendance: {
        presentDays: 58,
        totalDays: 62,
        attendancePercent: 93.5,
      },
      total: 344,
      average: 86,
      overallPosition: 2,
      overallGPA: 3.82,
      classTeacherRemark:
        "Jonathan is attentive, respectful and participates actively in class.",
      headTeacherRemark:
        "A strong performance. Keep building excellent learning habits.",
      subjectResults: subjects.map((subject, index) => {
        const [
          subjectName,
          teacherName,
          classScore,
          examScore,
          percentage,
          grade,
          position,
          remark,
        ] = subject;
        return {
          classSubjectId: index + 1,
          subjectName,
          teacherName,
          breakdown: assessmentColumns.map((column) => ({
            ...column,
            score:
              column.assessmentStructureItemId === 1 ? classScore : examScore,
          })),
          weightedTotal: percentage,
          percentage,
          grade,
          subjectPosition: position,
          remark,
        };
      }),
    },
  };
}

function createDummyCumulativeReportBookPreviewDataset(args: {
  schoolName?: string;
  branchName?: string;
  primaryColor?: string;
  fontFamily?: string;
  logo?: string;
  reportCardBackgroundImage?: string;
  reportCardWatermark?: string;
  reportCardSignatureImage?: string;
}) {
  const term1 = createDummyStudentReportPreviewDataset(args);
  const term2 = createDummyStudentReportPreviewDataset(args) as any;
  const term3 = createDummyStudentReportPreviewDataset(args) as any;

  term1.header.academicPeriod = {
    ...term1.header.academicPeriod,
    name: "Term 1, 2026",
    formattedEndDate: "Apr 04, 2026",
  };
  term1.header.academicPeriodName = "Term 1, 2026";
  term1.report.average = 82.4;
  term1.report.total = 329.6;
  term1.report.overallPosition = 4;

  term2.header.academicPeriod = {
    ...term2.header.academicPeriod,
    name: "Term 2, 2026",
    formattedEndDate: "Jul 31, 2026",
  };
  term2.header.academicPeriodName = "Term 2, 2026";

  term3.header.academicPeriod = {
    ...term3.header.academicPeriod,
    name: "Term 3, 2026",
    formattedEndDate: "Dec 12, 2026",
  };
  term3.header.academicPeriodName = "Term 3, 2026";
  term3.report.average = 89.2;
  term3.report.total = 356.8;
  term3.report.overallPosition = 1;

  return {
    generatedAt: "2026-07-07T12:00:00.000Z",
    title: "Cumulative Academic Report Book",
    subtitle: "Student Academic Journey",
    header: term2.header,
    branding: term2.branding,
    student: {
      id: 1,
      fullName: "Jonathan Commey",
      admissionNumber: "STD-2026-014",
      gender: "Male",
      currentClassName: "Grade 6",
      parentName: "Parent / Guardian",
      parentPhone: "+233 24 000 0000",
      address: "Accra, Ghana",
      studentPhoto: "",
    },
    periods: [
      {
        id: 1,
        academicPeriodName: "Term 1, 2026",
        academicYear: "2026",
        dataset: term1,
        average: 82.4,
        position: 4,
        gpa: 3.54,
        recommendation: "promote",
      },
      {
        id: 2,
        academicPeriodName: "Term 2, 2026",
        academicYear: "2026",
        dataset: term2,
        average: 86,
        position: 2,
        gpa: 3.82,
        recommendation: "promote",
      },
      {
        id: 3,
        academicPeriodName: "Term 3, 2026",
        academicYear: "2026",
        dataset: term3,
        average: 89.2,
        position: 1,
        gpa: 3.9,
        recommendation: "promote",
      },
    ],
    notes: [
      "This is a preview-only academic booklet using dummy records.",
      "Actual cumulative books will use the student's saved report snapshots.",
    ],
  };
}

function createDummyCumulativeTranscriptPreviewDataset(args: {
  schoolName?: string;
  branchName?: string;
  primaryColor?: string;
  fontFamily?: string;
  logo?: string;
  reportCardWatermark?: string;
}) {
  const schoolName = args.schoolName || "Eleeveon International Academy";
  const branchName = args.branchName || "Main Campus";
  const primaryColor = args.primaryColor || "#111827";

  return {
    generatedAt: "2026-07-07T12:00:00.000Z",
    header: {
      branding: {
        schoolName,
        branchName,
        primaryColor,
        fontFamily: args.fontFamily || "Arial, sans-serif",
        logo: args.logo || "",
        reportCardWatermark: args.reportCardWatermark || args.logo || "",
        address: "P.O. Box 100, Accra",
        phone: "+233 24 000 0000",
        email: "records@school.edu.gh",
        website: "www.school.edu.gh",
        motto: "Excellence, Character and Service",
      },
      academicStructure: { id: 1, name: "Basic School" },
      academicPeriod: { id: 3, name: "Term 3, 2026" },
      classData: { id: 1, name: "Grade 6" },
    },
    transcript: {
      studentId: 1,
      studentName: "Jonathan Commey",
      admissionNumber: "STD-2026-014",
      gender: "Male",
      studentPhoto: "",
      currentClassName: "Grade 6",
      parentName: "Parent / Guardian",
      guardianName: "Parent / Guardian",
      periods: [
        {
          academicPeriodId: 1,
          academicPeriodName: "Term 1, 2026",
          academicYear: "2026",
          className: "Grade 6",
          total: 329.6,
          average: 82.4,
          gpa: 3.54,
          position: 4,
          recommendation: "promote",
          subjectResults: [
            {
              subjectId: 1,
              subjectName: "English Language",
              subjectCode: "ENG",
              percentage: 82,
              grade: "A",
              remark: "Very Good",
              position: 3,
            },
            {
              subjectId: 2,
              subjectName: "Mathematics",
              subjectCode: "MATH",
              percentage: 86,
              grade: "A",
              remark: "Excellent",
              position: 2,
            },
            {
              subjectId: 3,
              subjectName: "Science",
              subjectCode: "SCI",
              percentage: 80,
              grade: "B+",
              remark: "Good",
              position: 5,
            },
          ],
        },
        {
          academicPeriodId: 2,
          academicPeriodName: "Term 2, 2026",
          academicYear: "2026",
          className: "Grade 6",
          total: 344,
          average: 86,
          gpa: 3.82,
          position: 2,
          recommendation: "promote",
          subjectResults: [
            {
              subjectId: 1,
              subjectName: "English Language",
              subjectCode: "ENG",
              percentage: 88,
              grade: "A",
              remark: "Excellent",
              position: 2,
            },
            {
              subjectId: 2,
              subjectName: "Mathematics",
              subjectCode: "MATH",
              percentage: 92,
              grade: "A+",
              remark: "Outstanding",
              position: 1,
            },
            {
              subjectId: 3,
              subjectName: "Science",
              subjectCode: "SCI",
              percentage: 84,
              grade: "A",
              remark: "Very Good",
              position: 3,
            },
          ],
        },
        {
          academicPeriodId: 3,
          academicPeriodName: "Term 3, 2026",
          academicYear: "2026",
          className: "Grade 6",
          total: 356.8,
          average: 89.2,
          gpa: 3.9,
          position: 1,
          recommendation: "promote",
          subjectResults: [
            {
              subjectId: 1,
              subjectName: "English Language",
              subjectCode: "ENG",
              percentage: 90,
              grade: "A+",
              remark: "Outstanding",
              position: 1,
            },
            {
              subjectId: 2,
              subjectName: "Mathematics",
              subjectCode: "MATH",
              percentage: 94,
              grade: "A+",
              remark: "Outstanding",
              position: 1,
            },
            {
              subjectId: 3,
              subjectName: "Science",
              subjectCode: "SCI",
              percentage: 88,
              grade: "A",
              remark: "Excellent",
              position: 2,
            },
          ],
        },
      ],
      academicYears: [],
      subjectHistories: [],
      progression: [],
      totalPeriods: 3,
      totalSubjects: 3,
      cumulativeTotal: 1030.4,
      cumulativeAverage: 85.9,
      cumulativeGPA: 3.75,
      highestAverage: 89.2,
      lowestAverage: 82.4,
      latestAverage: 89.2,
      latestPosition: 1,
      latestDecision: "promote",
      overallTrend: "up",
    },
  };
}

function createDummyBroadsheetPreviewHeader(args: {
  schoolName?: string;
  branchName?: string;
  primaryColor?: string;
  fontFamily?: string;
  logo?: string;
  reportCardBackgroundImage?: string;
  reportCardWatermark?: string;
  reportCardSignatureImage?: string;
}) {
  return {
    branding: {
      schoolName: args.schoolName || "Eleeveon International Academy",
      branchName: args.branchName || "Main Campus",
      motto: "Excellence, Character and Service",
      address: "P.O. Box 100, Accra",
      branchAddress: "Main Campus, Accra",
      phone: "+233 24 000 0000",
      email: "records@school.edu.gh",
      website: "www.school.edu.gh",
      primaryColor: args.primaryColor || "#2f6fed",
      fontFamily: args.fontFamily || "Arial, sans-serif",
      logo: args.logo || "",
      resolvedLogoUrl: args.logo || "",
      reportCardBackgroundImage: args.reportCardBackgroundImage || "",
      resolvedReportCardBackgroundImageUrl:
        args.reportCardBackgroundImage || "",
      reportCardWatermark: args.reportCardWatermark || args.logo || "",
      resolvedReportCardWatermarkUrl:
        args.reportCardWatermark || args.logo || "",
      reportCardSignatureImage: args.reportCardSignatureImage || "",
      resolvedReportCardSignatureImageUrl: args.reportCardSignatureImage || "",
    },
    academicStructure: { id: 1, name: "Basic School" },
    academicStructureName: "Basic School",
    academicPeriod: { id: 2, name: "Term 2, 2026" },
    academicPeriodName: "Term 2, 2026",
    classData: { id: 1, name: "Grade 6" },
    className: "Grade 6",
  };
}

function createDummySubjectBroadsheetPreviewDataset() {
  const assessmentColumns = [
    {
      assessmentStructureItemId: 1,
      name: "Class Score",
      maxScore: 50,
      weight: 50,
      order: 1,
    },
    {
      assessmentStructureItemId: 2,
      name: "Exam",
      maxScore: 100,
      weight: 50,
      order: 2,
    },
  ];
  const rows = [
    ["Jonathan Commey", "STD-014", 42, 88, 86, "A", 2, "Excellent"],
    ["Ama Owusu", "STD-015", 46, 94, 93, "A+", 1, "Outstanding"],
    ["Kwesi Mensah", "STD-016", 37, 76, 75, "B", 4, "Good"],
    ["Nana Boateng", "STD-017", 40, 82, 81, "A", 3, "Very Good"],
  ] as const;
  return {
    classSubjectId: 1,
    classId: 1,
    subjectId: 1,
    className: "Grade 6",
    subjectName: "Mathematics",
    teacherName: "Mr. Kofi Addo",
    assessmentColumns,
    students: rows.map((row, index) => ({
      studentId: index + 1,
      studentName: row[0],
      admissionNumber: row[1],
      resolvedStudentPhotoUrl: "",
      breakdown: assessmentColumns.map((column) => ({
        ...column,
        score: column.assessmentStructureItemId === 1 ? row[2] : row[3],
      })),
      weightedTotal: row[4],
      percentage: row[4],
      grade: row[5],
      gpa: row[4] >= 90 ? 4 : row[4] >= 80 ? 3.7 : 3,
      position: row[6],
      remark: row[7],
    })),
    highestScore: 93,
    lowestScore: 75,
    classAverage: 83.75,
  };
}

function createDummyClassBroadsheetPreviewDataset() {
  const subjectColumns = [
    {
      classSubjectId: 1,
      subjectId: 1,
      subjectName: "English Language",
      subjectCode: "ENG",
      shortName: "ENG",
    },
    {
      classSubjectId: 2,
      subjectId: 2,
      subjectName: "Mathematics",
      subjectCode: "MATH",
      shortName: "MATH",
    },
    {
      classSubjectId: 3,
      subjectId: 3,
      subjectName: "Science",
      subjectCode: "SCI",
      shortName: "SCI",
    },
  ];
  const rows: any[] = [
    ["Jonathan Commey", "STD-014", [88, 92, 84], 88, 2],
    ["Ama Owusu", "STD-015", [94, 96, 91], 93.7, 1],
    ["Kwesi Mensah", "STD-016", [76, 80, 78], 78, 4],
    ["Nana Boateng", "STD-017", [84, 86, 82], 84, 3],
  ];
  return {
    classId: 1,
    className: "Grade 6",
    subjectColumns,
    students: rows.map((row, index) => ({
      studentId: index + 1,
      studentName: row[0],
      admissionNumber: row[1],
      resolvedStudentPhotoUrl: "",
      subjects: subjectColumns.map((subject, subjectIndex) => ({
        ...subject,
        percentage: row[2][subjectIndex],
        grade:
          row[2][subjectIndex] >= 90
            ? "A+"
            : row[2][subjectIndex] >= 80
              ? "A"
              : "B",
      })),
      total: row[2].reduce((sum: number, value: number) => sum + value, 0),
      average: row[3],
      gpa: row[3] >= 90 ? 4 : row[3] >= 80 ? 3.7 : 3,
      position: row[4],
      attendancePercent: 94 - index,
    })),
    highestAverage: 93.7,
    lowestAverage: 78,
    classAverage: 85.9,
  };
}

function createDummyAnnualBroadsheetPreviewDataset() {
  const subjectColumns = [
    {
      subjectId: 1,
      subjectName: "English Language",
      subjectCode: "ENG",
      shortName: "ENG",
    },
    {
      subjectId: 2,
      subjectName: "Mathematics",
      subjectCode: "MATH",
      shortName: "MATH",
    },
    {
      subjectId: 3,
      subjectName: "Science",
      subjectCode: "SCI",
      shortName: "SCI",
    },
  ];
  const periods = ["Term 1, 2026", "Term 2, 2026", "Term 3, 2026"];
  const rows: any[] = [
    ["Jonathan Commey", "STD-014", [87, 91, 85], 87.7, 2, "promote"],
    ["Ama Owusu", "STD-015", [93, 95, 92], 93.3, 1, "promote"],
    ["Kwesi Mensah", "STD-016", [76, 79, 77], 77.3, 4, "repeat"],
    ["Nana Boateng", "STD-017", [84, 86, 83], 84.3, 3, "promote"],
  ];
  return {
    classId: 1,
    className: "Grade 6",
    academicYear: "2026",
    periodNames: periods,
    totalPeriods: periods.length,
    totalStudents: rows.length,
    totalSubjects: subjectColumns.length,
    subjectColumns,
    students: rows.map((row, index) => ({
      studentId: index + 1,
      studentName: row[0],
      admissionNumber: row[1],
      className: "Grade 6",
      resolvedStudentPhotoUrl: "",
      subjects: subjectColumns.map((subject, subjectIndex) => ({
        ...subject,
        average: row[2][subjectIndex],
        grade:
          row[2][subjectIndex] >= 90
            ? "A+"
            : row[2][subjectIndex] >= 80
              ? "A"
              : "B",
        periodScores: periods.map((academicPeriodName, periodIndex) => ({
          academicPeriodId: periodIndex + 1,
          academicPeriodName,
          percentage: row[2][subjectIndex] - 2 + periodIndex * 2,
        })),
      })),
      periodsCount: periods.length,
      subjectsCount: subjectColumns.length,
      total: row[2].reduce((sum: number, value: number) => sum + value, 0),
      average: row[3],
      gpa: row[3] >= 90 ? 4 : row[3] >= 80 ? 3.7 : 3,
      position: row[4],
      recommendation: row[5],
      finalDecision: row[5],
    })),
    highestAverage: 93.3,
    lowestAverage: 77.3,
    classAverage: 85.65,
    promotionCount: 3,
    repeatCount: 1,
    graduateCount: 0,
  };
}

const reportBooleanKeys: (keyof ReportTemplateForm)[] = [
  "showSubjectPosition",
  "showClassPosition",
  "showNumberOnRoll",
  "showAttendance",
  "showAttendancePercent",
  "showStudentPhoto",
  "showTeacherNames",
  "showCurrentAcademicPeriodEnd",
  "showNextAcademicPeriod",
  "showPromotionStatus",
  "showGPA",
  "showAverage",
  "showTotal",
  "showGrade",
  "showSubjectRemarks",
  "showWatermark",
  "showParentSignature",
  "showGeneratedDate",
  "showAssessmentBreakdown",
  "showAssessmentParentItems",
  "showAssessmentChildItems",
  "showCalculatedAssessmentItems",
  "indentAssessmentChildren",
  "showAssessmentGroupHeaders",
  "flattenSingleChildAssessmentGroups",
  "showAssessmentMaximumScores",
  "showAssessmentWeights",
  "showAssessmentRawScores",
  "showAssessmentWeightedScores",
  "showAssessmentHierarchyPath",
  "broadsheetShowAssessmentGroupHeaders",
  "showBookFrontCover",
  "showBookStudentProfilePage",
  "showBookAcademicJourneyPage",
  "showBookSummaryPage",
  "showBookBackCover",
  "showTranscriptTermBreakdown",
  "showTranscriptYearAverage",
  "showTranscriptCumulativeAverage",
  "showTranscriptCumulativePosition",
  "showTranscriptGPAProgression",
  "showTranscriptFinalRecommendation",
  "showBroadsheetLogo",
  "showBroadsheetWatermark",
  "showBroadsheetGeneratedDate",
  "showBroadsheetPageNumber",
  "showBroadsheetSignatures",
  "showBroadsheetSummary",
  "showBroadsheetStatistics",
  "showBroadsheetStudentPhoto",
  "showBroadsheetAssessmentBreakdown",
  "showBroadsheetWeightedTotal",
  "showBroadsheetPercentage",
  "showBroadsheetGrade",
  "showBroadsheetRemark",
  "showBroadsheetGPA",
  "showBroadsheetPosition",
  "showBroadsheetHighestScore",
  "showBroadsheetLowestScore",
  "showBroadsheetClassAverage",
  "showBroadsheetSubjectScores",
  "showBroadsheetSubjectGrades",
  "showBroadsheetTotal",
  "showBroadsheetAverage",
  "showBroadsheetClassPosition",
  "showBroadsheetAttendance",
  "showBroadsheetClassHighestAverage",
  "showBroadsheetClassLowestAverage",
  "showBroadsheetPeriodScores",
  "showBroadsheetAnnualAverage",
  "showBroadsheetAnnualGPA",
  "showBroadsheetAnnualPosition",
  "showBroadsheetTrend",
  "showBroadsheetPromotionDecision",
  "showBroadsheetBestPeriod",
  "showBroadsheetLatestPeriod",
];

// ======================================================
// HELPERS
// ======================================================

function sameId(a: unknown, b: unknown) {
  return String(a ?? "") === String(b ?? "");
}

const idOf = (value: unknown): string => {
  if (value === undefined || value === null) return "";
  return String(value).trim();
};

const cleanId = (value: unknown): string => idOf(value);

const OPEN_WORKSPACE_KEY = "eleeveon_open_workspace";

const SETTINGS_MEDIA_OWNER_TABLE = MediaOwners.SCHOOL_BRANCH_SETTINGS;
const SCHOOL_MEDIA_OWNER_TABLE = MediaOwners.SCHOOLS;
const BRANCH_MEDIA_OWNER_TABLE = MediaOwners.BRANCHES;
const GALLERY_FIELD_KEY = MediaFieldKeys.GALLERY;

type OpenWorkspaceSession = {
  membership?: Record<string, any> | null;
  membershipId?: string | null;
  role?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  teacherId?: string | null;
  studentId?: string | null;
  parentId?: string | null;
  memberName?: string | null;
  fullName?: string | null;
  userName?: string | null;
  openedAt?: number;
};

function safeStorageRead(key: string) {
  if (typeof window === "undefined") return null;

  try {
    return (
      window.localStorage.getItem(key) || window.sessionStorage.getItem(key)
    );
  } catch {
    return null;
  }
}

function safeJsonRead<T>(key: string): T | null {
  const raw = safeStorageRead(key);
  if (!raw) return null;

  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

function readOpenWorkspaceSession() {
  return safeJsonRead<OpenWorkspaceSession>(OPEN_WORKSPACE_KEY);
}

function readStoredActiveMembership() {
  return safeJsonRead<Record<string, any>>("activeMembership");
}

function firstPermanentId(...values: unknown[]): string {
  for (const value of values) {
    const parsed = idOf(value);
    if (parsed) return parsed;
  }

  return "";
}

function selectedWorkspaceSchoolId(args: {
  openWorkspace?: OpenWorkspaceSession | null;
  activeMembership?: Record<string, any> | null;
  activeSchoolId?: unknown;
  activeSchool?: Record<string, any> | null;
  settings?: Record<string, any> | null;
}) {
  const storedMembership = readStoredActiveMembership();
  const membership =
    args.openWorkspace?.membership ||
    args.activeMembership ||
    storedMembership ||
    null;

  return firstPermanentId(
    args.openWorkspace?.schoolId,
    membership?.schoolId,
    membership?.school?.id,
    args.activeSchoolId,
    args.activeSchool?.id,
    args.settings?.schoolId,
    safeStorageRead("activeSchoolId"),
  );
}

function selectedWorkspaceBranchId(args: {
  openWorkspace?: OpenWorkspaceSession | null;
  activeMembership?: Record<string, any> | null;
  activeBranchId?: unknown;
  activeBranch?: Record<string, any> | null;
  settings?: Record<string, any> | null;
}) {
  const storedMembership = readStoredActiveMembership();
  const membership =
    args.openWorkspace?.membership ||
    args.activeMembership ||
    storedMembership ||
    null;

  return firstPermanentId(
    args.openWorkspace?.branchId,
    membership?.branchId,
    membership?.schoolBranchId,
    membership?.branch?.id,
    args.activeBranchId,
    args.activeBranch?.id,
    args.settings?.branchId,
    safeStorageRead("activeBranchId"),
  );
}

function mediaIdFieldFor(field: ImageField) {
  return `${field}MediaId` as keyof SettingsForm;
}

function schoolMediaIdFieldFor(field: keyof SchoolForm) {
  return `${String(field)}MediaId` as keyof SchoolForm;
}

function branchMediaIdFieldFor(field: keyof BranchForm) {
  return `${String(field)}MediaId` as keyof BranchForm;
}

function isPositiveMediaId(value: unknown) {
  return Boolean(idOf(value));
}

function mediaIdOrNull(value: unknown): string | null {
  const parsed = idOf(value);
  return parsed || null;
}

function safeRecordMediaValue(value?: string) {
  const media = String(value || "");
  if (!media) return undefined;
  if (media.startsWith("blob:")) return undefined;
  if (media.startsWith("data:image/")) return undefined;
  return media;
}

function assetPreviewKey(
  ownerTable: string,
  ownerId: string,
  fieldKey: string,
) {
  return `${ownerTable}:${ownerId}:${fieldKey}`;
}

function galleryAssetPreviewKey(assetId: unknown) {
  return `${SETTINGS_MEDIA_OWNER_TABLE}:gallery:${idOf(assetId)}`;
}

function createSettingsMediaSessionKey() {
  return createSharedMediaSessionKey(SETTINGS_MEDIA_OWNER_TABLE);
}

function createPendingRemoval(args: {
  assetId?: unknown;
  ownerTable: string;
  fieldKey: string;
  accountId?: string | null;
  schoolId?: unknown;
  branchId?: unknown;
  ownerId?: unknown;
  ownerTempKey?: string | null;
}): PendingMediaRemoval {
  return {
    assetId: idOf(args.assetId) || null,
    ownerTable: args.ownerTable,
    fieldKey: args.fieldKey,
    accountId: args.accountId || null,
    schoolId: idOf(args.schoolId) || null,
    branchId: idOf(args.branchId) || null,
    ownerId: idOf(args.ownerId) || null,

    ownerTempKey: args.ownerTempKey || null,
  };
}

function hasOwn(source: any, key: string) {
  return Object.prototype.hasOwnProperty.call(source || {}, key);
}

function valueOrExisting<T>(source: any, key: string, existingValue: T): T {
  return hasOwn(source, key) ? source[key] : existingValue;
}

function makeSettingsPayload(
  payload: Partial<SchoolBranchSetting>,
  existing?: Partial<SchoolBranchSetting>,
): SchoolBranchSetting {
  const now = Date.now();

  return {
    ...(existing || {}),
    ...payload,
    accountId: payload.accountId ?? existing?.accountId ?? "",
    schoolId: cleanId(payload.schoolId ?? existing?.schoolId) || undefined,
    branchId: cleanId(payload.branchId ?? existing?.branchId) || undefined,

    mode: payload.mode ?? existing?.mode ?? "manual",
    theme: payload.theme ?? existing?.theme ?? "light",
    primaryColor: payload.primaryColor ?? existing?.primaryColor ?? "#2f6fed",
    fontFamily:
      payload.fontFamily ??
      existing?.fontFamily ??
      "system-ui, -apple-system, sans-serif",
    fontSize: Number(payload.fontSize ?? existing?.fontSize ?? 16),

    academicYear: payload.academicYear ?? existing?.academicYear ?? "",
    currentTerm: payload.currentTerm ?? existing?.currentTerm ?? "Term 1",
    currentAcademicStructureId:
      payload.currentAcademicStructureId ??
      existing?.currentAcademicStructureId,
    currentAcademicPeriodId:
      payload.currentAcademicPeriodId ?? existing?.currentAcademicPeriodId,

    logo: valueOrExisting(payload, "logo", existing?.logo),
    logoMediaId: hasOwn(payload as any, "logoMediaId")
      ? (payload as any).logoMediaId
      : (existing as any)?.logoMediaId,
    reportCardBackgroundImage: valueOrExisting(
      payload,
      "reportCardBackgroundImage",
      existing?.reportCardBackgroundImage,
    ),
    reportCardBackgroundImageMediaId: hasOwn(
      payload as any,
      "reportCardBackgroundImageMediaId",
    )
      ? (payload as any).reportCardBackgroundImageMediaId
      : (existing as any)?.reportCardBackgroundImageMediaId,
    reportCardWatermark: valueOrExisting(
      payload,
      "reportCardWatermark",
      existing?.reportCardWatermark,
    ),
    reportCardWatermarkMediaId: hasOwn(
      payload as any,
      "reportCardWatermarkMediaId",
    )
      ? (payload as any).reportCardWatermarkMediaId
      : (existing as any)?.reportCardWatermarkMediaId,
    reportCardSignatureImage: valueOrExisting(
      payload,
      "reportCardSignatureImage",
      existing?.reportCardSignatureImage,
    ),
    reportCardSignatureImageMediaId: hasOwn(
      payload as any,
      "reportCardSignatureImageMediaId",
    )
      ? (payload as any).reportCardSignatureImageMediaId
      : (existing as any)?.reportCardSignatureImageMediaId,
    dashboardHeroImage: valueOrExisting(
      payload,
      "dashboardHeroImage",
      existing?.dashboardHeroImage,
    ),
    dashboardHeroImageMediaId: hasOwn(
      payload as any,
      "dashboardHeroImageMediaId",
    )
      ? (payload as any).dashboardHeroImageMediaId
      : (existing as any)?.dashboardHeroImageMediaId,
    dashboardBannerImage: valueOrExisting(
      payload,
      "dashboardBannerImage",
      existing?.dashboardBannerImage,
    ),
    dashboardBannerImageMediaId: hasOwn(
      payload as any,
      "dashboardBannerImageMediaId",
    )
      ? (payload as any).dashboardBannerImageMediaId
      : (existing as any)?.dashboardBannerImageMediaId,
    studentPortalImage: valueOrExisting(
      payload,
      "studentPortalImage",
      existing?.studentPortalImage,
    ),
    studentPortalImageMediaId: hasOwn(
      payload as any,
      "studentPortalImageMediaId",
    )
      ? (payload as any).studentPortalImageMediaId
      : (existing as any)?.studentPortalImageMediaId,
    teacherPortalImage: valueOrExisting(
      payload,
      "teacherPortalImage",
      existing?.teacherPortalImage,
    ),
    teacherPortalImageMediaId: hasOwn(
      payload as any,
      "teacherPortalImageMediaId",
    )
      ? (payload as any).teacherPortalImageMediaId
      : (existing as any)?.teacherPortalImageMediaId,
    classroomPlaceholderImage: valueOrExisting(
      payload,
      "classroomPlaceholderImage",
      existing?.classroomPlaceholderImage,
    ),
    classroomPlaceholderImageMediaId: hasOwn(
      payload as any,
      "classroomPlaceholderImageMediaId",
    )
      ? (payload as any).classroomPlaceholderImageMediaId
      : (existing as any)?.classroomPlaceholderImageMediaId,
    subjectPlaceholderImage: valueOrExisting(
      payload,
      "subjectPlaceholderImage",
      existing?.subjectPlaceholderImage,
    ),
    subjectPlaceholderImageMediaId: hasOwn(
      payload as any,
      "subjectPlaceholderImageMediaId",
    )
      ? (payload as any).subjectPlaceholderImageMediaId
      : (existing as any)?.subjectPlaceholderImageMediaId,
    createdAt: existing?.createdAt || payload.createdAt || now,
    updatedAt: now,
    version: Number(existing?.version || 0) + 1,

    synced: "pending" as unknown as SchoolBranchSetting["synced"],
    isDeleted: payload.isDeleted ?? existing?.isDeleted ?? false,
  } as unknown as SchoolBranchSetting;
}

function makeReportTemplatePayload(args: {
  form: ReportTemplateForm;
  accountId: string;
  schoolId: string;
  branchId: string;
  existing?: any;
}) {
  const now = Date.now();
  const existing = args.existing || {};

  return {
    ...existing,
    accountId: args.accountId,
    schoolId: args.schoolId,
    branchId: args.branchId,
    name:
      args.form.templateName?.trim() ||
      defaultReportTemplateDefinition().name ||
      "Classic Formal",
    code:
      args.form.templateCode?.trim() ||
      defaultReportTemplateDefinition().code ||
      "classic_formal",
    layoutKey:
      args.form.layoutKey ||
      defaultReportTemplateDefinition().layoutKey ||
      "classic_formal",
    orientation: args.form.orientation || "portrait",
    paperSize: args.form.paperSize || "A4",
    density: args.form.density || "compact",
    templateKey: args.form.templateCode?.trim() || args.form.layoutKey,
    reportType: args.form.reportType || "student_report",
    description:
      existing.description ||
      (args.form.reportType === "cumulative_book"
        ? "Default configurable cumulative report book template."
        : args.form.reportType === "cumulative_transcript"
          ? "Default configurable cumulative transcript template."
          : args.form.reportType === "subject_broadsheet"
            ? "Default configurable subject broadsheet template."
            : args.form.reportType === "class_broadsheet"
              ? "Default configurable class broadsheet template."
              : args.form.reportType === "annual_broadsheet"
                ? "Default configurable annual broadsheet template."
                : "Default configurable student report card template."),
    active: args.form.active !== false,
    isDefault: true,
    createdAt: existing.createdAt || now,
    updatedAt: now,
    version: Number(existing.version || 0) + 1,
    synced: "pending",
    isDeleted: false,
  };
}

function makeReportTemplateSettingsPayload(args: {
  form: ReportTemplateForm;
  accountId: string;
  schoolId: string;
  branchId: string;
  templateId: string;
  existing?: any;
}) {
  const now = Date.now();
  const existing = args.existing || {};

  return {
    ...existing,
    accountId: args.accountId,
    schoolId: args.schoolId,
    branchId: args.branchId,
    templateId: args.templateId,
    templateCode: args.form.templateCode,
    layoutKey: args.form.layoutKey,
    templateKey: args.form.templateCode,
    templateName: args.form.templateName,
    reportType: args.form.reportType || "student_report",

    orientation: args.form.orientation,
    paperSize: args.form.paperSize,
    density: args.form.density,

    showSubjectPosition: !!args.form.showSubjectPosition,
    showClassPosition: !!args.form.showClassPosition,
    showNumberOnRoll: !!args.form.showNumberOnRoll,
    showAttendance: !!args.form.showAttendance,
    showAttendancePercent: !!args.form.showAttendancePercent,
    showStudentPhoto: !!args.form.showStudentPhoto,
    showTeacherNames: !!args.form.showTeacherNames,
    showCurrentAcademicPeriodEnd: !!args.form.showCurrentAcademicPeriodEnd,
    showNextAcademicPeriod: !!args.form.showNextAcademicPeriod,
    showPromotionStatus: !!args.form.showPromotionStatus,
    showGPA: !!args.form.showGPA,
    showAverage: !!args.form.showAverage,
    showTotal: !!args.form.showTotal,
    showGrade: !!args.form.showGrade,
    showSubjectRemarks: !!args.form.showSubjectRemarks,
    showWatermark: !!args.form.showWatermark,
    showParentSignature: !!args.form.showParentSignature,
    showGeneratedDate: !!args.form.showGeneratedDate,

    showAssessmentBreakdown:
      !!args.form.showAssessmentBreakdown,
    assessmentHierarchyDisplay:
      args.form.assessmentHierarchyDisplay,
    showAssessmentParentItems:
      !!args.form.showAssessmentParentItems,
    showAssessmentChildItems:
      !!args.form.showAssessmentChildItems,
    showCalculatedAssessmentItems:
      !!args.form.showCalculatedAssessmentItems,
    indentAssessmentChildren:
      !!args.form.indentAssessmentChildren,
    showAssessmentGroupHeaders:
      !!args.form.showAssessmentGroupHeaders,
    flattenSingleChildAssessmentGroups:
      !!args.form.flattenSingleChildAssessmentGroups,
    assessmentMaximumVisibleDepth:
      args.form.assessmentMaximumVisibleDepth,
    showAssessmentMaximumScores:
      !!args.form.showAssessmentMaximumScores,
    showAssessmentWeights:
      !!args.form.showAssessmentWeights,
    showAssessmentRawScores:
      !!args.form.showAssessmentRawScores,
    showAssessmentWeightedScores:
      !!args.form.showAssessmentWeightedScores,
    showAssessmentHierarchyPath:
      !!args.form.showAssessmentHierarchyPath,

    broadsheetAssessmentHierarchyDisplay:
      args.form.broadsheetAssessmentHierarchyDisplay,
    broadsheetShowAssessmentGroupHeaders:
      !!args.form.broadsheetShowAssessmentGroupHeaders,
    broadsheetMaximumAssessmentDepth:
      args.form.broadsheetMaximumAssessmentDepth,

    showBookFrontCover: !!args.form.showBookFrontCover,
    showBookStudentProfilePage: !!args.form.showBookStudentProfilePage,
    showBookAcademicJourneyPage: !!args.form.showBookAcademicJourneyPage,
    showBookSummaryPage: !!args.form.showBookSummaryPage,
    showBookBackCover: !!args.form.showBookBackCover,

    showTranscriptTermBreakdown: !!args.form.showTranscriptTermBreakdown,
    showTranscriptYearAverage: !!args.form.showTranscriptYearAverage,
    showTranscriptCumulativeAverage:
      !!args.form.showTranscriptCumulativeAverage,
    showTranscriptCumulativePosition:
      !!args.form.showTranscriptCumulativePosition,
    showTranscriptGPAProgression: !!args.form.showTranscriptGPAProgression,
    showTranscriptFinalRecommendation:
      !!args.form.showTranscriptFinalRecommendation,
    showBroadsheetLogo: !!args.form.showBroadsheetLogo,
    showBroadsheetWatermark: !!args.form.showBroadsheetWatermark,
    showBroadsheetGeneratedDate: !!args.form.showBroadsheetGeneratedDate,
    showBroadsheetPageNumber: !!args.form.showBroadsheetPageNumber,
    showBroadsheetSignatures: !!args.form.showBroadsheetSignatures,
    showBroadsheetSummary: !!args.form.showBroadsheetSummary,
    showBroadsheetStatistics: !!args.form.showBroadsheetStatistics,
    showBroadsheetStudentPhoto: !!args.form.showBroadsheetStudentPhoto,
    showBroadsheetAssessmentBreakdown:
      !!args.form.showBroadsheetAssessmentBreakdown,
    showBroadsheetWeightedTotal: !!args.form.showBroadsheetWeightedTotal,
    showBroadsheetPercentage: !!args.form.showBroadsheetPercentage,
    showBroadsheetGrade: !!args.form.showBroadsheetGrade,
    showBroadsheetRemark: !!args.form.showBroadsheetRemark,
    showBroadsheetGPA: !!args.form.showBroadsheetGPA,
    showBroadsheetPosition: !!args.form.showBroadsheetPosition,
    showBroadsheetHighestScore: !!args.form.showBroadsheetHighestScore,
    showBroadsheetLowestScore: !!args.form.showBroadsheetLowestScore,
    showBroadsheetClassAverage: !!args.form.showBroadsheetClassAverage,
    showBroadsheetSubjectScores: !!args.form.showBroadsheetSubjectScores,
    showBroadsheetSubjectGrades: !!args.form.showBroadsheetSubjectGrades,
    showBroadsheetTotal: !!args.form.showBroadsheetTotal,
    showBroadsheetAverage: !!args.form.showBroadsheetAverage,
    showBroadsheetClassPosition: !!args.form.showBroadsheetClassPosition,
    showBroadsheetAttendance: !!args.form.showBroadsheetAttendance,
    showBroadsheetClassHighestAverage:
      !!args.form.showBroadsheetClassHighestAverage,
    showBroadsheetClassLowestAverage:
      !!args.form.showBroadsheetClassLowestAverage,
    showBroadsheetPeriodScores: !!args.form.showBroadsheetPeriodScores,
    showBroadsheetAnnualAverage: !!args.form.showBroadsheetAnnualAverage,
    showBroadsheetAnnualGPA: !!args.form.showBroadsheetAnnualGPA,
    showBroadsheetAnnualPosition: !!args.form.showBroadsheetAnnualPosition,
    showBroadsheetTrend: !!args.form.showBroadsheetTrend,
    showBroadsheetPromotionDecision:
      !!args.form.showBroadsheetPromotionDecision,
    showBroadsheetBestPeriod: !!args.form.showBroadsheetBestPeriod,
    showBroadsheetLatestPeriod: !!args.form.showBroadsheetLatestPeriod,

    classTeacherLabel: args.form.classTeacherLabel?.trim() || "Class Teacher",
    headTeacherLabel:
      args.form.headTeacherLabel?.trim() || "Headteacher / Principal",
    parentLabel: args.form.parentLabel?.trim() || "Parent / Guardian",
    principalLabel: args.form.principalLabel?.trim() || "Principal",
    currentAcademicPeriodEndLabel:
      args.form.currentAcademicPeriodEndLabel?.trim() ||
      "This Academic Period Ends",
    nextAcademicPeriodLabel:
      args.form.nextAcademicPeriodLabel?.trim() ||
      "Next Academic Period Begins",
    numberOnRollLabel: args.form.numberOnRollLabel?.trim() || "Number On Roll",
    classPositionLabel:
      args.form.classPositionLabel?.trim() || "Class Position",
    subjectPositionLabel: args.form.subjectPositionLabel?.trim() || "Position",
    generatedDateLabel: args.form.generatedDateLabel?.trim() || "Generated",
    bookTitleLabel:
      args.form.bookTitleLabel?.trim() || "Cumulative Academic Report Book",
    bookSubtitleLabel:
      args.form.bookSubtitleLabel?.trim() || "Student Academic Journey",
    studentNameLabel: args.form.studentNameLabel?.trim() || "Student",
    admissionNumberLabel:
      args.form.admissionNumberLabel?.trim() || "Student ID",
    genderLabel: args.form.genderLabel?.trim() || "Gender",
    classLabel: args.form.classLabel?.trim() || "Class",
    academicStructureLabel:
      args.form.academicStructureLabel?.trim() || "Academic Structure",
    academicPeriodLabel:
      args.form.academicPeriodLabel?.trim() || "Academic Period",
    subjectLabel: args.form.subjectLabel?.trim() || "Subject",
    totalLabel: args.form.totalLabel?.trim() || "Total",
    averageLabel: args.form.averageLabel?.trim() || "Average",
    gradeLabel: args.form.gradeLabel?.trim() || "Grade",
    gpaLabel: args.form.gpaLabel?.trim() || "GPA",
    footerText:
      args.form.footerText?.trim() ||
      "Official academic document generated by Eleeveon Schools.",
    broadsheetTitleLabel:
      args.form.broadsheetTitleLabel?.trim() || "Broadsheet",
    broadsheetGeneratedDateLabel:
      args.form.broadsheetGeneratedDateLabel?.trim() || "Generated",
    broadsheetFooterText:
      args.form.broadsheetFooterText?.trim() ||
      "Official academic broadsheet generated by Eleeveon Schools.",
    studentColumnLabel: args.form.studentColumnLabel?.trim() || "Student",
    admissionNumberColumnLabel:
      args.form.admissionNumberColumnLabel?.trim() || "Admission No.",
    positionColumnLabel: args.form.positionColumnLabel?.trim() || "Position",
    gradeColumnLabel: args.form.gradeColumnLabel?.trim() || "Grade",
    remarkColumnLabel: args.form.remarkColumnLabel?.trim() || "Remark",

    active: args.form.active !== false,
    createdAt: existing.createdAt || now,
    updatedAt: now,
    version: Number(existing.version || 0) + 1,
    synced: "pending",
    isDeleted: false,
  };
}

function makeReportTemplateAssignmentPayload(args: {
  form: ReportTemplateForm;
  accountId: string;
  schoolId: string;
  branchId: string;
  templateId: string;
  templateSettingsId: string;
  existing?: any;
}) {
  const now = Date.now();
  const existing = args.existing || {};

  return {
    ...existing,
    accountId: args.accountId,
    schoolId: args.schoolId,
    branchId: args.branchId,
    templateId: args.templateId,
    templateSettingsId: args.templateSettingsId,
    templateCode: args.form.templateCode,
    layoutKey: args.form.layoutKey,
    templateKey: args.form.templateCode,
    reportType: args.form.reportType || "student_report",
    scopeType: "branch",
    scopeId: args.branchId,
    isDefault: true,
    active: args.form.active !== false,
    createdAt: existing.createdAt || now,
    updatedAt: now,
    version: Number(existing.version || 0) + 1,
    synced: "pending",
    isDeleted: false,
  };
}

function assetReady(value: unknown) {
  return !!String(value || "").trim();
}

// Settings has no delete action, but keeping the shared CRUD toolkit import
// makes future soft-delete additions consistent with the other golden modules.
void softDeleteLocal;

// ======================================================
// COMPONENT
// ======================================================

export function BranchSettingsWorkspace({ view = "branch" }: { view?: "branch" | "reports" }) {
  const dataRevision = useDataRevision();

  // Shared branch-scoped resolver used by Classes and Assessment Entries.
  const workspace = useBranchWorkspaceScope();
  const accountContext = useAccount() as any;
  const { accountId, authenticated, loading: accountLoading } = accountContext;

  const {
    settings,
    updateSettings: updateContextSettings,
    loading: settingsLoading,
  } = useSettings();

  const {
    activeSchool,
    activeSchoolId,
    activeBranch,
    activeBranchId,
    loading: contextLoading,
    refreshInstitution,
  } = useActiveBranch() as any;
  const { activeMembership } = useActiveMembership();

  const openWorkspace = useMemo(() => readOpenWorkspaceSession(), []);

  const selectedAccountId = workspace.accountId || accountId || settings?.accountId;
  const selectedSchoolId = workspace.schoolId || selectedWorkspaceSchoolId({
    openWorkspace,
    activeMembership: activeMembership as any,
    activeSchoolId,
    activeSchool: activeSchool as any,
    settings: settings as any,
  });
  const selectedBranchId = workspace.branchId || selectedWorkspaceBranchId({
    openWorkspace,
    activeMembership: activeMembership as any,
    activeBranchId,
    activeBranch: activeBranch as any,
    settings: settings as any,
  });

  const primary = settings?.primaryColor || "var(--primary-color, #2563eb)";

  // ======================================================
  // STATE
  // ======================================================

  const [toast, setToast] = useState<{
    tone: ToastTone;
    message: string;
  } | null>(null);
  const [search, setSearch] = useState("");
  const [viewMode, setViewMode] = useState<SettingsDisplayMode>("cards");
  useEffect(() => {
    if (typeof window !== "undefined") {
      setViewMode(window.matchMedia("(min-width: 900px)").matches ? "table" : "cards");
    }
  }, []);
  const [filterOpen, setFilterOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [sectionOpen, setSectionOpen] = useState<SettingsSection | null>(null);
  const [admissionDraft, setAdmissionDraft] = useState({ mode: "manual" as "manual" | "automatic" | "automatic_or_manual", prefix: "", separator: "-", nextSequence: 1, padding: 3, scope: "branch" as const });
  const [savingAdmission, setSavingAdmission] = useState(false);
  const [hasLoaded, setHasLoaded] = useState(false);
  const loadSequenceRef = useRef(0);


  const [school, setSchool] = useState<School | null>(null);
  const [branch, setBranch] = useState<Branch | null>(null);
  const [academicStructures, setAcademicStructures] = useState<
    AcademicStructure[]
  >([]);
  const [academicPeriods, setAcademicPeriods] = useState<AcademicPeriod[]>([]);
  const [settingsRow, setSettingsRow] = useState<SchoolBranchSetting | null>(
    null,
  );
  useEffect(() => {
    if (!settingsRow) return;
    const cfg = (settingsRow as any).admissionNumbers;
    // If settings rehydration delivers an older row without an admissionNumbers
    // object, never erase a prefix the user is currently editing.
    if (!cfg || typeof cfg !== "object") return;
    setAdmissionDraft({
      mode: cfg?.mode || "manual",
      prefix: cfg?.prefix || "",
      separator: cfg?.separator ?? "-",
      // The browser must never reuse the old saved sequence as an allocation floor.
      nextSequence: 1,
      padding: Math.min(12, Math.max(3, Number(cfg?.padding) || 3)),
      scope: "branch",
    });
  }, [settingsRow]);

  // Do not estimate the authoritative number from browser data.
  // Admission allocations belong to the server registry, not IndexedDB.
  // The backend status is intentionally unavailable until an authenticated
  // server read endpoint is wired into this module.

  const [reportTemplates, setReportTemplates] = useState<ReportTemplateRow[]>(
    [],
  );
  const [reportTemplateSettingsRow, setReportTemplateSettingsRow] =
    useState<ReportTemplateSettingsRow | null>(null);
  const [reportTemplateAssignmentRow, setReportTemplateAssignmentRow] =
    useState<ReportTemplateAssignmentRow | null>(null);
  const [portalHighlights, setPortalHighlights] = useState<PortalHighlightRow[]>([]);
  const [portalHighlightDraft, setPortalHighlightDraft] =
    useState<PortalHighlightDraft>(newPortalHighlightDraft());
  const [savingPortalHighlight, setSavingPortalHighlight] = useState(false);

  const [form, setForm] = useState<SettingsForm>(
    defaultForm(selectedSchoolId, selectedBranchId),
  );
  const [schoolForm, setSchoolForm] = useState<SchoolForm>({});
  const [branchForm, setBranchForm] = useState<BranchForm>({});
  const [reportTemplateForm, setReportTemplateForm] =
    useState<ReportTemplateForm>(defaultReportTemplateForm());

  const { loading, setLoading } = useBackgroundLoader();
  const [savingAll, setSavingAll] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [savingSchool, setSavingSchool] = useState(false);
  const [savingBranch, setSavingBranch] = useState(false);
  const [savingReportTemplate, setSavingReportTemplate] = useState(false);
  const [mediaPreviewUrls, setMediaPreviewUrls] = useState<
    Record<string, string>
  >({});
  const [pendingMediaRemovals, setPendingMediaRemovals] = useState<
    PendingMediaRemoval[]
  >([]);
  const settingsMediaSessionKeyRef = useRef(createSettingsMediaSessionKey());
  const schoolMediaSessionKeyRef = useRef(
    createSharedMediaSessionKey(SCHOOL_MEDIA_OWNER_TABLE),
  );
  const branchMediaSessionKeyRef = useRef(
    createSharedMediaSessionKey(BRANCH_MEDIA_OWNER_TABLE),
  );

  /**
   * Track only media selected during the current edit session. This mirrors
   * Students.tsx and prevents an unchanged saved image from being mistaken for
   * a newly staged upload.
   */
  const uploadedSettingsMediaIdsRef =
    useRef<Partial<Record<ImageField, string>>>({});

  /**
   * Gallery uploads create mediaAssets immediately, which increments the shared
   * data revision before the settings row is saved. Keep their IDs separately
   * so the automatic reload cannot discard unsaved gallery selections.
   */
  const stagedGalleryMediaIdsRef = useRef<Set<string>>(new Set());

  const uploadedSchoolMediaIdsRef =
    useRef<Record<string, string>>({});

  const uploadedBranchMediaIdsRef =
    useRef<Record<string, string>>({});

  // ======================================================
  // TENANT HELPERS
  // ======================================================

  const sameTenant = (row: TenantRow) =>
    (!row.accountId || row.accountId === selectedAccountId) &&
    (!row.schoolId || sameId(row.schoolId, selectedSchoolId)) &&
    (!row.branchId || sameId(row.branchId, selectedBranchId)) &&
    !row.isDeleted;

  const showToast = (tone: ToastTone, message: string) => {
    setToast({ tone, message });
    window.setTimeout(() => {
      setToast((current) => (current?.message === message ? null : current));
    }, 4500);
  };

  const clearData = () => {
    Object.values(mediaPreviewUrls).forEach(revokeMediaObjectUrl);
    setMediaPreviewUrls({});
    setSchool(null);
    setBranch(null);
    setSettingsRow(null);
    setReportTemplates([]);
    setReportTemplateSettingsRow(null);
    setReportTemplateAssignmentRow(null);
    setAcademicStructures([]);
    setAcademicPeriods([]);
    setSchoolForm({});
    setBranchForm({});
    setReportTemplateForm(defaultReportTemplateForm());
    setPendingMediaRemovals([]);
    stagedGalleryMediaIdsRef.current.clear();
    setForm(defaultForm(selectedSchoolId, selectedBranchId));
  };

  /**
   * Resolve media through the same shared owner-aware path used by Students.
   *
   * resolveOwnerMediaUrl checks:
   * - the committed ownerTable + ownerId + fieldKey relationship;
   * - the explicit media ID stored on the owner record;
   * - local mediaBlobs for offline display;
   * - remote/public/storage/download URLs after synchronization.
   *
   * This is important on a second device, where mediaBlobs do not exist and
   * only the synchronized remote URL is available.
   */
  const resolveOwnedAssetUrl = async ({
    ownerTable,
    ownerId,
    fieldKey,
    fallbackMediaId,
  }: {
    ownerTable: string;
    ownerId?: string | null;
    fieldKey: string;
    fallbackMediaId?: string | null;
  }) => {
    const ownerIdValue = cleanId(ownerId);
    const fallbackAssetId = cleanId(fallbackMediaId);

    if (!ownerIdValue && !fallbackAssetId) {
      return "";
    }

    try {
      return (
        (await resolveOwnerMediaUrl({
          accountId:
            cleanId(selectedAccountId) ||
            undefined,
          ownerTable,
          ownerId:
            ownerIdValue ||
            undefined,
          fieldKey,
          fallbackAssetId:
            fallbackAssetId ||
            undefined,
        })) || ""
      );
    } catch (error) {
      console.error(
        "Failed to resolve branch-settings media:",
        {
          ownerTable,
          ownerId:
            ownerIdValue ||
            null,
          fieldKey,
          fallbackAssetId:
            fallbackAssetId ||
            null,
          error,
        },
      );

      return "";
    }
  };

  const resolveBranchSettingsMedia = async ({
    currentSchool,
    currentBranch,
    currentSetting,
  }: {
    currentSchool?: School | null;
    currentBranch?: Branch | null;
    currentSetting?: SchoolBranchSetting | null;
  }) => {
    const next: Record<string, string> = {};

    const resolveAndPut = async (
      ownerTable: string,
      ownerId: string | string | null | undefined,

      fieldKey: string,
      fallbackMediaId?: string | string | null,
    ) => {
      const ownerIdValue = cleanId(ownerId);
      if (!ownerIdValue) return "";

      const url = await resolveOwnedAssetUrl({
        ownerTable,
        ownerId: ownerIdValue,

        fieldKey,
        fallbackMediaId,
      });

      if (url) next[assetPreviewKey(ownerTable, ownerIdValue, fieldKey)] = url;
      return url;
    };

    const schoolIdValue = idOf((currentSchool as any)?.id);
    const branchIdValue = idOf((currentBranch as any)?.id);
    const settingIdValue = idOf((currentSetting as any)?.id);

    const schoolLogoUrl = await resolveAndPut(
      SCHOOL_MEDIA_OWNER_TABLE,
      schoolIdValue,
      "logo",
      (currentSchool as any)?.logoMediaId,
    );
    const schoolBannerUrl = await resolveAndPut(
      SCHOOL_MEDIA_OWNER_TABLE,
      schoolIdValue,
      "bannerImage",
      (currentSchool as any)?.bannerImageMediaId,
    );

    const branchLogoUrl = await resolveAndPut(
      BRANCH_MEDIA_OWNER_TABLE,
      branchIdValue,
      "logo",
      (currentBranch as any)?.logoMediaId,
    );
    const branchBannerUrl = await resolveAndPut(
      BRANCH_MEDIA_OWNER_TABLE,
      branchIdValue,
      "bannerImage",
      (currentBranch as any)?.bannerImageMediaId,
    );

    const settingUrls: Partial<Record<ImageField, string>> = {};
    for (const field of [
      "logo",
      "reportCardBackgroundImage",
      "reportCardWatermark",
      "reportCardSignatureImage",
      "dashboardHeroImage",
      "dashboardBannerImage",
      "studentPortalImage",
      "teacherPortalImage",
      "classroomPlaceholderImage",
      "subjectPlaceholderImage",
    ] as ImageField[]) {
      const url = await resolveAndPut(
        SETTINGS_MEDIA_OWNER_TABLE,
        settingIdValue,
        field,
        (currentSetting as any)?.[mediaIdFieldFor(field)],
      );
      if (url) settingUrls[field] = url;
    }



    return {
      schoolLogoUrl,
      schoolBannerUrl,
      branchLogoUrl,
      branchBannerUrl,
      settingUrls,
    };
  };

  // ======================================================
  // LOAD DATA
  // ======================================================

  const load = async () => {
    const loadSequence = ++loadSequenceRef.current;
    if (
      !authenticated ||
      !selectedAccountId ||
      !selectedSchoolId ||
      !selectedBranchId
    ) {
      clearData();
      setLoading(false);
      setHasLoaded(true);
      return;
    }

    try {
      if (!hasLoaded) setLoading(true);

      const [
        schoolRows,
        branchRows,
        settingRows,
        structureRows,
        periodRows,
        reportTemplateRows,
        reportTemplateSettingsRows,
        reportTemplateAssignmentRows,
      ] = await Promise.all([
        db.schools.toArray(),
        db.branches.toArray(),
        db.schoolBranchSettings.toArray(),
        listActiveLocal("academicStructures", {
          accountId: selectedAccountId,
          schoolId: cleanId(selectedSchoolId) || undefined,
          branchId: cleanId(selectedBranchId) || undefined,
        } as any),
        listActiveLocal("academicPeriods", {
          accountId: selectedAccountId,
          schoolId: cleanId(selectedSchoolId) || undefined,
          branchId: cleanId(selectedBranchId) || undefined,
        } as any),
        (db as any).reportCardTemplates?.toArray?.() || [],
        (db as any).reportCardTemplateSettings?.toArray?.() || [],
        (db as any).reportCardTemplateAssignments?.toArray?.() || [],
      ]);

      if (loadSequence !== loadSequenceRef.current) return;

      const currentSchool =
        schoolRows.find(
          (row: any) =>
            row.accountId === selectedAccountId &&
            sameId(row.id, selectedSchoolId) &&
            !row.isDeleted,
        ) ||
        schoolRows.find(
          (row: any) => sameId(row.id, selectedSchoolId) && !row.isDeleted,
        ) ||
        null;

      const currentBranch =
        branchRows.find(
          (row: any) =>
            row.accountId === selectedAccountId &&
            sameId(row.schoolId, selectedSchoolId) &&
            sameId(row.id, selectedBranchId) &&
            !row.isDeleted,
        ) ||
        branchRows.find(
          (row: any) =>
            sameId(row.schoolId, selectedSchoolId) &&
            sameId(row.id, selectedBranchId) &&
            !row.isDeleted,
        ) ||
        null;

      // A loose tenant match can select account-wide or another branch's row.
      // Always select the exact school + branch record; use newest on duplicates.
      const currentSetting = settingRows
        .filter((row: any) =>
          !row.isDeleted &&
          (!row.accountId || sameId(row.accountId, selectedAccountId)) &&
          sameId(row.schoolId, selectedSchoolId) &&
          sameId(row.branchId, selectedBranchId),
        )
        .sort((a: any, b: any) =>
          Number(b.updatedAt || 0) - Number(a.updatedAt || 0),
        )[0] || null;

      const dbReportTemplates = (
        reportTemplateRows as ReportTemplateRow[]
      ).filter((row: any) => {
        if (row.isDeleted || row.active === false) return false;
        if (row.accountId && row.accountId !== selectedAccountId) return false;
        if (row.schoolId && !sameId(row.schoolId, selectedSchoolId))
          return false;
        if (row.branchId && !sameId(row.branchId, selectedBranchId))
          return false;
        return true;
      });

      const templateMap = new Map<string, ReportTemplateRow>();

      reportTemplateDefinitionOptions().forEach((template) => {
        const baseKey = String(
          template.code || template.layoutKey || template.name || "",
        ).trim();
        const reportTypeKey = String(template.reportType || "student_report");
        const key = baseKey ? `${reportTypeKey}:${baseKey}` : "";
        if (key) templateMap.set(key, template);
      });

      dbReportTemplates.forEach((template) => {
        const baseKey = String(
          template.code ||
            template.layoutKey ||
            template.name ||
            template.id ||
            "",
        ).trim();
        const reportTypeKey = String(template.reportType || "student_report");
        const key = baseKey ? `${reportTypeKey}:${baseKey}` : "";
        if (key) {
          templateMap.set(key, {
            ...(templateMap.get(key) || {}),
            ...template,
            reportType:
              (template as any).reportType ||
              (templateMap.get(key) as any)?.reportType ||
              "student_report",
          });
        }
      });

      const branchReportTemplates = Array.from(templateMap.values())
        .filter((row: any) => row.active !== false && !row.isDeleted)
        .sort((a: any, b: any) => {
          if (a.isDefault && !b.isDefault) return -1;
          if (!a.isDefault && b.isDefault) return 1;
          return String(a.name || "").localeCompare(String(b.name || ""));
        });

      const defaultReportTemplate =
        branchReportTemplates.find((row: any) => row.isDefault) ||
        branchReportTemplates.find(
          (row: any) =>
            String(row.code || "") === defaultReportTemplateDefinition().code,
        ) ||
        branchReportTemplates[0] ||
        defaultReportTemplateDefinition();

      const currentReportAssignment =
        (reportTemplateAssignmentRows as ReportTemplateAssignmentRow[]).find(
          (row: any) =>
            sameTenant(row) &&
            row.active !== false &&
            (row.reportType === "student_report" || !row.reportType) &&
            row.isDefault === true &&
            (!row.scopeType || row.scopeType === "branch"),
        ) ||
        (reportTemplateAssignmentRows as ReportTemplateAssignmentRow[]).find(
          (row: any) =>
            sameTenant(row) &&
            row.active !== false &&
            (row.reportType === "student_report" || !row.reportType),
        ) ||
        null;

      const assignedTemplateId =
        idOf(currentReportAssignment?.templateId) ||
        idOf(defaultReportTemplate?.id);

      const assignedTemplateCode = String(
        (currentReportAssignment as any)?.templateCode || "",
      ).trim();

      const currentReportTemplate =
        branchReportTemplates.find(
          (row: any) =>
            Boolean(assignedTemplateId) && sameId(row.id, assignedTemplateId),
        ) ||
        branchReportTemplates.find(
          (row: any) =>
            assignedTemplateCode && sameId(row.code, assignedTemplateCode),
        ) ||
        defaultReportTemplate;

      const assignedSettingsId = idOf(
        currentReportAssignment?.templateSettingsId,
      );

      const currentReportTemplateSettings =
        (reportTemplateSettingsRows as ReportTemplateSettingsRow[]).find(
          (row: any) =>
            sameTenant(row) &&
            row.active !== false &&
            (row.reportType === "student_report" || !row.reportType) &&
            Boolean(assignedSettingsId) &&
            sameId(row.id, assignedSettingsId),
        ) ||
        (reportTemplateSettingsRows as ReportTemplateSettingsRow[]).find(
          (row: any) =>
            sameTenant(row) &&
            row.active !== false &&
            (row.reportType === "student_report" || !row.reportType) &&
            currentReportTemplate?.id &&
            sameId(row.templateId, currentReportTemplate.id),
        ) ||
        (reportTemplateSettingsRows as ReportTemplateSettingsRow[]).find(
          (row: any) =>
            sameTenant(row) &&
            row.active !== false &&
            (row.reportType === "student_report" || !row.reportType),
        ) ||
        null;

      const branchStructures = structureRows
        .filter((row: any) => sameTenant(row))
        .filter((row: any) => row.active !== false)
        .sort((a, b) =>
          String(a.name || "").localeCompare(String(b.name || "")),
        );

      const branchPeriods = periodRows
        .filter((row: any) => sameTenant(row))
        .filter((row: any) => row.active !== false)
        .sort((a: any, b: any) => Number(a.order || 0) - Number(b.order || 0));

      // Media blobs can be unavailable offline or indefinitely slow. Never block
      // the settings form itself on thumbnails, logos or signed asset URLs.
      const mediaFallback = {
        schoolLogoUrl: "", schoolBannerUrl: "",
        branchLogoUrl: "", branchBannerUrl: "",
        settingUrls: {} as Record<string, string>,
      };
      const mediaUrls = await Promise.race([
        resolveBranchSettingsMedia({ currentSchool, currentBranch, currentSetting })
          .catch((error) => {
            console.warn("Branch settings media could not be resolved:", error);
            return mediaFallback;
          }),
        new Promise<typeof mediaFallback>((resolve) =>
          setTimeout(() => resolve(mediaFallback), 4500),
        ),
      ]);
      if (loadSequence !== loadSequenceRef.current) return;

      setSchool(currentSchool);
      setBranch(currentBranch);
      setSettingsRow(currentSetting);
      // Some branches have duplicate settings rows. Read admission rules
      // from the matching configured row, even if the newest settings row
      // has no admissionNumbers object (as observed in the USOH account).
      const admissionSettingsRow = settingRows
        .filter((row: any) =>
          !row.isDeleted &&
          (!row.accountId || sameId(row.accountId, selectedAccountId)) &&
          sameId(row.schoolId, selectedSchoolId) &&
          sameId(row.branchId, selectedBranchId) &&
          !!row.admissionNumbers,
        )
        .sort((a: any, b: any) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0))[0];
      const savedAdmissionRules = (admissionSettingsRow as any)?.admissionNumbers;
      if (savedAdmissionRules) {
        setAdmissionDraft({
          mode: savedAdmissionRules.mode || "manual",
          prefix: savedAdmissionRules.prefix || "",
          separator: savedAdmissionRules.separator ?? "-",
          padding: Math.min(12, Math.max(3, Number(savedAdmissionRules.padding) || 3)),
          nextSequence: 1,
          scope: "branch",
        });
      }
      setReportTemplates(branchReportTemplates);
      setReportTemplateSettingsRow(currentReportTemplateSettings);
      setReportTemplateAssignmentRow(currentReportAssignment);
      setAcademicStructures(branchStructures);
      setAcademicPeriods(branchPeriods);

      setSchoolForm({
        id: currentSchool?.id,
        name: currentSchool?.name || "",
        motto: currentSchool?.motto || "",
        logo:
          mediaUrls.schoolLogoUrl ||
          safeRecordMediaValue(currentSchool?.logo || currentSchool?.photo) ||
          "",
        logoMediaId: (currentSchool as any)?.logoMediaId,
        address: currentSchool?.address || "",
        location: (currentSchool as any)?.location || "",
        email: currentSchool?.email || "",
        phone: currentSchool?.phone || "",
        website: currentSchool?.website || "",
        galleryImages: Array.isArray(currentSchool?.galleryImages)
          ? currentSchool.galleryImages
          : [],
        bannerImage:
          mediaUrls.schoolBannerUrl ||
          safeRecordMediaValue(currentSchool?.bannerImage) ||
          "",
        bannerImageMediaId: (currentSchool as any)?.bannerImageMediaId,
        active: (currentSchool as any)?.active !== false,
      });

      setBranchForm({
        id: currentBranch?.id,
        schoolId: currentBranch?.schoolId,
        name: currentBranch?.name || "",
        code: currentBranch?.code || "",
        address: currentBranch?.address || "",
        location: (currentBranch as any)?.location || currentBranch?.city || "",
        city: currentBranch?.city || "",
        email: currentBranch?.email || "",
        phone: currentBranch?.phone || "",
        website: (currentBranch as any)?.website || "",
        logo:
          mediaUrls.branchLogoUrl ||
          safeRecordMediaValue(currentBranch?.logo || currentBranch?.photo) ||
          "",
        logoMediaId: (currentBranch as any)?.logoMediaId,
        bannerImage:
          mediaUrls.branchBannerUrl ||
          safeRecordMediaValue(currentBranch?.bannerImage) ||
          "",
        bannerImageMediaId: (currentBranch as any)?.bannerImageMediaId,
        active: currentBranch?.active !== false,
      });

      setForm({
        ...defaultForm(selectedSchoolId, selectedBranchId),
        ...(currentSetting || {}),
        id: currentSetting?.id,
        schoolId: selectedSchoolId,
        branchId: selectedBranchId,
        fontSize: Number((currentSetting as any)?.fontSize || 16),
        fontFamily:
          (currentSetting as any)?.fontFamily ||
          "system-ui, -apple-system, sans-serif",
        primaryColor:
          (currentSetting as any)?.primaryColor ||
          settings?.primaryColor ||
          "#2f6fed",
        theme: ((currentSetting as any)?.theme || "light") as "light" | "dark",
        mode: (currentSetting as any)?.mode || "manual",
        currentTerm: (currentSetting as any)?.currentTerm || "Term 1",
        academicYear: (currentSetting as any)?.academicYear || "",
        currentAcademicStructureId:
          (currentSetting as any)?.currentAcademicStructureId || undefined,
        currentAcademicPeriodId:
          (currentSetting as any)?.currentAcademicPeriodId || undefined,
        logo:
          mediaUrls.settingUrls.logo ||
          safeRecordMediaValue((currentSetting as any)?.logo) ||
          "",
        logoMediaId: (currentSetting as any)?.logoMediaId,
        reportCardBackgroundImage:
          mediaUrls.settingUrls.reportCardBackgroundImage ||
          safeRecordMediaValue(
            (currentSetting as any)?.reportCardBackgroundImage,
          ) ||
          "",
        reportCardBackgroundImageMediaId: (currentSetting as any)
          ?.reportCardBackgroundImageMediaId,
        reportCardWatermark:
          mediaUrls.settingUrls.reportCardWatermark ||
          safeRecordMediaValue((currentSetting as any)?.reportCardWatermark) ||
          "",
        reportCardWatermarkMediaId: (currentSetting as any)
          ?.reportCardWatermarkMediaId,
        reportCardSignatureImage:
          mediaUrls.settingUrls.reportCardSignatureImage ||
          safeRecordMediaValue(
            (currentSetting as any)?.reportCardSignatureImage,
          ) ||
          "",
        reportCardSignatureImageMediaId: (currentSetting as any)
          ?.reportCardSignatureImageMediaId,
        dashboardHeroImage:
          mediaUrls.settingUrls.dashboardHeroImage ||
          safeRecordMediaValue((currentSetting as any)?.dashboardHeroImage) ||
          "",
        dashboardHeroImageMediaId: (currentSetting as any)
          ?.dashboardHeroImageMediaId,
        dashboardBannerImage:
          mediaUrls.settingUrls.dashboardBannerImage ||
          safeRecordMediaValue((currentSetting as any)?.dashboardBannerImage) ||
          "",
        dashboardBannerImageMediaId: (currentSetting as any)
          ?.dashboardBannerImageMediaId,
        studentPortalImage:
          mediaUrls.settingUrls.studentPortalImage ||
          safeRecordMediaValue((currentSetting as any)?.studentPortalImage) ||
          "",
        studentPortalImageMediaId: (currentSetting as any)
          ?.studentPortalImageMediaId,
        teacherPortalImage:
          mediaUrls.settingUrls.teacherPortalImage ||
          safeRecordMediaValue((currentSetting as any)?.teacherPortalImage) ||
          "",
        teacherPortalImageMediaId: (currentSetting as any)
          ?.teacherPortalImageMediaId,
        classroomPlaceholderImage:
          mediaUrls.settingUrls.classroomPlaceholderImage ||
          safeRecordMediaValue(
            (currentSetting as any)?.classroomPlaceholderImage,
          ) ||
          "",
        classroomPlaceholderImageMediaId: (currentSetting as any)
          ?.classroomPlaceholderImageMediaId,
        subjectPlaceholderImage:
          mediaUrls.settingUrls.subjectPlaceholderImage ||
          safeRecordMediaValue(
            (currentSetting as any)?.subjectPlaceholderImage,
          ) ||
          "",
        subjectPlaceholderImageMediaId: (currentSetting as any)
          ?.subjectPlaceholderImageMediaId,
      });

      setReportTemplateForm({
        ...defaultReportTemplateForm(),
        ...(currentReportTemplateSettings || {}),
        templateId: idOf(currentReportTemplate?.id) || undefined,
        templateSettingsId:
          idOf(currentReportTemplateSettings?.id) || undefined,
        assignmentId: idOf(currentReportAssignment?.id) || undefined,
        reportType: "student_report",
        templateName:
          currentReportTemplate?.name ||
          currentReportTemplateSettings?.templateName ||
          defaultReportTemplateDefinition().name ||
          "Classic Formal",
        templateCode:
          currentReportTemplate?.code ||
          currentReportTemplateSettings?.templateCode ||
          defaultReportTemplateDefinition().code ||
          "classic_formal",
        layoutKey:
          currentReportTemplate?.layoutKey ||
          currentReportTemplateSettings?.layoutKey ||
          defaultReportTemplateDefinition().layoutKey ||
          "classic_formal",
        orientation: (currentReportTemplateSettings?.orientation ||
          currentReportTemplate?.orientation ||
          "portrait") as "portrait" | "landscape",
        paperSize: (currentReportTemplateSettings?.paperSize ||
          currentReportTemplate?.paperSize ||
          "A4") as "A4" | "Letter",
        density: (currentReportTemplateSettings?.density ||
          currentReportTemplate?.density ||
          "compact") as "compact" | "comfortable" | "spacious",
      });
    } catch (error) {
      if (loadSequence === loadSequenceRef.current) {
        console.error("Failed to load branch settings:", error);
        // Keep the last known settings and unsaved input on transient Dexie failures.
        showToast("error", "Could not refresh settings. Your current values are retained.");
      }
    } finally {
      if (loadSequence === loadSequenceRef.current) {
        setLoading(false);
        setHasLoaded(true);
      }
    }
  };

  useEffect(() => {
    if (accountLoading || contextLoading || !authenticated) return;
    // Autosync and media updates must not replace a draft in an open editor.
    if (sectionOpen !== null || filterOpen || moreOpen || savingAll ||
        savingSettings || savingSchool || savingBranch || savingReportTemplate || savingAdmission) return;
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    authenticated,
    selectedAccountId,
    selectedSchoolId,
    selectedBranchId,
    accountLoading,
    settingsLoading,
    contextLoading,
    dataRevision,
    sectionOpen,
    filterOpen,
    moreOpen,
    savingAll,
    savingSettings,
    savingSchool,
    savingBranch,
    savingReportTemplate,
    savingAdmission,
  ]);

  useEffect(() => {
    return () => {
      Object.values(mediaPreviewUrls).forEach(revokeMediaObjectUrl);
    };
  }, [mediaPreviewUrls]);

  // ======================================================
  // DERIVED DATA
  // ======================================================

  const filteredAcademicStructures = useMemo(() => {
    return academicStructures
      .filter((structure: any) => sameId(structure.branchId, selectedBranchId))
      .sort((a, b) => String(a.name || "").localeCompare(String(b.name || "")));
  }, [academicStructures, selectedBranchId]);

  const filteredAcademicPeriods = useMemo(() => {
    return academicPeriods
      .filter((period: any) => {
        if (!selectedBranchId) return false;
        if (!sameId(period.branchId, selectedBranchId)) return false;
        if (period.active === false) return false;
        if (
          form.currentAcademicStructureId &&
          !sameId(period.academicStructureId, form.currentAcademicStructureId)
        ) {
          return false;
        }
        return true;
      })
      .sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
  }, [academicPeriods, selectedBranchId, form.currentAcademicStructureId]);

  const activeStructure = useMemo(() => {
    return filteredAcademicStructures.find((row: any) =>
      sameId(row.id, form.currentAcademicStructureId),
    );
  }, [filteredAcademicStructures, form.currentAcademicStructureId]);

  const activePeriod = useMemo(() => {
    return filteredAcademicPeriods.find((row: any) =>
      sameId(row.id, form.currentAcademicPeriodId),
    );
  }, [filteredAcademicPeriods, form.currentAcademicPeriodId]);

  const assetCount =
    [
      schoolForm.logo,
      schoolForm.bannerImage,
      branchForm.logo,
      branchForm.bannerImage,
      form.logo,
      form.dashboardHeroImage,
      form.dashboardBannerImage,
      form.studentPortalImage,
      form.teacherPortalImage,
      form.classroomPlaceholderImage,
      form.subjectPlaceholderImage,
      form.reportCardBackgroundImage,
      form.reportCardWatermark,
      form.reportCardSignatureImage,
    ].filter(Boolean).length +
    portalHighlights.filter(
      (row) =>
        row.active !== false &&
        row.placement === "gallery",
    ).length;

  const completion = useMemo(() => {
    const checks = [
      !!school?.name,
      !!branch?.name,
      !!form.academicYear,
      !!form.currentTerm,
      !!form.currentAcademicStructureId,
      !!form.currentAcademicPeriodId,
      !!form.primaryColor,
      !!form.logo || !!schoolForm.logo || !!branchForm.logo,
      !!form.dashboardHeroImage,
      !!form.reportCardSignatureImage,
    ];

    return Math.round((checks.filter(Boolean).length / checks.length) * 100);
  }, [school, branch, form, schoolForm.logo, branchForm.logo]);

  // ======================================================
  // FIELD HELPERS
  // ======================================================

  const updateForm = (key: keyof SettingsForm, value: any) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const updateSchoolField = (key: keyof SchoolForm, value: any) => {
    setSchoolForm((prev) => ({ ...prev, [key]: value }));
  };

  const updateBranchField = (key: keyof BranchForm, value: any) => {
    setBranchForm((prev) => ({ ...prev, [key]: value }));
  };

  const updateReportTemplateField = (
    key: keyof ReportTemplateForm,
    value: any,
  ) => {
    setReportTemplateForm((prev) => ({ ...prev, [key]: value }));
  };

  const queueMediaRemoval = (removal: PendingMediaRemoval) => {
    const normalized = createPendingRemoval({
      ...removal,
      accountId: removal.accountId || selectedAccountId || null,
      schoolId: removal.schoolId || selectedSchoolId || null,
      branchId: removal.branchId || selectedBranchId || null,
    });

    if (
      !normalized.assetId &&
      !normalized.ownerId &&
      !normalized.ownerTempKey
    ) {
      return;
    }

    setPendingMediaRemovals((current) => {
      const exists = current.some(
        (item) =>
          idOf(item.assetId) === idOf(normalized.assetId) &&
          item.ownerTable === normalized.ownerTable &&
          item.fieldKey === normalized.fieldKey &&
          sameId(item.ownerId, normalized.ownerId) &&
          sameId(item.ownerTempKey, normalized.ownerTempKey),
      );

      return exists ? current : [...current, normalized];
    });
  };

  const clearSettingsImage = (field: ImageField) => {
    delete uploadedSettingsMediaIdsRef.current[field];

    const mediaField = mediaIdFieldFor(field);
    const assetId = idOf(form[mediaField]);
    const ownerId = settingsRow?.id || form.id || undefined;

    queueMediaRemoval(
      createPendingRemoval({
        assetId,
        ownerTable: SETTINGS_MEDIA_OWNER_TABLE,
        fieldKey: field,
        accountId: selectedAccountId,
        schoolId: selectedSchoolId,
        branchId: selectedBranchId,
        ownerId,
        ownerTempKey: ownerId ? null : settingsMediaSessionKeyRef.current,
      }),
    );

    setForm((prev) => ({
      ...prev,
      [field]: "",
      [mediaField]: null as any,
    }));
  };

  const clearSchoolImage = (field: keyof SchoolForm) => {
    delete uploadedSchoolMediaIdsRef.current[String(field)];

    const mediaField = schoolMediaIdFieldFor(field);
    const assetId = idOf((schoolForm as any)[mediaField]);

    queueMediaRemoval(
      createPendingRemoval({
        assetId,
        ownerTable: SCHOOL_MEDIA_OWNER_TABLE,
        fieldKey: String(field),
        accountId: selectedAccountId,
        schoolId: selectedSchoolId,
        branchId: selectedBranchId,
        ownerId: schoolForm.id,
      }),
    );

    setSchoolForm((prev) => ({
      ...prev,
      [field]: "",
      [mediaField]: null as any,
    }));
  };

  const clearBranchImage = (field: keyof BranchForm) => {
    delete uploadedBranchMediaIdsRef.current[String(field)];

    const mediaField = branchMediaIdFieldFor(field);
    const assetId = idOf((branchForm as any)[mediaField]);

    queueMediaRemoval(
      createPendingRemoval({
        assetId,
        ownerTable: BRANCH_MEDIA_OWNER_TABLE,
        fieldKey: String(field),
        accountId: selectedAccountId,
        schoolId: selectedSchoolId,
        branchId: selectedBranchId,
        ownerId: branchForm.id,
      }),
    );

    setBranchForm((prev) => ({
      ...prev,
      [field]: "",
      [mediaField]: null as any,
    }));
  };

  const uploadImage = async (field: ImageField, file?: File) => {
    if (!file) return;
    if (!requireTenant()) return;

    try {
      /*
       * Always stage under the current form session. This is the same safety
       * model used by Students.tsx: the currently committed image remains
       * untouched until the user presses Save.
       */
      const result = await saveImageAsset(file, {
        accountId: selectedAccountId,
        schoolId: cleanId(selectedSchoolId) || undefined,
        branchId: cleanId(selectedBranchId) || undefined,
        ownerTable: SETTINGS_MEDIA_OWNER_TABLE,
        ownerId: undefined,
        ownerTempKey: settingsMediaSessionKeyRef.current,
        fieldKey: field,
        variant:
          field === "logo"
            ? "logo"
            : field === "reportCardSignatureImage"
              ? "signature"
              : "cover",
        replaceExisting: true,
      });

      const uploadedAssetId = cleanId(result.assetId);

      if (!uploadedAssetId) {
        throw new Error(
          "The image was processed but no media asset ID was created.",
        );
      }

      uploadedSettingsMediaIdsRef.current = {
        ...uploadedSettingsMediaIdsRef.current,
        [field]: uploadedAssetId,
      };

      updateForm(field, result.previewUrl);
      updateForm(mediaIdFieldFor(field), uploadedAssetId);
      setPendingMediaRemovals((current) =>
        current.filter(
          (item) =>
            item.assetId !== result.assetId ||
            item.ownerTable !== SETTINGS_MEDIA_OWNER_TABLE ||
            item.fieldKey !== field,
        ),
      );
      showToast(
        "info",
        "Image prepared locally. Click Save to attach and verify it.",
      );
    } catch (error: any) {
      console.error("Failed to process settings image:", error);
      showToast("error", error?.message || "Failed to process image.");
    }
  };

  const uploadSchoolImage = async (field: keyof SchoolForm, file?: File) => {
    if (!file) return;
    if (!selectedAccountId || !selectedSchoolId || !schoolForm.id) {
      showToast(
        "error",
        "Assigned school record is required before uploading media.",
      );
      return;
    }

    try {
      const result = await saveImageAsset(file, {
        accountId: selectedAccountId,
        schoolId: cleanId(selectedSchoolId) || undefined,
        branchId: selectedBranchId ? String(selectedBranchId) : undefined,
        ownerTable: SCHOOL_MEDIA_OWNER_TABLE,
        ownerId: undefined,
        ownerTempKey: schoolMediaSessionKeyRef.current,
        fieldKey: String(field),
        variant: String(field).toLowerCase().includes("logo")
          ? "logo"
          : "cover",
        replaceExisting: true,
      });

      const uploadedAssetId = cleanId(result.assetId);

      if (!uploadedAssetId) {
        throw new Error(
          "The school image was processed but no media asset ID was created.",
        );
      }

      uploadedSchoolMediaIdsRef.current = {
        ...uploadedSchoolMediaIdsRef.current,
        [String(field)]: uploadedAssetId,
      };

      updateSchoolField(field, result.previewUrl);
      updateSchoolField(schoolMediaIdFieldFor(field), uploadedAssetId);
      setPendingMediaRemovals((current) =>
        current.filter(
          (item) =>
            item.assetId !== result.assetId ||
            item.ownerTable !== SCHOOL_MEDIA_OWNER_TABLE ||
            item.fieldKey !== String(field),
        ),
      );
      showToast(
        "info",
        "School image prepared locally. Click Save to attach and verify it.",
      );
    } catch (error: any) {
      console.error("Failed to process school image:", error);
      showToast("error", error?.message || "Failed to process image.");
    }
  };

  const uploadBranchImage = async (field: keyof BranchForm, file?: File) => {
    if (!file) return;
    if (
      !selectedAccountId ||
      !selectedSchoolId ||
      !selectedBranchId ||
      !branchForm.id
    ) {
      showToast(
        "error",
        "Assigned branch record is required before uploading media.",
      );
      return;
    }

    try {
      const result = await saveImageAsset(file, {
        accountId: selectedAccountId,
        schoolId: cleanId(selectedSchoolId) || undefined,
        branchId: cleanId(selectedBranchId) || undefined,
        ownerTable: BRANCH_MEDIA_OWNER_TABLE,
        ownerId: undefined,
        ownerTempKey: branchMediaSessionKeyRef.current,
        fieldKey: String(field),
        variant: String(field).toLowerCase().includes("logo")
          ? "avatar"
          : "cover",
        replaceExisting: true,
      });

      const uploadedAssetId = cleanId(result.assetId);

      if (!uploadedAssetId) {
        throw new Error(
          "The branch image was processed but no media asset ID was created.",
        );
      }

      uploadedBranchMediaIdsRef.current = {
        ...uploadedBranchMediaIdsRef.current,
        [String(field)]: uploadedAssetId,
      };

      updateBranchField(field, result.previewUrl);
      updateBranchField(branchMediaIdFieldFor(field), uploadedAssetId);
      setPendingMediaRemovals((current) =>
        current.filter(
          (item) =>
            item.assetId !== result.assetId ||
            item.ownerTable !== BRANCH_MEDIA_OWNER_TABLE ||
            item.fieldKey !== String(field),
        ),
      );
      showToast(
        "info",
        "Branch image prepared locally. Click Save to attach and verify it.",
      );
    } catch (error: any) {
      console.error("Failed to process branch image:", error);
      showToast("error", error?.message || "Failed to process image.");
    }
  };


  const persistPendingMediaRemovals = async () => {
    const removals = pendingMediaRemovals.filter(
      (item) =>
        isPositiveMediaId(item.assetId) ||
        idOf(item.ownerId) ||
        item.ownerTempKey ||
        item.ownerId,
    );

    if (!removals.length) return;

    const now = Date.now();
    const allAssets = await (db as any).mediaAssets?.toArray?.();

    const sameOptionalNumber = (a: unknown, b: unknown) => {
      if (!idOf(a) || !idOf(b)) return true;
      return sameId(a, b);
    };

    const sameOptionalString = (a: unknown, b: unknown) => {
      if (!String(a || "") || !String(b || "")) return true;
      return sameId(a, b);
    };

    const assetsToDelete = new Map<string, any>();

    for (const removal of removals) {
      if (isPositiveMediaId(removal.assetId)) {
        const asset = await (db as any).mediaAssets?.get?.(
          String(removal.assetId),
        );
        if (asset?.id) assetsToDelete.set(String(asset.id), asset);
      }

      const ownerMatches = (allAssets || []).filter((asset: any) => {
        if (!asset?.id || asset.isDeleted || asset.active === false)
          return false;
        if (asset.ownerTable !== removal.ownerTable) return false;
        if (asset.fieldKey !== removal.fieldKey) return false;
        if (removal.accountId && asset.accountId !== removal.accountId)
          return false;
        if (!sameOptionalString(asset.schoolId, removal.schoolId)) return false;
        if (!sameOptionalString(asset.branchId, removal.branchId)) return false;

        const localMatch =
          idOf(removal.ownerId) && sameId(asset.ownerId, removal.ownerId);
        const cloudMatch =
          removal.ownerId &&
          sameOptionalString(asset.ownerId, removal.ownerId) &&
          String(asset.ownerId || "");
        const tempMatch =
          removal.ownerTempKey &&
          sameId(asset.ownerTempKey, removal.ownerTempKey);

        return !!localMatch || !!cloudMatch || !!tempMatch;
      });

      ownerMatches.forEach((asset: any) =>
        assetsToDelete.set(String(asset.id), asset),
      );
    }

    await Promise.all(
      Array.from(assetsToDelete.values()).map(async (asset: any) => {
        try {
          await updateLocal("mediaAssets", String(asset.id), {
            active: false,
            isDeleted: true,
            deletedAt: now,
            updatedAt: now,
            synced: "pending",
            uploadStatus: asset.uploadStatus || "local",
          } as any).catch(async () => {
            await (db as any).mediaAssets?.update?.(String(asset.id), {
              active: false,
              isDeleted: true,
              deletedAt: now,
              updatedAt: now,
              synced: "pending",
            });
          });

          const blobId = asset.localBlobId || asset.blobId || asset.mediaBlobId;
          if (blobId) {
            await (db as any).mediaBlobs?.update?.(String(blobId), {
              active: false,
              isDeleted: true,
              deletedAt: now,
              updatedAt: now,
              synced: "pending",
            });
          }

          if (asset.localObjectUrl) {
            revokeMediaObjectUrl(asset.localObjectUrl);
          }
        } catch (error) {
          console.warn(
            "Failed to soft-delete removed media asset:",
            asset,
            error,
          );
        }
      }),
    );

    setPendingMediaRemovals([]);
  };

  const requireTenant = () => {
    if (!authenticated || !selectedAccountId) {
      showToast("error", "Sign in first.");
      return false;
    }

    if (!selectedSchoolId) {
      showToast("error", "Assigned school is required.");
      return false;
    }

    if (!selectedBranchId) {
      showToast("error", "Assigned branch is required.");
      return false;
    }

    return true;
  };

  const saveSchoolBranchSettings = async (
    options: boolean | SaveOptions = false,
  ) => {
    const silent = typeof options === "boolean" ? options : !!options.silent;
    const reloadAfterSave =
      typeof options === "boolean" ? true : options.reloadAfterSave !== false;
    const shouldPersistRemovals =
      typeof options === "boolean" ? true : options.persistRemovals !== false;
    const includeAppearance =
      typeof options === "boolean" ? false : options.includeAppearance === true;
    if (!requireTenant()) return false;

    try {
      setSavingSettings(true);

      const settingsMediaPatch = {
        logo: safeRecordMediaValue(form.logo) || "",
        reportCardBackgroundImage:
          safeRecordMediaValue(form.reportCardBackgroundImage) || "",
        reportCardWatermark:
          safeRecordMediaValue(form.reportCardWatermark) || "",
        reportCardSignatureImage:
          safeRecordMediaValue(form.reportCardSignatureImage) || "",
        dashboardHeroImage: safeRecordMediaValue(form.dashboardHeroImage) || "",
        dashboardBannerImage:
          safeRecordMediaValue(form.dashboardBannerImage) || "",
        studentPortalImage: safeRecordMediaValue(form.studentPortalImage) || "",
        teacherPortalImage: safeRecordMediaValue(form.teacherPortalImage) || "",
        classroomPlaceholderImage:
          safeRecordMediaValue(form.classroomPlaceholderImage) || "",
        subjectPlaceholderImage:
          safeRecordMediaValue(form.subjectPlaceholderImage) || "",
        logoMediaId: mediaIdOrNull(form.logoMediaId),
        reportCardBackgroundImageMediaId: mediaIdOrNull(
          form.reportCardBackgroundImageMediaId,
        ),
        reportCardWatermarkMediaId: mediaIdOrNull(
          form.reportCardWatermarkMediaId,
        ),
        reportCardSignatureImageMediaId: mediaIdOrNull(
          form.reportCardSignatureImageMediaId,
        ),
        dashboardHeroImageMediaId: mediaIdOrNull(
          form.dashboardHeroImageMediaId,
        ),
        dashboardBannerImageMediaId: mediaIdOrNull(
          form.dashboardBannerImageMediaId,
        ),
        studentPortalImageMediaId: mediaIdOrNull(
          form.studentPortalImageMediaId,
        ),
        teacherPortalImageMediaId: mediaIdOrNull(
          form.teacherPortalImageMediaId,
        ),
        classroomPlaceholderImageMediaId: mediaIdOrNull(
          form.classroomPlaceholderImageMediaId,
        ),
        subjectPlaceholderImageMediaId: mediaIdOrNull(
          form.subjectPlaceholderImageMediaId,
        ),
      };

      const committedAppearance = {
        primaryColor:
          (settingsRow as any)?.primaryColor ||
          settings?.primaryColor ||
          form.primaryColor ||
          "#2f6fed",
        theme:
          ((settingsRow as any)?.theme ||
            settings?.theme ||
            form.theme ||
            "light") as "light" | "dark",
        fontFamily:
          (settingsRow as any)?.fontFamily ||
          settings?.fontFamily ||
          form.fontFamily ||
          "system-ui, -apple-system, sans-serif",
        fontSize:
          Number(
            (settingsRow as any)?.fontSize ??
              settings?.fontSize ??
              form.fontSize ??
              16,
          ) || 16,
      };

      const appearancePatch = includeAppearance
        ? {
            primaryColor: form.primaryColor,
            theme: form.theme,
            fontFamily: form.fontFamily,
            fontSize: form.fontSize,
          }
        : committedAppearance;

      const latestSavedRow = (await db.schoolBranchSettings.toArray())
        .filter((row: any) => !row.isDeleted &&
          (!row.accountId || sameId(row.accountId, selectedAccountId)) &&
          sameId(row.schoolId, selectedSchoolId) &&
          sameId(row.branchId, selectedBranchId))
        .sort((a: any, b: any) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0))[0];

      const payload = makeSettingsPayload(
        {
          ...form,
          // Preserve independent admission/ID configuration during all other saves.
          admissionNumbers: (() => {
            const saved = (latestSavedRow as any)?.admissionNumbers ??
              (settingsRow as any)?.admissionNumbers;
            return saved && typeof saved === "object"
              ? { ...saved, padding: Math.min(12, Math.max(3, Number(saved.padding) || 3)), nextSequence: 1 }
              : saved;
          })(),
          identityIssuancePolicyCache: (latestSavedRow as any)?.identityIssuancePolicyCache ??
            (settingsRow as any)?.identityIssuancePolicyCache,
          identityIssuancePolicyPending: (latestSavedRow as any)?.identityIssuancePolicyPending ??
            (settingsRow as any)?.identityIssuancePolicyPending,
          ...appearancePatch,
          ...settingsMediaPatch,
          accountId: selectedAccountId,
          schoolId: cleanId(selectedSchoolId) || undefined,
          branchId: cleanId(selectedBranchId) || undefined,
          currentAcademicStructureId:
            form.currentAcademicStructureId || undefined,
          currentAcademicPeriodId: form.currentAcademicPeriodId || undefined,
          isDeleted: false,
        } as Partial<SchoolBranchSetting>,
        latestSavedRow || settingsRow || undefined,
      );

      /**
       * Commit through SettingsContext instead of writing the settings table
       * directly. This keeps the saved theme, primary colour and typography in
       * one atomic state update and prevents refreshSettings from rehydrating a
       * fallback/default colour after a theme-only change.
       */
      const committedSettings = await updateContextSettings({
        ...payload,
        accountId: selectedAccountId,
        schoolId: cleanId(selectedSchoolId) || undefined,
        branchId: cleanId(selectedBranchId) || undefined,
        isDeleted: false,
      } as any);

      const savedSettingsId = idOf(committedSettings?.id);
      if (!savedSettingsId) throw new Error("Settings save did not return a record ID.");
      const locallyPersisted = await db.schoolBranchSettings.get(savedSettingsId);
      if (!locallyPersisted || locallyPersisted.isDeleted) {
        throw new Error("Settings could not be verified in Dexie. Please retry.");
      }

      setSettingsRow(locallyPersisted);
      setForm((current) => ({
        ...current,
        ...committedSettings,
        id: committedSettings.id,
        schoolId: cleanId(committedSettings.schoolId) || undefined,
        branchId: cleanId(committedSettings.branchId) || undefined,
        primaryColor:
          committedSettings.primaryColor ||
          current.primaryColor ||
          "#2f6fed",
        theme:
          (committedSettings.theme || current.theme || "light") as
            | "light"
            | "dark",
        fontFamily:
          committedSettings.fontFamily ||
          current.fontFamily,
        fontSize:
          Number(committedSettings.fontSize) ||
          current.fontSize ||
          16,
      }));

      if (savedSettingsId) {
        const settingsFieldAssets = [
          { assetId: form.logoMediaId, fieldKey: "logo" },
          {
            assetId: form.reportCardBackgroundImageMediaId,
            fieldKey: "reportCardBackgroundImage",
          },
          {
            assetId: form.reportCardWatermarkMediaId,
            fieldKey: "reportCardWatermark",
          },
          {
            assetId: form.reportCardSignatureImageMediaId,
            fieldKey: "reportCardSignatureImage",
          },
          {
            assetId: form.dashboardHeroImageMediaId,
            fieldKey: "dashboardHeroImage",
          },
          {
            assetId: form.dashboardBannerImageMediaId,
            fieldKey: "dashboardBannerImage",
          },
          {
            assetId: form.studentPortalImageMediaId,
            fieldKey: "studentPortalImage",
          },
          {
            assetId: form.teacherPortalImageMediaId,
            fieldKey: "teacherPortalImage",
          },
          {
            assetId: form.classroomPlaceholderImageMediaId,
            fieldKey: "classroomPlaceholderImage",
          },
          {
            assetId: form.subjectPlaceholderImageMediaId,
            fieldKey: "subjectPlaceholderImage",
          },
        ];

        await commitMediaAssetsToOwner({
          accountId: selectedAccountId,
          ownerTable: SETTINGS_MEDIA_OWNER_TABLE,
          ownerId: savedSettingsId,

          ownerTempKey: settingsMediaSessionKeyRef.current,
          assets: settingsFieldAssets,
        });

        uploadedSettingsMediaIdsRef.current = {};
        stagedGalleryMediaIdsRef.current.clear();
        settingsMediaSessionKeyRef.current = createSettingsMediaSessionKey();
      }

      if (shouldPersistRemovals) await persistPendingMediaRemovals();

      if (reloadAfterSave) {
        await load();
      }

      try {
        await refreshInstitution?.();
      } catch (refreshError) {
        // The Dexie write already succeeded; a refresh failure is not a failed save.
        console.warn("Institution refresh did not complete:", refreshError);
      }

      /**
       * Phase 10 post-commit propagation:
       * 1. publish selective schoolBranchSettings revision;
       * 2. SettingsContext reloads the exact active branch row;
       * 3. PortalAppearanceRuntime asks ThemeContext to reapply it;
       * 4. background sync is requested through the central sync runtime.
       */
      publishBranchSettingsSaved({
        accountId: selectedAccountId,
        schoolId: cleanId(selectedSchoolId), 
        branchId: cleanId(selectedBranchId)
      });

      /*
       * updateContextSettings already updated effectiveSettings and announced
       * the exact committed record. Do not perform a second settings reload
       * here; that was the race which could replace the saved primary colour.
       */

      if (!silent)
        showToast("success", "School branch settings saved successfully.");
      return true;
    } catch (error: any) {
      console.error("Failed to save school branch settings:", error);
      showToast(
        "error",
        error?.message || "Failed to save school branch settings.",
      );
      return false;
    } finally {
      setSavingSettings(false);
    }
  };

  const saveSchoolIdentity = async (options: boolean | SaveOptions = false) => {
    const silent = typeof options === "boolean" ? options : !!options.silent;
    const reloadAfterSave =
      typeof options === "boolean" ? true : options.reloadAfterSave !== false;
    const shouldPersistRemovals =
      typeof options === "boolean" ? true : options.persistRemovals !== false;
    if (!selectedAccountId) {
      showToast("error", "Sign in first.");
      return false;
    }

    if (!schoolForm.id) {
      showToast("error", "Assigned school record was not found.");
      return false;
    }

    if (!schoolForm.name?.trim()) {
      showToast("error", "School name is required.");
      return false;
    }

    try {
      setSavingSchool(true);

      await updateLocal("schools", String(schoolForm.id), {
        accountId: selectedAccountId,
        name: schoolForm.name.trim(),
        motto: schoolForm.motto?.trim() || undefined,
        logo: safeRecordMediaValue(schoolForm.logo) || "",
        logoMediaId: mediaIdOrNull(schoolForm.logoMediaId),
        bannerImage: safeRecordMediaValue(schoolForm.bannerImage) || "",
        bannerImageMediaId: mediaIdOrNull(schoolForm.bannerImageMediaId),
        galleryImages: (schoolForm.galleryImages || [])
          .map(safeRecordMediaValue)
          .filter(Boolean),
        address: schoolForm.address?.trim() || undefined,
        location: schoolForm.location?.trim() || undefined,
        email: schoolForm.email?.trim() || undefined,
        phone: schoolForm.phone?.trim() || undefined,
        website: schoolForm.website?.trim() || undefined,
        active: schoolForm.active !== false,
        updatedAt: Date.now(),
        synced: "pending",
      } as any);

      const stagedSchoolLogoId = cleanId(
        uploadedSchoolMediaIdsRef.current.logo,
      );
      const stagedSchoolBannerId = cleanId(
        uploadedSchoolMediaIdsRef.current.bannerImage,
      );

      const committedSchoolMedia = await commitMediaAssetsToOwner({
        accountId: selectedAccountId,
        ownerTable: SCHOOL_MEDIA_OWNER_TABLE,
        ownerId: cleanId(schoolForm.id) || undefined,
        ownerTempKey: schoolMediaSessionKeyRef.current,
        assets: [
          {
            assetId: stagedSchoolLogoId || undefined,
            fieldKey: "logo",
          },
          {
            assetId: stagedSchoolBannerId || undefined,
            fieldKey: "bannerImage",
          },
        ],
      });

      const committedSchoolLogoId = committedSchoolMedia.find(
        (item) => item.fieldKey === "logo",
      )?.assetId;

      const committedSchoolBannerId = committedSchoolMedia.find(
        (item) => item.fieldKey === "bannerImage",
      )?.assetId;

      if (committedSchoolLogoId || committedSchoolBannerId) {
        await updateLocal("schools", String(schoolForm.id), {
          logoMediaId:
            committedSchoolLogoId ||
            schoolForm.logoMediaId ||
            undefined,
          bannerImageMediaId:
            committedSchoolBannerId ||
            schoolForm.bannerImageMediaId ||
            undefined,
          logo: safeRecordMediaValue(schoolForm.logo) || "",
          bannerImage:
            safeRecordMediaValue(schoolForm.bannerImage) || "",
        } as any);
      }

      uploadedSchoolMediaIdsRef.current = {};
      schoolMediaSessionKeyRef.current =
        createSharedMediaSessionKey(SCHOOL_MEDIA_OWNER_TABLE);

      if (shouldPersistRemovals) await persistPendingMediaRemovals();

      if (reloadAfterSave) await load();
      await refreshInstitution?.();
      window.dispatchEvent(new Event("school-branch-settings-updated"));

      if (!silent) showToast("success", "School identity saved successfully.");
      return true;
    } catch (error: any) {
      console.error("Failed to save school identity:", error);
      showToast("error", error?.message || "Failed to save school identity.");
      return false;
    } finally {
      setSavingSchool(false);
    }
  };

  const saveBranchIdentity = async (options: boolean | SaveOptions = false) => {
    const silent = typeof options === "boolean" ? options : !!options.silent;
    const reloadAfterSave =
      typeof options === "boolean" ? true : options.reloadAfterSave !== false;
    const shouldPersistRemovals =
      typeof options === "boolean" ? true : options.persistRemovals !== false;
    if (!selectedAccountId) {
      showToast("error", "Sign in first.");
      return false;
    }

    if (!branchForm.id) {
      showToast("error", "Assigned branch record was not found.");
      return false;
    }

    if (!branchForm.name?.trim()) {
      showToast("error", "Branch name is required.");
      return false;
    }

    try {
      setSavingBranch(true);

      await updateLocal("branches", String(branchForm.id), {
        accountId: selectedAccountId,
        schoolId: cleanId(selectedSchoolId || branchForm.schoolId) || undefined,
        name: branchForm.name.trim(),
        code: branchForm.code?.trim() || undefined,
        logo: safeRecordMediaValue(branchForm.logo) || "",
        logoMediaId: mediaIdOrNull(branchForm.logoMediaId),
        bannerImage: safeRecordMediaValue(branchForm.bannerImage) || "",
        bannerImageMediaId: mediaIdOrNull(branchForm.bannerImageMediaId),
        address: branchForm.address?.trim() || undefined,
        location: branchForm.location?.trim() || undefined,
        city:
          branchForm.city?.trim() || branchForm.location?.trim() || undefined,
        email: branchForm.email?.trim() || undefined,
        phone: branchForm.phone?.trim() || undefined,
        website: branchForm.website?.trim() || undefined,
        active: branchForm.active !== false,
        updatedAt: Date.now(),
        synced: "pending",
      } as any);

      const stagedBranchLogoId = cleanId(
        uploadedBranchMediaIdsRef.current.logo,
      );
      const stagedBranchBannerId = cleanId(
        uploadedBranchMediaIdsRef.current.bannerImage,
      );

      const committedBranchMedia = await commitMediaAssetsToOwner({
        accountId: selectedAccountId,
        ownerTable: BRANCH_MEDIA_OWNER_TABLE,
        ownerId: cleanId(branchForm.id) || undefined,
        ownerTempKey: branchMediaSessionKeyRef.current,
        assets: [
          {
            assetId: stagedBranchLogoId || undefined,
            fieldKey: "logo",
          },
          {
            assetId: stagedBranchBannerId || undefined,
            fieldKey: "bannerImage",
          },
        ],
      });

      const committedBranchLogoId = committedBranchMedia.find(
        (item) => item.fieldKey === "logo",
      )?.assetId;

      const committedBranchBannerId = committedBranchMedia.find(
        (item) => item.fieldKey === "bannerImage",
      )?.assetId;

      if (committedBranchLogoId || committedBranchBannerId) {
        await updateLocal("branches", String(branchForm.id), {
          logoMediaId:
            committedBranchLogoId ||
            branchForm.logoMediaId ||
            undefined,
          bannerImageMediaId:
            committedBranchBannerId ||
            branchForm.bannerImageMediaId ||
            undefined,
          logo: safeRecordMediaValue(branchForm.logo) || "",
          bannerImage:
            safeRecordMediaValue(branchForm.bannerImage) || "",
        } as any);
      }

      uploadedBranchMediaIdsRef.current = {};
      branchMediaSessionKeyRef.current =
        createSharedMediaSessionKey(BRANCH_MEDIA_OWNER_TABLE);

      if (shouldPersistRemovals) await persistPendingMediaRemovals();

      if (reloadAfterSave) await load();
      await refreshInstitution?.();
      window.dispatchEvent(new Event("school-branch-settings-updated"));

      if (!silent) showToast("success", "Branch identity saved successfully.");
      return true;
    } catch (error: any) {
      console.error("Failed to save branch identity:", error);
      showToast("error", error?.message || "Failed to save branch identity.");
      return false;
    } finally {
      setSavingBranch(false);
    }
  };

  const saveReportCardTemplateSettings = async (
    options: boolean | SaveOptions = false,
  ) => {
    const silent = typeof options === "boolean" ? options : !!options.silent;
    const reloadAfterSave =
      typeof options === "boolean" ? true : options.reloadAfterSave !== false;

    if (!requireTenant()) return false;

    if (
      !(db as any).reportCardTemplates ||
      !(db as any).reportCardTemplateSettings ||
      !(db as any).reportCardTemplateAssignments
    ) {
      showToast(
        "error",
        "Report card template tables are missing. Update db.ts first.",
      );
      return false;
    }

    try {
      setSavingReportTemplate(true);

      const accountIdValue = String(selectedAccountId);
      const schoolIdValue = String(selectedSchoolId);
      const branchIdValue = String(selectedBranchId);

      const activeReportType = (reportTemplateForm.reportType ||
        "student_report") as ReportTemplateReportType;
      const existingTemplateId = idOf(reportTemplateForm.templateId);
      const allExistingTemplates = await ((
        db as any
      ).reportCardTemplates?.toArray?.() || []);
      const existingTemplate = Boolean(existingTemplateId)
        ? await (db as any).reportCardTemplates.get(existingTemplateId)
        : (allExistingTemplates as any[]).find(
            (row: any) =>
              !row.isDeleted &&
              row.active !== false &&
              row.accountId === accountIdValue &&
              sameId(row.schoolId, schoolIdValue) &&
              sameId(row.branchId, branchIdValue) &&
              (row.reportType === activeReportType ||
                (!row.reportType && activeReportType === "student_report")) &&
              sameId(row.code, reportTemplateForm.templateCode),
          ) || null;

      const templatePayload = makeReportTemplatePayload({
        form: reportTemplateForm,
        accountId: accountIdValue,
        schoolId: schoolIdValue,
        branchId: branchIdValue,
        existing: existingTemplate || undefined,
      });

      let savedTemplateId = existingTemplateId || idOf(existingTemplate?.id);

      if (savedTemplateId) {
        await updateLocal(
          "reportCardTemplates" as any,
          savedTemplateId,
          templatePayload as any,
        );
      } else {
        const { id, ...withoutId } = templatePayload as any;
        const created = await createLocal(
          "reportCardTemplates" as any,
          withoutId as any,
        );
        savedTemplateId = idOf(
          typeof created === "string" || typeof created === "number"
            ? created
            : (created as any)?.id,
        );
      }

      if (!savedTemplateId) {
        throw new Error("Could not save the report card template.");
      }

      const existingSettingsId = idOf(reportTemplateForm.templateSettingsId);
      const existingTemplateSettingsById = Boolean(existingSettingsId)
        ? await (db as any).reportCardTemplateSettings.get(existingSettingsId)
        : null;
      const existingTemplateSettings =
        existingTemplateSettingsById &&
        (existingTemplateSettingsById.reportType === activeReportType ||
          (!existingTemplateSettingsById.reportType &&
            activeReportType === "student_report"))
          ? existingTemplateSettingsById
          : (
              await ((db as any).reportCardTemplateSettings?.toArray?.() || [])
            ).find(
              (row: any) =>
                !row.isDeleted &&
                row.active !== false &&
                row.accountId === accountIdValue &&
                sameId(row.schoolId, schoolIdValue) &&
                sameId(row.branchId, branchIdValue) &&
                (row.reportType === activeReportType ||
                  (!row.reportType && activeReportType === "student_report")) &&
                (sameId(row.templateCode, reportTemplateForm.templateCode) ||
                  sameId(row.templateId, savedTemplateId)),
            ) || null;

      const settingsPayload = makeReportTemplateSettingsPayload({
        form: reportTemplateForm,
        accountId: accountIdValue,
        schoolId: schoolIdValue,
        branchId: branchIdValue,
        templateId: savedTemplateId,
        existing: existingTemplateSettings || undefined,
      });

      let savedSettingsId = idOf(existingTemplateSettings?.id);

      if (savedSettingsId) {
        await updateLocal(
          "reportCardTemplateSettings" as any,
          savedSettingsId,
          settingsPayload as any,
        );
      } else {
        const { id, ...withoutId } = settingsPayload as any;
        const created = await createLocal(
          "reportCardTemplateSettings" as any,
          withoutId as any,
        );
        savedSettingsId = idOf(
          typeof created === "string" || typeof created === "number"
            ? created
            : (created as any)?.id,
        );
      }

      if (!savedSettingsId) {
        throw new Error("Could not save the report card display settings.");
      }

      const existingAssignmentId = idOf(reportTemplateForm.assignmentId);
      const existingAssignmentById = Boolean(existingAssignmentId)
        ? await (db as any).reportCardTemplateAssignments.get(
            existingAssignmentId,
          )
        : null;
      const existingAssignment =
        existingAssignmentById &&
        (existingAssignmentById.reportType === activeReportType ||
          (!existingAssignmentById.reportType &&
            activeReportType === "student_report"))
          ? existingAssignmentById
          : (
              await ((db as any).reportCardTemplateAssignments?.toArray?.() ||
                [])
            ).find(
              (row: any) =>
                !row.isDeleted &&
                row.active !== false &&
                row.accountId === accountIdValue &&
                sameId(row.schoolId, schoolIdValue) &&
                sameId(row.branchId, branchIdValue) &&
                (row.reportType === activeReportType ||
                  (!row.reportType && activeReportType === "student_report")) &&
                (!row.scopeType || row.scopeType === "branch") &&
                sameId(row.scopeId, branchIdValue),
            ) || null;

      const assignmentPayload = makeReportTemplateAssignmentPayload({
        form: reportTemplateForm,
        accountId: accountIdValue,
        schoolId: schoolIdValue,
        branchId: branchIdValue,
        templateId: savedTemplateId,
        templateSettingsId: savedSettingsId,
        existing: existingAssignment || undefined,
      });

      const saveAssignmentId = idOf(existingAssignment?.id);
      if (saveAssignmentId) {
        await updateLocal(
          "reportCardTemplateAssignments" as any,
          saveAssignmentId,
          assignmentPayload as any,
        );
      } else {
        const { id, ...withoutId } = assignmentPayload as any;
        await createLocal(
          "reportCardTemplateAssignments" as any,
          withoutId as any,
        );
      }

      if (reloadAfterSave) await load();
      window.dispatchEvent(new Event("school-branch-settings-updated"));

      if (!silent) {
        const savedLabel =
          activeReportType === "cumulative_book"
            ? "Cumulative report book"
            : activeReportType === "cumulative_transcript"
              ? "Cumulative transcript"
              : activeReportType === "subject_broadsheet"
                ? "Subject broadsheet"
                : activeReportType === "class_broadsheet"
                  ? "Class broadsheet"
                  : activeReportType === "annual_broadsheet"
                    ? "Annual broadsheet"
                    : "Student report card";
        showToast(
          "success",
          `${savedLabel} template settings saved successfully.`,
        );
      }
      return true;
    } catch (error: any) {
      console.error("Failed to save report card template settings:", error);
      showToast(
        "error",
        error?.message || "Failed to save report card template settings.",
      );
      return false;
    } finally {
      setSavingReportTemplate(false);
    }
  };

  const saveAdmissionNumbers = async (options: { silent?: boolean; close?: boolean } = {}) => {
    if (!requireTenant()) return false;
    try {
      setSavingAdmission(true);
      const settingsCandidates = (await db.schoolBranchSettings.toArray())
        .filter((row: any) => !row.isDeleted &&
          (!row.accountId || sameId(row.accountId, selectedAccountId)) &&
          sameId(row.schoolId, selectedSchoolId) &&
          sameId(row.branchId, selectedBranchId))
        .sort((a: any, b: any) => {
          // A duplicate settings row without admission configuration must not
          // replace the row that contains the school's actual numbering rules.
          const aConfigured = !!(a as any).admissionNumbers;
          const bConfigured = !!(b as any).admissionNumbers;
          if (aConfigured !== bConfigured) return aConfigured ? -1 : 1;
          return Number(b.updatedAt || 0) - Number(a.updatedAt || 0);
        });
      const existing = settingsCandidates[0];
      if (!existing) throw new Error("Save Branch Settings once before configuring admission numbers.");
      const previous = (existing as any).admissionNumbers;
      const next = {
        mode: admissionDraft.mode || previous?.mode || "manual",
        prefix: admissionDraft.prefix.trim().toUpperCase(),
        separator: admissionDraft.separator,
        padding: Math.min(12, Math.max(3, Math.floor(Number(admissionDraft.padding) || 3))),
        scope: "branch" as const,
        // Neutral starting floor: the server's AdmissionNumberSequence and
        // StudentAdmissionIdentity determine the next free number. Keeping 82
        // here would force Math.max(sequence.nextSequence, config.nextSequence)
        // to skip valid numbers even after a registry repair.
        nextSequence: 1,
      };
      await updateLocal("schoolBranchSettings", existing.id, { admissionNumbers: next } as any);
      const verified = await db.schoolBranchSettings.get(existing.id);
      if (!(verified as any)?.admissionNumbers) throw new Error("Admission settings were not saved in Dexie.");
      setSettingsRow(verified || null);
      setAdmissionDraft(next);
      publishBranchSettingsSaved({
        accountId: selectedAccountId,
        schoolId: cleanId(selectedSchoolId), branchId: cleanId(selectedBranchId),
      });
      if (options.close !== false) setSectionOpen(null);
      if (!options.silent) showToast("success", "Admission number settings saved.");
      return true;
    } catch (error: any) {
      showToast("error", error?.message || "Could not save admission number settings.");
      return false;
    } finally {
      setSavingAdmission(false);
    }
  };

  const saveAll = async () => {
    if (!requireTenant()) return;

    try {
      setSavingAll(true);

      if (schoolForm.id) {
        const result = await saveSchoolIdentity({
          silent: true, reloadAfterSave: false, persistRemovals: false,
        });
        if (!result) throw new Error("School identity could not be saved.");
      }
      if (branchForm.id) {
        const result = await saveBranchIdentity({
          silent: true, reloadAfterSave: false, persistRemovals: false,
        });
        if (!result) throw new Error("Branch identity could not be saved.");
      }
      if (!await saveSchoolBranchSettings({
        silent: true, reloadAfterSave: false,
        persistRemovals: false, includeAppearance: true,
      })) throw new Error("Branch preferences could not be saved.");

      if (!await saveAdmissionNumbers({ silent: true, close: false }))
        throw new Error("Admission number settings could not be saved.");

      if (!await saveReportCardTemplateSettings({
        silent: true, reloadAfterSave: false, persistRemovals: false,
      })) throw new Error("Report template settings could not be saved.");

      await persistPendingMediaRemovals();
      await load();
      await refreshInstitution?.();
      showToast("success", "All branch settings saved in Dexie.");
    } catch (error: any) {
      showToast("error", error?.message || "One or more settings could not be saved.");
    } finally {
      setSavingAll(false);
    }
  };

  // ======================================================
  // THEME SAFETY
  // ======================================================

  // Branch Settings stores theme preferences only.
  // It intentionally does not mutate document.documentElement on open or save.
  // Global theme application belongs to the shell/settings provider.

  useEffect(() => {
    const icon = form.logo || schoolForm.logo || branchForm.logo;
    if (!icon) return;

    const link: HTMLLinkElement =
      document.querySelector("link[rel~='icon']") ||
      document.createElement("link");

    link.rel = "icon";
    link.href = icon;
    document.head.appendChild(link);
  }, [form.logo, schoolForm.logo, branchForm.logo]);

  const loadPortalHighlights = async () => {
    if (!selectedAccountId || !selectedSchoolId || !selectedBranchId) {
      setPortalHighlights([]);
      return;
    }

    const table = (db as any).portalHighlights;
    if (!table?.toArray) {
      setPortalHighlights([]);
      return;
    }

    const rows = ((await table.toArray()) as PortalHighlightRow[])
      .filter(
        (row) =>
          !row.isDeleted &&
          row.accountId === selectedAccountId &&
          sameId(row.schoolId, selectedSchoolId) &&
          sameId(row.branchId, selectedBranchId),
      )
      .sort(
        (a, b) =>
          Number(a.displayOrder || 0) - Number(b.displayOrder || 0),
      );

    const resolved = await Promise.all(
      rows.map(async (row) => {
        let mediaUrl = String(row.fallbackImageUrl || "");
        let posterUrl = "";

        if (row.mediaAssetId) {
          try {
            mediaUrl =
              (await resolveMediaAssetUrlById(row.mediaAssetId, {
                accountId: selectedAccountId,
                ownerTable: MediaOwners.PORTAL_HIGHLIGHTS,
                ownerId: row.id,
              })) || mediaUrl;
          } catch {}
        }

        if (row.posterMediaAssetId) {
          try {
            posterUrl =
              (await resolveMediaAssetUrlById(row.posterMediaAssetId, {
                accountId: selectedAccountId,
                ownerTable: MediaOwners.PORTAL_HIGHLIGHTS,
                ownerId: row.id,
              })) || "";
          } catch {}
        }

        return { ...row, _mediaUrl: mediaUrl, _posterUrl: posterUrl };
      }),
    );

    setPortalHighlights(resolved);
  };

  useEffect(() => {
    void loadPortalHighlights();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedAccountId, selectedSchoolId, selectedBranchId, dataRevision]);

  const editPortalHighlight = (
    row?: PortalHighlightRow | null,
    placement: "hero" | "gallery" = "hero",
  ) => {
    if (!row) {
      setPortalHighlightDraft({
        ...newPortalHighlightDraft(),
        placement,
        audiences: placement === "gallery" ? ["all"] : ["all"],
      });
      return;
    }

    setPortalHighlightDraft({
      id: idOf(row.id) || undefined,
      ownerTempKey: createSharedMediaSessionKey(MediaOwners.PORTAL_HIGHLIGHTS),
      title: row.title || "",
      subtitle: row.subtitle || "",
      description: row.description || "",
      mediaType: row.mediaType || "image",
      placement: row.placement === "gallery" ? "gallery" : placement,
      mediaAssetId: idOf(row.mediaAssetId),
      mediaUrl: row._mediaUrl || row.fallbackImageUrl || "",
      posterMediaAssetId: idOf(row.posterMediaAssetId),
      posterUrl: row._posterUrl || "",
      audiences:
        Array.isArray(row.audiences) && row.audiences.length
          ? row.audiences
          : ["all"],
      actionType: row.actionType || "none",
      actionLabel: row.actionLabel || "",
      actionValue: row.actionValue || "",
      displayOrder: Number(row.displayOrder || 0),
      startAtInput: row.startAt
        ? new Date(row.startAt).toISOString().slice(0, 16)
        : "",
      endAtInput: row.endAt
        ? new Date(row.endAt).toISOString().slice(0, 16)
        : "",
      durationSeconds: Number(row.durationSeconds || 7),
      autoplay: row.autoplay !== false,
      loop: row.loop === true,
      muted: row.muted !== false,
      transition: row.transition || "fade",
      status:
        row.status === "draft" || row.status === "scheduled"
          ? row.status
          : "published",
      active: row.active !== false,

      publishToWebsite: row.publishToWebsite === true,
      websiteFeatured: row.websiteFeatured === true,
    });
  };

  const uploadPortalHighlightPrimary = async (file?: File) => {
    if (!file || !selectedAccountId) return;

    try {
      const saved = await savePortalHighlightMedia(file, {
        accountId: selectedAccountId,
        schoolId: selectedSchoolId,
        branchId: selectedBranchId,
        highlightId: portalHighlightDraft.id,
        ownerTempKey: portalHighlightDraft.ownerTempKey,
        replaceExisting: true,
      });

      setPortalHighlightDraft((current) => ({
        ...current,
        mediaType: saved.kind === "video" ? "video" : "image",
        mediaAssetId: saved.assetId,
        mediaUrl: saved.previewUrl,
      }));
    } catch (error) {
      showToast(
        "error",
        error instanceof Error ? error.message : "Could not save highlight media.",
      );
    }
  };

  const uploadPortalHighlightPosterFile = async (file?: File) => {
    if (!file || !selectedAccountId) return;

    try {
      const saved = await savePortalHighlightPoster(file, {
        accountId: selectedAccountId,
        schoolId: selectedSchoolId,
        branchId: selectedBranchId,
        highlightId: portalHighlightDraft.id,
        ownerTempKey: portalHighlightDraft.ownerTempKey,
        replaceExisting: true,
      });

      setPortalHighlightDraft((current) => ({
        ...current,
        posterMediaAssetId: saved.assetId,
        posterUrl: saved.previewUrl,
      }));
    } catch (error) {
      showToast(
        "error",
        error instanceof Error ? error.message : "Could not save video poster.",
      );
    }
  };

  const savePortalHighlight = async () => {
    if (
      !selectedAccountId ||
      !selectedSchoolId ||
      !selectedBranchId ||
      !portalHighlightDraft.title.trim()
    ) {
      showToast("error", `Add a title before saving the ${portalHighlightDraft.placement === "gallery" ? "gallery item" : "Portal Highlight"}.`);
      return;
    }

    if (!portalHighlightDraft.mediaAssetId && !portalHighlightDraft.mediaUrl) {
      showToast("error", `Select an image or video for this ${portalHighlightDraft.placement === "gallery" ? "gallery item" : "Portal Highlight"}.`);
      return;
    }

    setSavingPortalHighlight(true);

    try {
      const payload: PortalHighlightRow = {
        accountId: selectedAccountId,
        schoolId: selectedSchoolId,
        branchId: selectedBranchId,
        title: portalHighlightDraft.title.trim(),
        subtitle: portalHighlightDraft.subtitle.trim() || null,
        description: portalHighlightDraft.description.trim() || null,
        mediaType: portalHighlightDraft.mediaType,
        placement: portalHighlightDraft.placement,
        mediaAssetId: portalHighlightDraft.mediaAssetId || null,
        posterMediaAssetId:
          portalHighlightDraft.posterMediaAssetId || null,
        fallbackImageUrl:
          portalHighlightDraft.mediaType === "image"
            ? portalHighlightDraft.mediaUrl || null
            : portalHighlightDraft.posterUrl || null,
        audiences: portalHighlightDraft.audiences.length
          ? portalHighlightDraft.audiences
          : ["all"],
        actionType: portalHighlightDraft.actionType,
        actionLabel: portalHighlightDraft.actionLabel.trim() || null,
        actionValue: portalHighlightDraft.actionValue.trim() || null,
        displayOrder: portalHighlightDraft.displayOrder,
        startAt: portalHighlightDraft.startAtInput
          ? new Date(portalHighlightDraft.startAtInput).getTime()
          : null,
        endAt: portalHighlightDraft.endAtInput
          ? new Date(portalHighlightDraft.endAtInput).getTime()
          : null,
        durationSeconds: Math.max(
          3,
          Math.min(30, portalHighlightDraft.durationSeconds || 7),
        ),
        autoplay: portalHighlightDraft.autoplay,
        loop: portalHighlightDraft.loop,
        muted: true,
        transition: portalHighlightDraft.transition,
        status: portalHighlightDraft.status,
        active: portalHighlightDraft.active,
        publishedAt:
          portalHighlightDraft.status === "published"
            ? Date.now()
            : null,

        publishToWebsite: portalHighlightDraft.publishToWebsite,
        websitePublicationStatus: portalHighlightDraft.publishToWebsite
          ? portalHighlightDraft.status
          : "hidden",
        websiteFeatured: portalHighlightDraft.websiteFeatured,
        websiteDisplayOrder: portalHighlightDraft.displayOrder,
        websiteStartAt: portalHighlightDraft.startAtInput
          ? new Date(portalHighlightDraft.startAtInput).getTime()
          : null,
        websiteEndAt: portalHighlightDraft.endAtInput
          ? new Date(portalHighlightDraft.endAtInput).getTime()
          : null,
        websitePublishedAt:
          portalHighlightDraft.publishToWebsite &&
          portalHighlightDraft.status === "published"
            ? Date.now()
            : null,
      };

      let savedId = portalHighlightDraft.id || "";

      if (savedId) {
        await updateLocal(
          "portalHighlights" as any,
          savedId,
          payload as any,
        );
      } else {
        const created = await createLocal(
          "portalHighlights" as any,
          payload as any,
        );
        savedId = idOf(
          typeof created === "string" || typeof created === "number"
            ? created
            : (created as any)?.id,
        );
      }

      if (!savedId) throw new Error("Could not create the Portal Highlight.");

      await commitPortalHighlightMedia({
        accountId: selectedAccountId,
        highlightId: savedId,
        ownerTempKey: portalHighlightDraft.ownerTempKey,
        mediaAssetId: portalHighlightDraft.mediaAssetId,
        posterMediaAssetId: portalHighlightDraft.posterMediaAssetId,
      });

      setPortalHighlightDraft({
        ...newPortalHighlightDraft(),
        placement: portalHighlightDraft.placement,
      });
      await loadPortalHighlights();
      showToast("success", portalHighlightDraft.placement === "gallery" ? "Gallery item saved." : "Portal Highlight saved.");
    } catch (error) {
      showToast(
        "error",
        error instanceof Error ? error.message : "Could not save Portal Highlight.",
      );
    } finally {
      setSavingPortalHighlight(false);
    }
  };

  const removePortalHighlight = async (row: PortalHighlightRow) => {
    const highlightId = idOf(row.id);
    if (!highlightId || !window.confirm(`Remove “${row.title}”?`)) return;

    setSavingPortalHighlight(true);
    try {
      await softDeletePortalHighlightMedia({
        accountId: selectedAccountId || undefined,
        highlightId,
      });
      await softDeleteLocal("portalHighlights" as any, highlightId);
      await loadPortalHighlights();
      if (sameId(portalHighlightDraft.id, highlightId)) {
        setPortalHighlightDraft({
          ...newPortalHighlightDraft(),
          placement: portalHighlightDraft.placement,
        });
      }
      showToast("success", row.placement === "gallery" ? "Gallery item removed." : "Portal Highlight removed.");
    } catch (error) {
      showToast(
        "error",
        error instanceof Error ? error.message : "Could not remove Portal Highlight.",
      );
    } finally {
      setSavingPortalHighlight(false);
    }
  };

  // ======================================================
  // PREVIEW
  // ======================================================

  useEffect(() => {
    if (sectionOpen === "portalHighlights") {
      setPortalHighlightDraft((current) =>
        current.id || current.placement === "hero"
          ? current
          : { ...newPortalHighlightDraft(), placement: "hero" },
      );
    }

    if (sectionOpen === "gallery") {
      setPortalHighlightDraft((current) =>
        current.id || current.placement === "gallery"
          ? current
          : { ...newPortalHighlightDraft(), placement: "gallery" },
      );
    }
  }, [sectionOpen]);

  const previewStyle: React.CSSProperties = {
    background:
      "linear-gradient(135deg, color-mix(in srgb, var(--ba-primary, var(--primary-color, #2563eb)) 10%, var(--card-bg, var(--surface, #ffffff))), var(--card-bg, var(--surface, #ffffff)))",
    color: "var(--text, #111111)",
    borderColor: "var(--border, rgba(0,0,0,.10))",
  };

  // ======================================================
  // GOLDEN COMPACT UI
  // ======================================================

  const activeFilterCount = useMemo(() => {
    return [
      form.currentAcademicStructureId,
      form.currentAcademicPeriodId,
      form.academicYear,
      form.currentTerm && form.currentTerm !== "Term 1"
        ? form.currentTerm
        : undefined,
      form.theme !== "light" ? form.theme : undefined,
      form.mode !== "manual" ? form.mode : undefined,
    ].filter(Boolean).length;
  }, [
    form.currentAcademicStructureId,
    form.currentAcademicPeriodId,
    form.academicYear,
    form.currentTerm,
    form.theme,
    form.mode,
  ]);

  const searchTerm = search.trim().toLowerCase();

  const visibleSections = useMemo(() => {
    const sections = [
      {
        key: "academic" as SettingsSection,
        icon: "📚",
        title: "Academic Defaults",
        subtitle: `${activeStructure?.name || "No structure"} · ${activePeriod?.name || "No period"}`,
        detail: `${form.academicYear || "No academic year"} · ${form.currentTerm || "No term"}`,
        tone: activeStructure && activePeriod ? "green" : "orange",
      },
      {
        key: "school" as SettingsSection,
        icon: "🏫",
        title: "School Identity",
        subtitle: schoolForm.name || "No school name",
        detail: `${schoolForm.phone || "No phone"} · ${schoolForm.email || "No email"}`,
        tone: schoolForm.name ? "green" : "red",
      },
      {
        key: "branch" as SettingsSection,
        icon: "🏢",
        title: "Branch Identity",
        subtitle: branchForm.name || "No branch name",
        detail: `${branchForm.code || "No code"} · ${branchForm.location || branchForm.city || "No location"}`,
        tone: branchForm.name ? "green" : "red",
      },
      {
        key: "admissionNumbers" as SettingsSection,
        icon: "#",
        title: "Admission Numbers",
        subtitle: admissionDraft.mode === "manual" ? "Manual entry" : "Automatic numbering",
        detail: `${admissionDraft.prefix || "No prefix"}${admissionDraft.separator}${"0".repeat(Math.max(3, Math.min(12, admissionDraft.padding)))} · Next number assigned by server`,
        tone: "blue",
      },
      {
        key: "appearance" as SettingsSection,
        icon: "🎨",
        title: "Appearance",
        subtitle: `${form.theme} · ${form.primaryColor}`,
        detail: `${form.fontSize}px · ${fontOptions.find((item) => item.value === form.fontFamily)?.label || "Custom font"}`,
        tone: form.primaryColor ? "green" : "orange",
      },
      {
        key: "dashboardMedia" as SettingsSection,
        icon: "🖼️",
        title: "Dashboard & Portal Images",
        subtitle: `${
          [
            form.dashboardHeroImage,
            form.dashboardBannerImage,
            form.studentPortalImage,
            form.teacherPortalImage,
            form.classroomPlaceholderImage,
            form.subjectPlaceholderImage,
          ].filter(Boolean).length
        } asset(s)`,
        detail: "Dashboards, portals, classes and subject placeholders",
        tone:
          form.dashboardHeroImage || form.dashboardBannerImage
            ? "green"
            : "gray",
      },
      {
        key: "portalHighlights" as SettingsSection,
        icon: "🎞️",
        title: "Portal Highlights",
        subtitle: `${portalHighlights.filter((row) => row.active !== false && row.placement !== "gallery").length} active slide(s)`,
        detail: "Rotating image and short-video stories for dashboard heroes",
        tone: portalHighlights.length ? "green" : "gray",
      },
      {
        key: "reportMedia" as SettingsSection,
        icon: "📄",
        title: "Report Branding",
        subtitle: `${
          [
            form.reportCardBackgroundImage,
            form.reportCardWatermark,
            form.reportCardSignatureImage,
            form.logo,
          ].filter(Boolean).length
        } asset(s)`,
        detail: "Report background, watermark, signature and branch logo",
        tone: form.reportCardSignatureImage ? "green" : "gray",
      },
      {
        key: "reportTemplates" as SettingsSection,
        icon: "🧾",
        title: "Report Card Template",
        subtitle: `${reportTemplateForm.templateName || "Classic Ghana Report"} · ${reportTemplateForm.density}`,
        detail: `${
          [
            reportTemplateForm.showSubjectPosition ? "Subject pos." : "",
            reportTemplateForm.showClassPosition ? "Class pos." : "",
            reportTemplateForm.showNumberOnRoll ? "Roll" : "",
            reportTemplateForm.showCurrentAcademicPeriodEnd ? "Period end" : "",
            reportTemplateForm.showNextAcademicPeriod ? "Next period" : "",
            reportTemplateForm.showGeneratedDate
              ? reportTemplateForm.generatedDateLabel || "Generated"
              : "",
          ]
            .filter(Boolean)
            .join(" · ") || "Display controls ready"
        }`,
        tone: reportTemplateForm.active ? "green" : "gray",
      },
      {
        key: "website" as SettingsSection,
        icon: "🌐",
        title: "School Website",
        subtitle: "Template, display, labels and live preview",
        detail: "Content order, domains, SEO and publishing controls",
        tone: "blue",
      },
      {
        key: "idCards" as SettingsSection,
        icon: "🪪",
        title: "ID Cards",
        subtitle: "Student and teacher ID designs",
        detail: "Card layout, logos, visible fields, issuance and QR privacy",
        tone: "blue",
      },
      {
        key: "gallery" as SettingsSection,
        icon: "🌄",
        title: "Gallery",
        subtitle: `${
          portalHighlights.filter(
            (row) => row.active !== false && row.placement === "gallery",
          ).length
        } active item(s)`,
        detail: "Record-based image and video gallery using the Portal Highlights workflow",
        tone: portalHighlights.some((row) => row.placement === "gallery")
          ? "green"
          : "gray",
      },
    ];

    const allowed = view === "reports"
      ? ["reportMedia", "reportTemplates"]
      : ["academic", "school", "branch", "admissionNumbers", "appearance", "idCards"];
    const chosen = sections.filter((section) => allowed.includes(section.key));
    if (!searchTerm) return chosen;

    return chosen.filter((section) =>
      `${section.title} ${section.subtitle} ${section.detail}`
        .toLowerCase()
        .includes(searchTerm),
    );
  }, [activePeriod, activeStructure, branchForm, form, schoolForm, searchTerm, view, admissionDraft]);

  // Report Card Settings uses this same editor with view="reports".
  // The shared actions work under both the Setup route and the legacy direct routes.
  const settingsToolbar = {
    add: () => setSectionOpen(view === "reports" ? "reportTemplates" : "academic"),
    search: (value: string) => setSearch(value),
    filter: () => setFilterOpen(true),
    more: () => setMoreOpen(true),
    print: () => printBranchTable({
      title: view === "reports" ? "Report card settings" : "Branch settings",
      subtitle: `${visibleSections.length} settings sections`,
      columns: [
        { key: "setting", label: "Section" },
        { key: "summary", label: "Current details" },
        { key: "description", label: "Configuration" },
      ],
      rows: visibleSections.map(section => ({
        setting: section.title,
        summary: section.subtitle,
        description: section.detail,
      })),
    }),
  };
  useRegisterBranchWorkspaceToolbar("setupWorkspace", settingsToolbar);
  useRegisterBranchWorkspaceToolbar("branchSettings", settingsToolbar);
  useRegisterBranchWorkspaceToolbar("reportCardSettings", settingsToolbar);

  if (!hasLoaded && (accountLoading || contextLoading || loading)) {
    return (
      <State
        primary={primary}
        title="Opening Branch Settings..."
        text="Checking account, school, branch, academic defaults and branding assets."
      />
    );
  }

  if (!authenticated || !selectedAccountId) {
    return (
      <State
        primary={primary}
        title="Sign in required"
        text="You must sign in before managing school branch settings."
      />
    );
  }

  if (!selectedSchoolId || !selectedBranchId) {
    return (
      <State
        primary={primary}
        title="Assigned branch required"
        text="This settings page is locked to the active branch-admin school branch assignment."
      />
    );
  }

  return (
    <main
      className="ba-page branch-settings-page"
      style={
        { "--ba-primary": form.primaryColor || primary } as React.CSSProperties
      }
    >
      <style>{css}</style>

      {toast && (
        <section className={`ba-toast ${toast.tone}`}>
          {toast.message}
          <button
            type="button"
            onClick={() => setToast(null)}
            aria-label="Close notification"
          >
            ✕
          </button>
        </section>
      )}

      <section
        className="ba-search-card"
        aria-label="Branch settings search and actions"
      >
        <label className="ba-search">
          <span>⌕</span>
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search settings..."
            aria-label="Search branch settings"
          />
        </label>

        <button
          type="button"
          className="ba-add-inline settings-save-button"
          onClick={saveAll}
          disabled={savingAll}
          aria-label="Save all settings"
          title="Save all"
        >
          {savingAll ? "..." : "Save"}
        </button>

        <button
          type="button"
          className={`ba-filter-button ${activeFilterCount ? "active" : ""}`}
          onClick={() => setFilterOpen(true)}
          aria-label="Open branch setting filters"
          title="Filters"
        >
          <SliderIcon />
          {activeFilterCount ? <b>{activeFilterCount}</b> : null}
        </button>

        <button
          type="button"
          className="ba-icon-button"
          onClick={() => setMoreOpen(true)}
          aria-label="More options"
        >
          ⋯
        </button>
      </section>

      {viewMode === "table" ? (
        <section className="ba-table-card branch-settings-table-card" aria-label="Settings sections table">
          <div className="ba-table-scroll">
          <table className="branch-settings-table">
            <thead>
              <tr>
                <th scope="col">Setting</th>
                <th scope="col">Current details</th>
                <th scope="col">Configuration</th>
                <th scope="col">Status</th>
                <th scope="col"><span className="sr-only">Action</span></th>
              </tr>
            </thead>
            <tbody>
              {visibleSections.map(section => (
                <tr key={section.key}>
                  <td>
                    <span className="ba-table-person branch-setting-table-name">
                      <span className="ba-avatar branch-settings-icon">{section.icon}</span>
                      <strong>{section.title}</strong>
                    </span>
                  </td>
                  <td>{section.subtitle}</td>
                  <td>{section.detail}</td>
                  <td><span className={`status-dot-mini ${section.tone}`} aria-label="Current status" /></td>
                  <td>
                    <button type="button" className="branch-setting-table-edit"
                      onClick={() => setSectionOpen(section.key)}
                      aria-label={`Configure ${section.title}`}>
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
          {!visibleSections.length && (
            <Empty icon="⚙️" title="No settings found" text="Try another search term or open More to refresh settings." />
          )}
        </section>
      ) : (
      <section className="ba-list branch-settings-list">
        {visibleSections.map((section) => (
          <button
            key={section.key}
            type="button"
            className="student-row"
            onClick={() => setSectionOpen(section.key)}
          >
            <span className="ba-avatar branch-settings-icon">{section.icon}</span>

            <span className="student-main">
              <strong>{section.title}</strong>
              <small>{section.subtitle}</small>
              <em>{section.detail}</em>
            </span>

            <span className="student-side">
              <span className={`status-dot-mini ${section.tone}`} />
              <i>⋯</i>
            </span>
          </button>
        ))}

        {!visibleSections.length && (
          <Empty
            icon="⚙️"
            title="No settings found"
            text="Try another search term or open More to refresh the branch settings."
          />
        )}
      </section>

      )}

      {filterOpen && (
        <AcademicFilterSheet
          form={form}
          filteredAcademicStructures={filteredAcademicStructures}
          filteredAcademicPeriods={filteredAcademicPeriods}
          updateForm={updateForm}
          onClose={() => setFilterOpen(false)}
        />
      )}

      {moreOpen && (
        <MoreSheet
          view={view}
          viewMode={viewMode}
          onChangeView={setViewMode}
          savingAll={savingAll}
          onSave={async () => {
            setMoreOpen(false);
            await saveAll();
          }}
          onRefresh={async () => {
            setMoreOpen(false);
            await load();
          }}
          openSection={(section) => {
            setMoreOpen(false);
            setSectionOpen(section);
          }}
          onClose={() => setMoreOpen(false)}
        />
      )}

      {sectionOpen === "admissionNumbers" && (
        <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true" aria-label="Admission number settings">
          <section className="ba-sheet">
            <div className="ba-sheet-head"><div><h2>Admission Numbers</h2><p>Numbering rules for new student records in this branch.</p></div><button type="button" onClick={() => setSectionOpen(null)} aria-label="Close">✕</button></div>
            <div className="ba-form compact">
              <Field label="Numbering mode"><select value={admissionDraft.mode} onChange={e => setAdmissionDraft(p => ({...p, mode: e.target.value as any}))}><option value="manual">Manual only</option><option value="automatic">Generate automatically</option><option value="automatic_or_manual">Automatic, allow manual entry</option></select></Field>
              <Field label="School prefix"><input value={admissionDraft.prefix} onChange={e => setAdmissionDraft(p => ({...p, prefix: e.target.value.toUpperCase()}))} placeholder="USOH" maxLength={32}/></Field>
                <Field label="Separator"><select value={admissionDraft.separator} onChange={e => setAdmissionDraft(p => ({...p, separator: e.target.value}))}><option value="-">Hyphen (-)</option><option value="/">Slash (/)</option><option value="">None</option></select></Field>
                <Field label="Minimum number of digits"><input type="number" min={3} max={12} value={admissionDraft.padding} onChange={e => setAdmissionDraft(p => ({...p,padding: Math.max(3,Math.min(12,Number(e.target.value)||3))}))}/></Field>
                <div className="admission-sequence-note" role="status">
                  <strong>Next number: controlled by backend registry</strong>
                  <span>This screen saves the prefix, mode, separator and minimum digits. The server assigns the next available number; the old local counter is not used.</span>
                </div>
                <p className="admission-sequence-caption">Existing student IDs are not changed. New allocations use the server registry.</p>
            </div>
            <div className="ba-sheet-footer"><button type="button" onClick={() => setSectionOpen(null)}>Cancel</button><button type="button" className="primary" disabled={savingAdmission} onClick={() => void saveAdmissionNumbers()}>{savingAdmission ? "Saving..." : "Save"}</button></div>
          </section>
        </div></EleeveonFullscreenOverlay>
      )}

      {sectionOpen === "academic" && (
        <AcademicSheet
          form={form}
          savingSettings={savingSettings}
          filteredAcademicStructures={filteredAcademicStructures}
          filteredAcademicPeriods={filteredAcademicPeriods}
          updateForm={updateForm}
          saveSchoolBranchSettings={saveSchoolBranchSettings}
          onClose={() => setSectionOpen(null)}
        />
      )}

      {sectionOpen === "school" && (
        <SchoolSheet
          schoolForm={schoolForm}
          savingSchool={savingSchool}
          updateSchoolField={updateSchoolField}
          uploadSchoolImage={uploadSchoolImage}
          saveSchoolIdentity={saveSchoolIdentity}
          clearImage={clearSchoolImage}
          onClose={() => setSectionOpen(null)}
        />
      )}

      {sectionOpen === "branch" && (
        <BranchSheet
          branchForm={branchForm}
          savingBranch={savingBranch}
          updateBranchField={updateBranchField}
          uploadBranchImage={uploadBranchImage}
          saveBranchIdentity={saveBranchIdentity}
          clearImage={clearBranchImage}
          onClose={() => setSectionOpen(null)}
        />
      )}

      {sectionOpen === "appearance" && (
        <AppearanceSheet
          form={form}
          savingSettings={savingSettings}
          updateForm={updateForm}
          saveSchoolBranchSettings={saveSchoolBranchSettings}
          previewStyle={previewStyle}
          schoolName={school?.name || activeSchool?.name || "School"}
          branchName={branch?.name || activeBranch?.name || "Branch"}
          onClose={() => setSectionOpen(null)}
        />
      )}

      {sectionOpen === "dashboardMedia" && (
        <MediaSheet
          title="Dashboard & Portal Images"
          text="These images belong only to the assigned school branch settings row."
          form={form}
          fields={[
            [
              "Dashboard Hero Image",
              "dashboardHeroImage",
              "Main dashboard hero visual for this branch.",
            ],
            [
              "Dashboard Banner Image",
              "dashboardBannerImage",
              "Wide dashboard and finance banner visual for this branch.",
            ],
            [
              "Student Portal Image",
              "studentPortalImage",
              "Image used for student dashboard/portal cards in this branch.",
            ],
            [
              "Teacher Portal Image",
              "teacherPortalImage",
              "Image used for teacher dashboard/portal cards in this branch.",
            ],
            [
              "Classroom Placeholder Image",
              "classroomPlaceholderImage",
              "Image used for class/classroom cards in this branch.",
            ],
            [
              "Subject Placeholder Image",
              "subjectPlaceholderImage",
              "Image used for subject cards in this branch.",
            ],
          ]}
          uploadImage={uploadImage}
          updateForm={updateForm}
          clearImage={clearSettingsImage}
          onClose={() => setSectionOpen(null)}
        />
      )}

      {sectionOpen === "portalHighlights" && (
        <PortalHighlightsSheet
          title="Portal Highlights"
          description="The saved Dashboard Hero Image remains the first slide. These highlights follow it as rotating image or short-video slides."
          entityLabel="Highlight"
          emptyText="No Portal Highlights yet."
          rows={portalHighlights.filter((row) => row.placement !== "gallery")}
          draft={portalHighlightDraft}
          saving={savingPortalHighlight}
          setDraft={setPortalHighlightDraft}
          editRow={(row) => editPortalHighlight(row, "hero")}
          uploadPrimary={uploadPortalHighlightPrimary}
          uploadPoster={uploadPortalHighlightPosterFile}
          saveRow={savePortalHighlight}
          removeRow={removePortalHighlight}
          onClose={() => setSectionOpen(null)}
        />
      )}

      {sectionOpen === "reportMedia" && (
        <MediaSheet
          title="Report Card Branding"
          text="These report card assets belong only to the assigned school branch."
          form={form}
          fields={[
            [
              "Report Background Image",
              "reportCardBackgroundImage",
              "A light background image for this branch's printed report cards.",
            ],
            [
              "Report Watermark",
              "reportCardWatermark",
              "Used behind report card content for this branch.",
            ],
            [
              "Official Signature Image",
              "reportCardSignatureImage",
              "Used near the headteacher/principal signature section.",
            ],
            [
              "Branch Settings Logo",
              "logo",
              "Optional settings-level logo for this branch experience.",
            ],
          ]}
          uploadImage={uploadImage}
          updateForm={updateForm}
          clearImage={clearSettingsImage}
          onClose={() => setSectionOpen(null)}
        />
      )}

      {sectionOpen === "reportTemplates" && (
        <ReportTemplateSheet
          form={reportTemplateForm}
          templates={reportTemplates}
          settingsForm={form}
          schoolName={
            schoolForm.name ||
            school?.name ||
            activeSchool?.name ||
            "Eleeveon International Academy"
          }
          branchName={
            branchForm.name ||
            branch?.name ||
            activeBranch?.name ||
            "Main Campus"
          }
          saving={savingReportTemplate}
          updateField={updateReportTemplateField}
          saveReportCardTemplateSettings={saveReportCardTemplateSettings}
          onClose={() => setSectionOpen(null)}
        />
      )}

      {sectionOpen === "website" && (
        <WebsiteSettingsSheet
          open
          accountId={selectedAccountId}
          schoolId={selectedSchoolId}
          branchId={selectedBranchId}
          schoolName={
            schoolForm.name ||
            school?.name ||
            activeSchool?.name ||
            "School Website"
          }
          branchName={
            branchForm.name ||
            branch?.name ||
            activeBranch?.name ||
            "Main Campus"
          }
          rootDomain="eleeveon.com"
          onSaved={() => {
            void load();
            setToast({
              tone: "success",
              message: "Website settings saved successfully.",
            });
          }}
          onClose={() => setSectionOpen(null)}
        />
      )}

      {sectionOpen === "idCards" && (
        <BranchIDCardSettings
          accountId={selectedAccountId}
          schoolId={selectedSchoolId}
          branchId={selectedBranchId}
          school={school}
          branch={branch}
          primaryColor={String(primary)}
          onClose={() => setSectionOpen(null)}
        />
      )}

      {sectionOpen === "gallery" && (
        <PortalHighlightsSheet
          title="Gallery"
          description="Gallery items use the same record-based workflow as Portal Highlights: image or video media, ordering, scheduling, visibility, actions and persistent removal."
          entityLabel="Gallery Item"
          emptyText="No gallery items yet."
          rows={portalHighlights.filter((row) => row.placement === "gallery")}
          draft={portalHighlightDraft}
          saving={savingPortalHighlight}
          setDraft={setPortalHighlightDraft}
          editRow={(row) => editPortalHighlight(row, "gallery")}
          uploadPrimary={uploadPortalHighlightPrimary}
          uploadPoster={uploadPortalHighlightPosterFile}
          saveRow={savePortalHighlight}
          removeRow={removePortalHighlight}
          onClose={() => setSectionOpen(null)}
        />
      )}
    </main>
  );
}


/**
 * One entry point for ID configuration. All settings live in Branch Settings,
 * while Generate/View/Replace/Revoke remain person actions in Students/Teachers.
 * The legacy IdentityCredentials workspace is not imported or needed.
 */
function BranchIDCardSettings({
  accountId,
  schoolId,
  branchId,
  school,
  branch,
  primaryColor,
  onClose,
}: {
  accountId?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  school?: School | null;
  branch?: Branch | null;
  primaryColor?: string;
  onClose: () => void;
}) {
  const [pane, setPane] = useState<"home" | "design" | "issuance">("home");

  if (pane === "design") {
    return (
      <CredentialDesignSettings
        accountId={accountId}
        schoolId={schoolId}
        branchId={branchId}
        school={school}
        branch={branch}
        primaryColor={primaryColor}
        onClose={() => setPane("home")}
      />
    );
  }

  if (pane === "issuance") {
    return (
      <IdentityIssuanceSettings
        accountId={String(accountId || "")}
        schoolId={String(schoolId || "")}
        branchId={String(branchId || "")}
        onClose={() => setPane("home")}
      />
    );
  }

  return (
    <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true"
      aria-label="ID Card Settings" style={{ zIndex: 1200 }}>
      <section className="ba-sheet small" style={{ width: "min(100%, 590px)" }}>
        <header className="ba-sheet-head">
          <div>
            <h2>ID Cards</h2>
            <p>One place to configure the IDs used by this branch.</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close ID Card Settings">✕</button>
        </header>
        <div className="ba-menu-list">
          <button type="button" onClick={() => setPane("design")}>
            <span>▣</span>
            <b>Card Designs</b>
            <small>Student and teacher layouts, school logos, front/back, colours and visible details</small>
          </button>
          <button type="button" onClick={() => setPane("issuance")}>
            <span>🪪</span>
            <b>Issuance & QR Privacy</b>
            <small>Automatic/manual IDs, expiry and information visible when the QR is scanned</small>
          </button>
        </div>
        <p style={{ fontSize: 11, margin: "16px 0 0", color: "var(--muted,#64748b)" }}>
          Generate, view, print, replace or revoke an ID from the student's or teacher's record.
        </p>
      </section>
    </div></EleeveonFullscreenOverlay>
  );
}

// ======================================================
// GOLDEN SMALL COMPONENTS
// ======================================================

function State({
  primary,
  title,
  text,
}: {
  primary: string;
  title: string;
  text: string;
}) {
  return (
    <main
      className="ba-page branch-settings-page"
      style={{ "--ba-primary": primary } as React.CSSProperties}
    >
      <style>{css}</style>
      <section className="ba-state">
        <div className="ba-spinner" />
        <h2>{title}</h2>
        <p>{text}</p>
      </section>
    </main>
  );
}

function Empty({
  icon,
  title,
  text,
}: {
  icon: string;
  title: string;
  text: string;
}) {
  return (
    <section className="ba-empty">
      <div className="ba-empty-icon">{icon}</div>
      <h3>{title}</h3>
      <p>{text}</p>
    </section>
  );
}

function SliderIcon() {
  return (
    <svg className="ba-slider-icon" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M4 7h9" />
      <path d="M17 7h3" />
      <circle cx="15" cy="7" r="2" />
      <path d="M4 17h3" />
      <path d="M11 17h9" />
      <circle cx="9" cy="17" r="2" />
    </svg>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="branch-field">
      <span>{label}</span>
      {children}
    </label>
  );
}

function ImagePreview({
  label,
  value,
  clear,
}: {
  label: string;
  value: string;
  clear: () => void;
}) {
  return (
    <div className="branch-image-preview">
      <img src={value} alt={label} />
      <button type="button" onClick={clear}>
        Remove
      </button>
    </div>
  );
}

function ImageUploader({
  label,
  field,
  helper,
  value,
  upload,
  clear,
}: {
  label: string;
  field: ImageField;
  helper?: string;
  value: string;
  upload: (field: ImageField, file?: File) => void;
  clear: () => void;
}) {
  return (
    <div className="branch-media-block">
      <div className="branch-media-title">{label}</div>
      {helper && <p>{helper}</p>}
      <input
        type="file"
        accept="image/*"
        onChange={(event) => upload(field, event.target.files?.[0])}
      />
      {value && <ImagePreview label={label} value={value} clear={clear} />}
    </div>
  );
}

function GenericImageUploader<TField extends string>({
  label,
  field,
  helper,
  value,
  upload,
  clear,
}: {
  label: string;
  field: TField;
  helper?: string;
  value: string;
  upload: (field: TField, file?: File) => void;
  clear: () => void;
}) {
  return (
    <div className="branch-media-block">
      <div className="branch-media-title">{label}</div>
      {helper && <p>{helper}</p>}
      <input
        type="file"
        accept="image/*"
        onChange={(event) => upload(field, event.target.files?.[0])}
      />
      {value && <ImagePreview label={label} value={value} clear={clear} />}
    </div>
  );
}

function AcademicFilterSheet({
  form,
  filteredAcademicStructures,
  filteredAcademicPeriods,
  updateForm,
  onClose,
}: {
  form: SettingsForm;
  filteredAcademicStructures: AcademicStructure[];
  filteredAcademicPeriods: AcademicPeriod[];
  updateForm: (key: keyof SettingsForm, value: any) => void;
  onClose: () => void;
}) {
  return (
    <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet">
        <div className="ba-sheet-head">
          <div>
            <h2>Filters</h2>
            <p>Quick branch academic defaults and theme filters.</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close filters">
            ✕
          </button>
        </div>

        <div className="ba-form compact">
          <Field label="Academic Structure">
            <select
              value={form.currentAcademicStructureId || ""}
              onChange={(event) => {
                updateForm(
                  "currentAcademicStructureId",
                  Number(event.target.value) || undefined,
                );
                updateForm("currentAcademicPeriodId", undefined);
              }}
            >
              <option value="">Select academic structure</option>
              {filteredAcademicStructures.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name} ({(item as any).level || "Level"})
                </option>
              ))}
            </select>
          </Field>

          <Field label="Academic Period">
            <select
              value={form.currentAcademicPeriodId || ""}
              onChange={(event) =>
                updateForm(
                  "currentAcademicPeriodId",
                  Number(event.target.value) || undefined,
                )
              }
            >
              <option value="">Select academic period</option>
              {filteredAcademicPeriods.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </Field>

          <Field label="Academic Year">
            <input
              value={form.academicYear || ""}
              onChange={(event) =>
                updateForm("academicYear", event.target.value)
              }
              placeholder="e.g. 2025/2026"
            />
          </Field>

          <Field label="Current Term">
            <select
              value={form.currentTerm || "Term 1"}
              onChange={(event) =>
                updateForm("currentTerm", event.target.value)
              }
            >
              <option>Term 1</option>
              <option>Term 2</option>
              <option>Term 3</option>
              <option>Semester 1</option>
              <option>Semester 2</option>
            </select>
          </Field>

          <Field label="Theme">
            <select
              value={form.theme}
              onChange={(event) =>
                updateForm("theme", event.target.value as "light" | "dark")
              }
            >
              <option value="light">Light Theme</option>
              <option value="dark">Dark Theme</option>
            </select>
          </Field>

          <Field label="Mode">
            <select
              value={form.mode}
              onChange={(event) => updateForm("mode", event.target.value)}
            >
              <option value="manual">Manual Mode</option>
              <option value="auto">Auto Mode</option>
            </select>
          </Field>
        </div>

        <div className="ba-sheet-actions">
          <button
            type="button"
            onClick={() => {
              updateForm("currentAcademicStructureId", undefined);
              updateForm("currentAcademicPeriodId", undefined);
              updateForm("academicYear", "");
              updateForm("currentTerm", "Term 1");
              updateForm("theme", "light");
              updateForm("mode", "manual");
            }}
          >
            Clear
          </button>
          <button type="button" className="primary" onClick={onClose}>
            Apply
          </button>
        </div>
      </section>
    </div></EleeveonFullscreenOverlay>
  );
}

function MoreSheet({
  view = "branch",
  viewMode,
  onChangeView,
  savingAll,
  onSave,
  onRefresh,
  openSection,
  onClose,
}: {
  view?: "branch" | "reports";
  viewMode: SettingsDisplayMode;
  onChangeView: (mode: SettingsDisplayMode) => void;
  savingAll: boolean;
  onSave: () => void | Promise<void>;
  onRefresh: () => void | Promise<void>;
  openSection: (section: SettingsSection) => void;
  onClose: () => void;
}) {
  const sections: {
    key: SettingsSection;
    icon: string;
    label: string;
    note: string;
  }[] = [
    {
      key: "academic",
      icon: "📚",
      label: "Academic Defaults",
      note: "Structure, period, term and year",
    },
    {
      key: "school",
      icon: "🏫",
      label: "School Identity",
      note: "Name, motto, contacts and logo",
    },
    {
      key: "branch",
      icon: "🏢",
      label: "Branch Identity",
      note: "Branch name, code, contact and media",
    },
    { key: "admissionNumbers", icon: "#", label: "Admission Numbers", note: "Sequence and prefix" },
    {
      key: "appearance",
      icon: "🎨",
      label: "Appearance",
      note: "Theme, primary color and font",
    },
    {
      key: "dashboardMedia",
      icon: "🖼️",
      label: "Dashboard Media",
      note: "Portal and dashboard images",
    },
    {
      key: "portalHighlights",
      icon: "🎞️",
      label: "Portal Highlights",
      note: "Rotating dashboard images and short videos",
    },
    {
      key: "reportMedia",
      icon: "📄",
      label: "Report Branding",
      note: "Report images, watermark and signature",
    },
    {
      key: "reportTemplates",
      icon: "🧾",
      label: "Report Card Template",
      note: "Template, visibility, labels and report fields",
    },
    {
      key: "website",
      icon: "🌐",
      label: "School Website",
      note: "Template, domain, SEO and publishing",
    },
    {
      key: "idCards",
      icon: "🪪",
      label: "ID Cards",
      note: "Designs, visible details, student and teacher issuance",
    },
    {
      key: "gallery",
      icon: "🌄",
      label: "Gallery",
      note: "Branch experience images",
    },
  ];

  return (
    <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet small">
        <div className="ba-sheet-head">
          <div>
            <h2>More</h2>
            <p>Open a settings group or run quick actions.</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close menu">
            ✕
          </button>
        </div>

        <div className="ba-menu-list">
          <button type="button" className={viewMode === "cards" ? "active" : ""}
            onClick={() => { onChangeView("cards"); onClose(); }}>
            <span>▦</span><b>Cards</b><small>Compact cards, best for phones</small>
          </button>
          <button type="button" className={viewMode === "table" ? "active" : ""}
            onClick={() => { onChangeView("table"); onClose(); }}>
            <span>☷</span><b>Table</b><small>Compact columns, best for laptops</small>
          </button>
          {sections.filter(s => (view === "reports" ? ["reportMedia", "reportTemplates"] : ["academic", "school", "branch", "admissionNumbers", "appearance", "idCards"]).includes(s.key)).map((section) => (
            <button
              key={section.key}
              type="button"
              onClick={() => openSection(section.key)}
            >
              <span>{section.icon}</span>
              <b>{section.label}</b>
              <small>{section.note}</small>
            </button>
          ))}

          <button type="button" onClick={onSave} disabled={savingAll}>
            <span>✓</span>
            <b>{savingAll ? "Saving..." : "Save all"}</b>
            <small>Save school, branch and settings changes</small>
          </button>

          <button type="button" onClick={onRefresh}>
            <span>↻</span>
            <b>Refresh</b>
            <small>Reload local branch settings</small>
          </button>
        </div>
      </section>
    </div></EleeveonFullscreenOverlay>
  );
}

function AcademicSheet({
  form,
  savingSettings,
  filteredAcademicStructures,
  filteredAcademicPeriods,
  updateForm,
  saveSchoolBranchSettings,
  onClose,
}: {
  form: SettingsForm;
  savingSettings: boolean;
  filteredAcademicStructures: AcademicStructure[];
  filteredAcademicPeriods: AcademicPeriod[];
  updateForm: (key: keyof SettingsForm, value: any) => void;
  saveSchoolBranchSettings: (
    options?: boolean | SaveOptions,
  ) => Promise<boolean>;
  onClose: () => void;
}) {
  return (
    <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet">
        <div className="ba-sheet-head">
          <div>
            <h2>Academic Defaults</h2>
            <p>
              Set current structure, period, academic year and term for this
              branch.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close academic defaults"
          >
            ✕
          </button>
        </div>

        <div className="ba-form compact">
          <Field label="Academic Structure">
            <select
              value={form.currentAcademicStructureId || ""}
              onChange={(event) => {
                updateForm(
                  "currentAcademicStructureId",
                  Number(event.target.value) || undefined,
                );
                updateForm("currentAcademicPeriodId", undefined);
              }}
            >
              <option value="">Select Academic Structure</option>
              {filteredAcademicStructures.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name} ({(item as any).level || "Level"})
                </option>
              ))}
            </select>
          </Field>

          <Field label="Academic Period">
            <select
              value={form.currentAcademicPeriodId || ""}
              onChange={(event) =>
                updateForm(
                  "currentAcademicPeriodId",
                  Number(event.target.value) || undefined,
                )
              }
            >
              <option value="">Select Academic Period</option>
              {filteredAcademicPeriods.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </Field>

          <Field label="Academic Year">
            <input
              value={form.academicYear || ""}
              onChange={(event) =>
                updateForm("academicYear", event.target.value)
              }
              placeholder="e.g. 2025/2026"
            />
          </Field>

          <Field label="Current Term">
            <select
              value={form.currentTerm || "Term 1"}
              onChange={(event) =>
                updateForm("currentTerm", event.target.value)
              }
            >
              <option>Term 1</option>
              <option>Term 2</option>
              <option>Term 3</option>
              <option>Semester 1</option>
              <option>Semester 2</option>
            </select>
          </Field>

          <Field label="Mode">
            <select
              value={form.mode}
              onChange={(event) => updateForm("mode", event.target.value)}
            >
              <option value="manual">Manual Mode</option>
              <option value="auto">Auto Mode</option>
            </select>
          </Field>
        </div>

        <div className="ba-sheet-actions">
          <button type="button" onClick={onClose}>
            Cancel
          </button>
          <button
            type="button"
            className="primary"
            disabled={savingSettings}
            onClick={async () => {
              const saved = await saveSchoolBranchSettings();
              if (saved) onClose();
            }}
          >
            {savingSettings ? "Saving..." : "Save"}
          </button>
        </div>
      </section>
    </div></EleeveonFullscreenOverlay>
  );
}

function SchoolSheet({
  schoolForm,
  savingSchool,
  updateSchoolField,
  uploadSchoolImage,
  saveSchoolIdentity,
  clearImage,
  onClose,
}: {
  schoolForm: SchoolForm;
  savingSchool: boolean;
  updateSchoolField: (key: keyof SchoolForm, value: any) => void;
  uploadSchoolImage: (
    field: keyof SchoolForm,
    file?: File,
  ) => void | Promise<void>;
  saveSchoolIdentity: (options?: boolean | SaveOptions) => Promise<boolean>;
  clearImage: (field: keyof SchoolForm) => void;
  onClose: () => void;
}) {
  return (
    <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet">
        <div className="ba-sheet-head">
          <div>
            <h2>School Identity</h2>
            <p>School identity remains on the school record.</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close school identity"
          >
            ✕
          </button>
        </div>

        <div className="ba-form compact">
          <Field label="School Name">
            <input
              value={schoolForm.name || ""}
              onChange={(event) =>
                updateSchoolField("name", event.target.value)
              }
            />
          </Field>
          <Field label="Motto">
            <input
              value={schoolForm.motto || ""}
              onChange={(event) =>
                updateSchoolField("motto", event.target.value)
              }
            />
          </Field>
          <Field label="Location">
            <input
              value={schoolForm.location || ""}
              onChange={(event) =>
                updateSchoolField("location", event.target.value)
              }
            />
          </Field>
          <Field label="Address">
            <input
              value={schoolForm.address || ""}
              onChange={(event) =>
                updateSchoolField("address", event.target.value)
              }
            />
          </Field>
          <Field label="Email">
            <input
              value={schoolForm.email || ""}
              onChange={(event) =>
                updateSchoolField("email", event.target.value)
              }
            />
          </Field>
          <Field label="Phone">
            <input
              value={schoolForm.phone || ""}
              onChange={(event) =>
                updateSchoolField("phone", event.target.value)
              }
            />
          </Field>
          <Field label="Website">
            <input
              value={schoolForm.website || ""}
              onChange={(event) =>
                updateSchoolField("website", event.target.value)
              }
            />
          </Field>
        </div>

        <div className="branch-media-grid">
          <GenericImageUploader
            label="School Logo"
            field="logo"
            helper="Official school logo stored on the school record."
            value={schoolForm.logo || ""}
            upload={uploadSchoolImage}
            clear={() => clearImage("logo")}
          />
          <GenericImageUploader
            label="School Banner"
            field="bannerImage"
            helper="General school banner stored on the school record."
            value={schoolForm.bannerImage || ""}
            upload={uploadSchoolImage}
            clear={() => clearImage("bannerImage")}
          />
        </div>

        <div className="ba-sheet-actions">
          <button type="button" onClick={onClose}>
            Cancel
          </button>
          <button
            type="button"
            className="primary"
            disabled={savingSchool}
            onClick={async () => {
              await saveSchoolIdentity();
              onClose();
            }}
          >
            {savingSchool ? "Saving..." : "Save"}
          </button>
        </div>
      </section>
    </div></EleeveonFullscreenOverlay>
  );
}

function BranchSheet({
  branchForm,
  savingBranch,
  updateBranchField,
  uploadBranchImage,
  saveBranchIdentity,
  clearImage,
  onClose,
}: {
  branchForm: BranchForm;
  savingBranch: boolean;
  updateBranchField: (key: keyof BranchForm, value: any) => void;
  uploadBranchImage: (
    field: keyof BranchForm,
    file?: File,
  ) => void | Promise<void>;
  saveBranchIdentity: (options?: boolean | SaveOptions) => Promise<boolean>;
  clearImage: (field: keyof BranchForm) => void;
  onClose: () => void;
}) {
  return (
    <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet">
        <div className="ba-sheet-head">
          <div>
            <h2>Branch Identity</h2>
            <p>Branch identity remains on the assigned branch record.</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close branch identity"
          >
            ✕
          </button>
        </div>

        {!branchForm.id && (
          <div className="ba-warning">
            Assigned branch record was not found.
          </div>
        )}

        <div className="ba-form compact">
          <Field label="Branch Name">
            <input
              value={branchForm.name || ""}
              onChange={(event) =>
                updateBranchField("name", event.target.value)
              }
            />
          </Field>
          <Field label="Branch Code">
            <input
              value={branchForm.code || ""}
              onChange={(event) =>
                updateBranchField("code", event.target.value)
              }
            />
          </Field>
          <Field label="Location / City">
            <input
              value={branchForm.location || ""}
              onChange={(event) => {
                updateBranchField("location", event.target.value);
                updateBranchField("city", event.target.value);
              }}
            />
          </Field>
          <Field label="Address">
            <input
              value={branchForm.address || ""}
              onChange={(event) =>
                updateBranchField("address", event.target.value)
              }
            />
          </Field>
          <Field label="Email">
            <input
              value={branchForm.email || ""}
              onChange={(event) =>
                updateBranchField("email", event.target.value)
              }
            />
          </Field>
          <Field label="Phone">
            <input
              value={branchForm.phone || ""}
              onChange={(event) =>
                updateBranchField("phone", event.target.value)
              }
            />
          </Field>
          <Field label="Website">
            <input
              value={branchForm.website || ""}
              onChange={(event) =>
                updateBranchField("website", event.target.value)
              }
            />
          </Field>
        </div>

        <div className="branch-media-grid">
          <GenericImageUploader
            label="Branch Logo"
            field="logo"
            helper="Optional branch-specific logo stored on the branch record."
            value={branchForm.logo || ""}
            upload={uploadBranchImage}
            clear={() => clearImage("logo")}
          />
          <GenericImageUploader
            label="Branch Banner"
            field="bannerImage"
            helper="Optional branch-specific banner stored on the branch record."
            value={branchForm.bannerImage || ""}
            upload={uploadBranchImage}
            clear={() => clearImage("bannerImage")}
          />
        </div>

        <div className="ba-sheet-actions">
          <button type="button" onClick={onClose}>
            Cancel
          </button>
          <button
            type="button"
            className="primary"
            disabled={savingBranch}
            onClick={async () => {
              await saveBranchIdentity();
              onClose();
            }}
          >
            {savingBranch ? "Saving..." : "Save"}
          </button>
        </div>
      </section>
    </div></EleeveonFullscreenOverlay>
  );
}

function PersonalThemePreference() {
  const [mode, setMode] = React.useState<"light" | "dark" | "system">("system");
  React.useEffect(() => {
    try {
      const workspace = JSON.parse(localStorage.getItem("eleeveon_open_workspace") || "{}");
      const membership = workspace.membership || {};
      const userId = membership.userId || membership.appUserId || workspace.userId;
      const accountId = membership.accountId || workspace.accountId;
      if (!userId || !accountId) return;
      const saved = localStorage.getItem(`eleeveon_theme:${accountId}:${userId}`);
      if (saved === "light" || saved === "dark" || saved === "system") setMode(saved);
    } catch {}
  }, []);
  const change = (value: "light" | "dark" | "system") => {
    setMode(value);
    try {
      const workspace = JSON.parse(localStorage.getItem("eleeveon_open_workspace") || "{}");
      const membership = workspace.membership || {};
      const userId = membership.userId || membership.appUserId || workspace.userId;
      const accountId = membership.accountId || workspace.accountId;
      if (!userId || !accountId) return;
      localStorage.setItem(`eleeveon_theme:${accountId}:${userId}`, value);
      window.dispatchEvent(new CustomEvent("eleeveon-personal-theme-changed", { detail: { userId, accountId, theme: value } }));
    } catch {}
  };
  return <select aria-label="My theme" value={mode} onChange={e => change(e.target.value as any)}><option value="system">Follow device</option><option value="light">Light</option><option value="dark">Dark</option></select>;
}

function AppearanceSheet({
  form,
  savingSettings,
  updateForm,
  saveSchoolBranchSettings,
  previewStyle,
  schoolName,
  branchName,
  onClose,
}: {
  form: SettingsForm;
  savingSettings: boolean;
  updateForm: (key: keyof SettingsForm, value: any) => void;
  saveSchoolBranchSettings: (
    options?: boolean | SaveOptions,
  ) => Promise<boolean>;
  previewStyle: React.CSSProperties;
  schoolName: string;
  branchName: string;
  onClose: () => void;
}) {
  return (
    <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet">
        <div className="ba-sheet-head">
          <div>
            <h2>Appearance</h2>
            <p>Brand colour and typography are shared. Your light/dark choice is personal.</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close appearance">
            ✕
          </button>
        </div>

        <div className="ba-form compact">
          <div className="ba-field"><label>My display mode</label><PersonalThemePreference /></div>
          <Field label="Font Family">
            <select
              value={form.fontFamily}
              onChange={(event) => updateForm("fontFamily", event.target.value)}
            >
              {fontOptions.map((font) => (
                <option key={font.value} value={font.value}>
                  {font.label}
                </option>
              ))}
            </select>
          </Field>

          <Field label="Font Size">
            <input
              type="number"
              min={12}
              max={22}
              value={form.fontSize}
              onChange={(event) =>
                updateForm("fontSize", Number(event.target.value))
              }
            />
          </Field>

          <Field label="Primary Color">
            <input
              className="branch-color-input"
              type="color"
              value={form.primaryColor}
              onChange={(event) =>
                updateForm("primaryColor", event.target.value)
              }
            />
          </Field>

          
        </div>

        <div className="branch-live-preview sheet-preview" style={previewStyle}>
          <div
            className="branch-preview-aa"
            style={{
              background: form.primaryColor,
              color: getContrastTextColor(form.primaryColor),
            }}
          >
            Aa
          </div>
          <div>
            <strong>
              {schoolName} · {branchName}
            </strong>
            <span>Live Branch Theme Preview</span>
          </div>
        </div>

        <div className="ba-sheet-actions">
          <button type="button" onClick={onClose}>
            Cancel
          </button>
          <button
            type="button"
            className="primary"
            disabled={savingSettings}
            onClick={async () => {
              const saved = await saveSchoolBranchSettings({
                includeAppearance: true,
              });
              if (saved) onClose();
            }}
          >
            {savingSettings ? "Saving..." : "Save"}
          </button>
        </div>
      </section>
    </div></EleeveonFullscreenOverlay>
  );
}

function ReportTemplateSheet({
  form,
  templates,
  settingsForm,
  schoolName,
  branchName,
  saving,
  updateField,
  saveReportCardTemplateSettings,
  onClose,
}: {
  form: ReportTemplateForm;
  templates: ReportTemplateRow[];
  settingsForm: SettingsForm;
  schoolName: string;
  branchName: string;
  saving: boolean;
  updateField: (key: keyof ReportTemplateForm, value: any) => void;
  saveReportCardTemplateSettings: (
    options?: boolean | SaveOptions,
  ) => Promise<boolean>;
  onClose: () => void;
}) {
  const reportTabGroups: {
    title: string;
    tabs: { key: ReportTemplateReportType; label: string; note: string }[];
  }[] = [
    {
      title: "Academic Reports",
      tabs: [
        {
          key: "student_report",
          label: "Student Report Cards",
          note: "Existing template gallery and display controls.",
        },
        {
          key: "cumulative_book",
          label: "Cumulative Report Book",
          note: "Student report templates assembled as printable booklets.",
        },
        {
          key: "cumulative_transcript",
          label: "Cumulative Transcript",
          note: "Official transcript-style academic history.",
        },
      ],
    },
    {
      title: "Broadsheets",
      tabs: [
        {
          key: "subject_broadsheet",
          label: "Subject Broadsheet",
          note: "Assessment breakdown and subject performance.",
        },
        {
          key: "class_broadsheet",
          label: "Class Broadsheet",
          note: "Students across all subjects for one period.",
        },
        {
          key: "annual_broadsheet",
          label: "Annual Broadsheet",
          note: "Cumulative class performance across periods.",
        },
      ],
    },
  ];

  const activeReportType = (form.reportType ||
    "student_report") as ReportTemplateReportType;

  const studentTemplates = reportTemplateDefinitionOptions(
    "student_report",
  ).map((definition) => {
    const existing = templates.find(
      (row: any) =>
        (row.reportType === "student_report" || !row.reportType) &&
        (sameId(row.code, definition.code) ||
          sameId(row.layoutKey, definition.layoutKey)),
    );
    return { ...definition, ...(existing || {}) };
  });

  const bookTemplates = reportTemplateDefinitionOptions("cumulative_book").map(
    (definition) => {
      const existing = templates.find(
        (row: any) =>
          row.reportType === "cumulative_book" &&
          (sameId(row.code, definition.code) ||
            sameId(row.layoutKey, definition.layoutKey)),
      );
      return { ...definition, ...(existing || {}) };
    },
  );

  const transcriptTemplates = reportTemplateDefinitionOptions(
    "cumulative_transcript",
  ).map((definition) => {
    const existing = templates.find(
      (row: any) =>
        row.reportType === "cumulative_transcript" &&
        (sameId(row.code, definition.code) ||
          sameId(row.layoutKey, definition.layoutKey)),
    );
    return { ...definition, ...(existing || {}) };
  });

  const subjectBroadsheetTemplates =
    reportTemplateDefinitionOptions("subject_broadsheet");
  const classBroadsheetTemplates =
    reportTemplateDefinitionOptions("class_broadsheet");
  const annualBroadsheetTemplates =
    reportTemplateDefinitionOptions("annual_broadsheet");

  const galleryTemplates =
    activeReportType === "cumulative_book"
      ? bookTemplates
      : activeReportType === "cumulative_transcript"
        ? transcriptTemplates
        : activeReportType === "subject_broadsheet"
          ? subjectBroadsheetTemplates
          : activeReportType === "class_broadsheet"
            ? classBroadsheetTemplates
            : activeReportType === "annual_broadsheet"
              ? annualBroadsheetTemplates
              : studentTemplates;

  const previewDataset = useMemo(
    () =>
      createDummyStudentReportPreviewDataset({
        schoolName,
        branchName,
        primaryColor: settingsForm.primaryColor,
        fontFamily: settingsForm.fontFamily,
        logo: settingsForm.logo,
        reportCardBackgroundImage: settingsForm.reportCardBackgroundImage,
        reportCardWatermark: settingsForm.reportCardWatermark,
        reportCardSignatureImage: settingsForm.reportCardSignatureImage,
      }),
    [
      schoolName,
      branchName,
      settingsForm.primaryColor,
      settingsForm.fontFamily,
      settingsForm.logo,
      settingsForm.reportCardBackgroundImage,
      settingsForm.reportCardWatermark,
      settingsForm.reportCardSignatureImage,
    ],
  );

  const bookPreviewDataset = useMemo(
    () =>
      createDummyCumulativeReportBookPreviewDataset({
        schoolName,
        branchName,
        primaryColor: settingsForm.primaryColor,
        fontFamily: settingsForm.fontFamily,
        logo: settingsForm.logo,
        reportCardBackgroundImage: settingsForm.reportCardBackgroundImage,
        reportCardWatermark: settingsForm.reportCardWatermark,
        reportCardSignatureImage: settingsForm.reportCardSignatureImage,
      }),
    [
      schoolName,
      branchName,
      settingsForm.primaryColor,
      settingsForm.fontFamily,
      settingsForm.logo,
      settingsForm.reportCardBackgroundImage,
      settingsForm.reportCardWatermark,
      settingsForm.reportCardSignatureImage,
    ],
  );

  const transcriptPreviewDataset = useMemo(
    () =>
      createDummyCumulativeTranscriptPreviewDataset({
        schoolName,
        branchName,
        primaryColor: settingsForm.primaryColor,
        fontFamily: settingsForm.fontFamily,
        logo: settingsForm.logo,
        reportCardWatermark: settingsForm.reportCardWatermark,
      }),
    [
      schoolName,
      branchName,
      settingsForm.primaryColor,
      settingsForm.fontFamily,
      settingsForm.logo,
      settingsForm.reportCardWatermark,
    ],
  );

  const broadsheetPreviewHeader = useMemo(
    () =>
      createDummyBroadsheetPreviewHeader({
        schoolName,
        branchName,
        primaryColor: settingsForm.primaryColor,
        fontFamily: settingsForm.fontFamily,
        logo: settingsForm.logo,
        reportCardBackgroundImage: settingsForm.reportCardBackgroundImage,
        reportCardWatermark: settingsForm.reportCardWatermark,
        reportCardSignatureImage: settingsForm.reportCardSignatureImage,
      }),
    [
      schoolName,
      branchName,
      settingsForm.primaryColor,
      settingsForm.fontFamily,
      settingsForm.logo,
      settingsForm.reportCardBackgroundImage,
      settingsForm.reportCardWatermark,
      settingsForm.reportCardSignatureImage,
    ],
  );

  const subjectBroadsheetPreviewDataset = useMemo(
    () => createDummySubjectBroadsheetPreviewDataset(),
    [],
  );
  const classBroadsheetPreviewDataset = useMemo(
    () => createDummyClassBroadsheetPreviewDataset(),
    [],
  );
  const annualBroadsheetPreviewDataset = useMemo(
    () => createDummyAnnualBroadsheetPreviewDataset(),
    [],
  );

  const isBroadsheetType = activeReportType.endsWith("_broadsheet");
  const activeBroadsheetKind =
    activeReportType === "class_broadsheet"
      ? "class"
      : activeReportType === "annual_broadsheet"
        ? "annual"
        : "subject";
  const activeBroadsheetDataset =
    activeReportType === "class_broadsheet"
      ? classBroadsheetPreviewDataset
      : activeReportType === "annual_broadsheet"
        ? annualBroadsheetPreviewDataset
        : subjectBroadsheetPreviewDataset;

  const selectedPreviewTemplate =
    galleryTemplates.find((item) => sameId(item.code, form.templateCode)) ||
    galleryTemplates.find((item) => sameId(item.layoutKey, form.layoutKey)) ||
    (activeReportType === "cumulative_transcript"
      ? getCumulativeTranscriptTemplateRegistryItem(form.templateCode)
      : isBroadsheetType
        ? getBroadsheetTemplateRegistryItem(form.templateCode)
        : getStudentReportTemplateRegistryItem(form.templateCode)) ||
    defaultReportTemplateDefinition(activeReportType);

  const selectedPreviewSettings = reportTemplatePreviewSettingsFromForm(
    form,
    selectedPreviewTemplate as any,
  );

  const studentVisibilityControls: {
    key: keyof ReportTemplateForm;
    label: string;
    note: string;
  }[] = [
    {
      key: "showSubjectPosition",
      label: "Subject Positions",
      note: "Remove the subject position column entirely when off.",
    },
    {
      key: "showClassPosition",
      label: "Class Position",
      note: "Remove class position summary entirely when off.",
    },
    {
      key: "showNumberOnRoll",
      label: "Number On Roll",
      note: "Show class size/roll count only for schools that want it.",
    },
    {
      key: "showAttendance",
      label: "Attendance",
      note: "Show attendance count section.",
    },
    {
      key: "showAttendancePercent",
      label: "Attendance Percentage",
      note: "Show attendance percentage field.",
    },
    {
      key: "showStudentPhoto",
      label: "Student Photo",
      note: "Show or hide student photo box.",
    },
    {
      key: "showTeacherNames",
      label: "Subject Teacher Names",
      note: "Show teacher name under each subject.",
    },
    {
      key: "showCurrentAcademicPeriodEnd",
      label: "Current Period End",
      note: "Show this academic period ends line before the next period line.",
    },
    {
      key: "showNextAcademicPeriod",
      label: "Next Academic Period",
      note: "Show reopening/next period begins line.",
    },
    {
      key: "showPromotionStatus",
      label: "Promotion Status",
      note: "Show promote/repeat/graduate status when available.",
    },
    { key: "showGPA", label: "GPA", note: "Show GPA summary field." },
    {
      key: "showAverage",
      label: "Average",
      note: "Show average summary field.",
    },
    { key: "showTotal", label: "Total", note: "Show total summary field." },
    { key: "showGrade", label: "Grade", note: "Show grade column." },
    {
      key: "showSubjectRemarks",
      label: "Subject Remarks",
      note: "Show subject remark column.",
    },
    {
      key: "showWatermark",
      label: "Watermark",
      note: "Use saved report watermark on report cards.",
    },
    {
      key: "showParentSignature",
      label: "Parent Signature",
      note: "Show parent/guardian signature area.",
    },
    {
      key: "showGeneratedDate",
      label: "Generated Date",
      note: "Show generated/printed date using the selected label.",
    },
  ];

  const bookControls: {
    key: keyof ReportTemplateForm;
    label: string;
    note: string;
  }[] = [
    {
      key: "showBookFrontCover",
      label: "Front Cover",
      note: "Start the cumulative book with a designed cover page.",
    },
    {
      key: "showBookStudentProfilePage",
      label: "Student Profile Page",
      note: "Show student identity, parent and branch profile details.",
    },
    {
      key: "showBookAcademicJourneyPage",
      label: "Academic Journey Page",
      note: "Show the student's period-by-period progress timeline.",
    },
    {
      key: "showBookSummaryPage",
      label: "Summary Page",
      note: "Show cumulative average, GPA, trend and final recommendation.",
    },
    {
      key: "showBookBackCover",
      label: "Back Cover",
      note: "End the printable booklet with an official closing cover.",
    },
    {
      key: "showGeneratedDate",
      label: "Generated Date",
      note: "Show generated/printed date on cover and info pages.",
    },
    {
      key: "showWatermark",
      label: "Watermark",
      note: "Use saved report watermark on book pages.",
    },
  ];

  const transcriptControls: {
    key: keyof ReportTemplateForm;
    label: string;
    note: string;
  }[] = [
    {
      key: "showTranscriptTermBreakdown",
      label: "Term / Period Breakdown",
      note: "Show subject rows grouped under each academic period.",
    },
    {
      key: "showTranscriptYearAverage",
      label: "Year Average",
      note: "Show academic-year average/statistics where available.",
    },
    {
      key: "showTranscriptCumulativeAverage",
      label: "Cumulative Average",
      note: "Show overall cumulative average in the transcript summary.",
    },
    {
      key: "showTranscriptCumulativePosition",
      label: "Cumulative Position",
      note: "Show latest/cumulative rank or position where available.",
    },
    {
      key: "showTranscriptGPAProgression",
      label: "GPA Progression",
      note: "Show term GPA and cumulative GPA values.",
    },
    {
      key: "showTranscriptFinalRecommendation",
      label: "Final Recommendation",
      note: "Show promote/repeat/graduate recommendation.",
    },
    {
      key: "showStudentPhoto",
      label: "Student Photo",
      note: "Show student photo if the template supports it.",
    },
    {
      key: "showGeneratedDate",
      label: "Generated Date",
      note: "Show generated/printed date in transcript footer or metadata.",
    },
    {
      key: "showWatermark",
      label: "Watermark",
      note: "Use saved report watermark on transcripts.",
    },
  ];

  const broadsheetSharedControls: {
    key: keyof ReportTemplateForm;
    label: string;
    note: string;
  }[] = [
    {
      key: "showBroadsheetLogo",
      label: "School Logo",
      note: "Show the resolved school or branch logo.",
    },
    {
      key: "showBroadsheetWatermark",
      label: "Watermark",
      note: "Use the saved report watermark.",
    },
    {
      key: "showBroadsheetGeneratedDate",
      label: "Generated Date",
      note: "Show generated or printed date.",
    },
    {
      key: "showBroadsheetPageNumber",
      label: "Page Number",
      note: "Show page numbering in the footer.",
    },
    {
      key: "showBroadsheetSignatures",
      label: "Signatures",
      note: "Show official sign-off areas.",
    },
    {
      key: "showBroadsheetSummary",
      label: "Summary",
      note: "Show top academic summary statistics.",
    },
    {
      key: "showBroadsheetStatistics",
      label: "Statistics",
      note: "Show additional statistics and period context.",
    },
    {
      key: "showBroadsheetStudentPhoto",
      label: "Student Photos",
      note: "Show student photos when available.",
    },
  ];
  const subjectBroadsheetControls = [
    ...broadsheetSharedControls,
    {
      key: "showBroadsheetAssessmentBreakdown",
      label: "Assessment Breakdown",
      note: "Show assessment component columns.",
    },
    {
      key: "showBroadsheetWeightedTotal",
      label: "Weighted Total",
      note: "Show weighted total.",
    },
    {
      key: "showBroadsheetPercentage",
      label: "Percentage",
      note: "Show final percentage.",
    },
    { key: "showBroadsheetGrade", label: "Grade", note: "Show grade column." },
    { key: "showBroadsheetGPA", label: "GPA", note: "Show GPA." },
    {
      key: "showBroadsheetPosition",
      label: "Position",
      note: "Show subject position.",
    },
    {
      key: "showBroadsheetRemark",
      label: "Remark",
      note: "Show remark column.",
    },
    {
      key: "showBroadsheetHighestScore",
      label: "Highest Score",
      note: "Show highest score statistic.",
    },
    {
      key: "showBroadsheetLowestScore",
      label: "Lowest Score",
      note: "Show lowest score statistic.",
    },
    {
      key: "showBroadsheetClassAverage",
      label: "Class Average",
      note: "Show class average statistic.",
    },
  ] as { key: keyof ReportTemplateForm; label: string; note: string }[];
  const classBroadsheetControls = [
    ...broadsheetSharedControls,
    {
      key: "showBroadsheetSubjectScores",
      label: "Subject Scores",
      note: "Show all subject columns.",
    },
    {
      key: "showBroadsheetSubjectGrades",
      label: "Subject Grades",
      note: "Show grades below scores.",
    },
    { key: "showBroadsheetTotal", label: "Total", note: "Show total column." },
    {
      key: "showBroadsheetAverage",
      label: "Average",
      note: "Show average column.",
    },
    { key: "showBroadsheetGPA", label: "GPA", note: "Show GPA column." },
    {
      key: "showBroadsheetClassPosition",
      label: "Class Position",
      note: "Show class position.",
    },
    {
      key: "showBroadsheetAttendance",
      label: "Attendance",
      note: "Show attendance percentage.",
    },
    {
      key: "showBroadsheetClassHighestAverage",
      label: "Highest Average",
      note: "Show highest average.",
    },
    {
      key: "showBroadsheetClassLowestAverage",
      label: "Lowest Average",
      note: "Show lowest average.",
    },
  ] as { key: keyof ReportTemplateForm; label: string; note: string }[];
  const annualBroadsheetControls = [
    ...broadsheetSharedControls,
    {
      key: "showBroadsheetPeriodScores",
      label: "Period Scores",
      note: "Show period scores under subject averages.",
    },
    {
      key: "showBroadsheetAnnualAverage",
      label: "Annual Average",
      note: "Show annual average.",
    },
    {
      key: "showBroadsheetAnnualGPA",
      label: "Annual GPA",
      note: "Show annual GPA.",
    },
    {
      key: "showBroadsheetAnnualPosition",
      label: "Annual Position",
      note: "Show annual rank.",
    },
    {
      key: "showBroadsheetTrend",
      label: "Trend",
      note: "Show performance trend where supported.",
    },
    {
      key: "showBroadsheetPromotionDecision",
      label: "Promotion Decision",
      note: "Show promote, repeat or graduate decision.",
    },
    {
      key: "showBroadsheetBestPeriod",
      label: "Best Period",
      note: "Show best period where supported.",
    },
    {
      key: "showBroadsheetLatestPeriod",
      label: "Latest Period",
      note: "Show latest period where supported.",
    },
  ] as { key: keyof ReportTemplateForm; label: string; note: string }[];

  const activeControls =
    activeReportType === "cumulative_book"
      ? bookControls
      : activeReportType === "cumulative_transcript"
        ? transcriptControls
        : activeReportType === "subject_broadsheet"
          ? subjectBroadsheetControls
          : activeReportType === "class_broadsheet"
            ? classBroadsheetControls
            : activeReportType === "annual_broadsheet"
              ? annualBroadsheetControls
              : studentVisibilityControls;

  const switchReportType = (reportType: ReportTemplateReportType) => {
    const defaultTemplate = defaultReportTemplateDefinition(reportType);
    updateField("reportType", reportType);
    selectReportTemplateIntoForm(defaultTemplate, updateField, reportType);
  };

  const renderPreviewCard = (
    template: ReportTemplateRow,
    templateSettings: any,
  ) => {
    if (isBroadsheetType) {
      return (
        <TemplatePreviewBroadsheetCard
          kind={activeBroadsheetKind}
          dataset={activeBroadsheetDataset}
          header={broadsheetPreviewHeader}
          template={template}
          settings={templateSettings}
          compact
          showWatermark={form.showBroadsheetWatermark}
          pageBreakAfter={false}
          mobilePreview={false}
        />
      );
    }
    if (activeReportType === "cumulative_book") {
      return (
        <TemplatePreviewCumulativeReportBook
          dataset={bookPreviewDataset}
          template={template}
          settings={templateSettings}
          compact
          showWatermark={form.showWatermark}
          pageBreakAfter={false}
          mobilePreview={false}
        />
      );
    }

    if (activeReportType === "cumulative_transcript") {
      return (
        <TemplatePreviewCumulativeTranscriptCard
          dataset={transcriptPreviewDataset}
          template={template}
          settings={templateSettings}
          compact
          showWatermark={form.showWatermark}
          pageBreakAfter={false}
          mobilePreview={false}
        />
      );
    }

    return (
      <TemplatePreviewStudentReportCard
        dataset={previewDataset}
        template={template}
        settings={templateSettings}
        compact
        showWatermark={form.showWatermark}
        pageBreakAfter={false}
        mobilePreview={false}
      />
    );
  };

  const renderFocusedPreview = () => {
    if (isBroadsheetType) {
      return (
        <TemplatePreviewBroadsheetCard
          kind={activeBroadsheetKind}
          dataset={activeBroadsheetDataset}
          header={broadsheetPreviewHeader}
          template={selectedPreviewTemplate}
          settings={selectedPreviewSettings}
          compact
          showWatermark={form.showBroadsheetWatermark}
          pageBreakAfter={false}
          mobilePreview
        />
      );
    }
    if (activeReportType === "cumulative_book") {
      return (
        <TemplatePreviewCumulativeReportBook
          dataset={bookPreviewDataset}
          template={selectedPreviewTemplate}
          settings={selectedPreviewSettings}
          compact
          showWatermark={form.showWatermark}
          pageBreakAfter={false}
          mobilePreview
        />
      );
    }

    if (activeReportType === "cumulative_transcript") {
      return (
        <TemplatePreviewCumulativeTranscriptCard
          dataset={transcriptPreviewDataset}
          template={selectedPreviewTemplate}
          settings={selectedPreviewSettings}
          compact
          showWatermark={form.showWatermark}
          pageBreakAfter={false}
          mobilePreview
        />
      );
    }

    return (
      <TemplatePreviewStudentReportCard
        dataset={previewDataset}
        template={selectedPreviewTemplate}
        settings={selectedPreviewSettings}
        compact
        showWatermark={form.showWatermark}
        pageBreakAfter={false}
        mobilePreview
      />
    );
  };

  return (
    <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet report-template-suite-sheet">
        <div className="ba-sheet-head">
          <div>
            <h2>Academic Document & Broadsheet Templates</h2>
            <p>
              Configure student reports, cumulative documents and separate
              subject, class and annual broadsheet defaults. Every tab saves its
              own template, settings and branch assignment.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close report template settings"
          >
            ✕
          </button>
        </div>

        <div className="report-template-tab-groups">
          {reportTabGroups.map((group) => (
            <section key={group.title} className="report-template-tab-group">
              <div className="report-template-tab-group-title">
                {group.title}
              </div>
              <div
                className="report-template-tabs"
                role="tablist"
                aria-label={`${group.title} template tabs`}
              >
                {group.tabs.map((tab) => (
                  <button
                    type="button"
                    key={tab.key}
                    className={activeReportType === tab.key ? "active" : ""}
                    onClick={() => switchReportType(tab.key)}
                  >
                    <strong>{tab.label}</strong>
                    <span>{tab.note}</span>
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className="ba-form compact">
          <Field
            label={
              activeReportType === "cumulative_book"
                ? "Book Style"
                : activeReportType === "cumulative_transcript"
                  ? "Transcript Template"
                  : "Template"
            }
          >
            <select
              value={form.templateCode || ""}
              onChange={(event) => {
                const templateCode = event.target.value;
                const selected =
                  galleryTemplates.find((item) =>
                    sameId(item.code, templateCode),
                  ) ||
                  galleryTemplates.find((item) =>
                    sameId(item.layoutKey, templateCode),
                  ) ||
                  (activeReportType === "cumulative_transcript"
                    ? getCumulativeTranscriptTemplateRegistryItem(templateCode)
                    : isBroadsheetType
                      ? getBroadsheetTemplateRegistryItem(templateCode)
                      : getStudentReportTemplateRegistryItem(templateCode));

                selectReportTemplateIntoForm(
                  selected as any,
                  updateField,
                  activeReportType,
                );
              }}
            >
              {galleryTemplates.map((template) => (
                <option
                  key={`${activeReportType}-${template.code || template.id || template.name}`}
                  value={template.code || template.layoutKey || ""}
                >
                  {template.name || template.code || "Report Template"}
                </option>
              ))}
            </select>
          </Field>

          <Field label="Template Name">
            <input value={form.templateName} readOnly />
          </Field>

          <Field label="Layout">
            <input value={form.layoutKey} readOnly />
          </Field>

          <Field label="Paper">
            <select
              value={form.paperSize}
              onChange={(event) =>
                updateField("paperSize", event.target.value as "A4" | "Letter")
              }
            >
              <option value="A4">A4</option>
              <option value="Letter">Letter</option>
            </select>
          </Field>

          <Field label="Orientation">
            <select
              value={form.orientation}
              onChange={(event) =>
                updateField(
                  "orientation",
                  event.target.value as "portrait" | "landscape",
                )
              }
            >
              <option value="portrait">Portrait</option>
              <option value="landscape">Landscape</option>
            </select>
          </Field>

          <Field label="Density">
            <select
              value={form.density}
              onChange={(event) =>
                updateField(
                  "density",
                  event.target.value as "compact" | "comfortable" | "spacious",
                )
              }
            >
              <option value="compact">Compact</option>
              <option value="comfortable">Comfortable</option>
              <option value="spacious">Spacious</option>
            </select>
          </Field>
        </div>

        <section className="branch-settings-subsection template-preview-studio">
          <div className="template-preview-studio-head">
            <div>
              <h3>
                {activeReportType === "cumulative_book"
                  ? "Cumulative Book Preview Studio"
                  : activeReportType === "cumulative_transcript"
                    ? "Transcript Preview Studio"
                    : "Student Report Preview Studio"}
              </h3>
              <p>
                {activeReportType === "cumulative_book"
                  ? "Preview each student-report style as a printable report book with covers and journey pages."
                  : activeReportType === "cumulative_transcript"
                    ? "Preview each transcript design using a dummy academic-history dataset."
                    : "Preview every student report-card design with the same dummy filled dataset before saving."}
              </p>
            </div>
            <span className="template-preview-badge">Preview only</span>
          </div>

          <div className="template-preview-gallery">
            {galleryTemplates.map((template) => {
              const templateCode = String(
                template.code || template.layoutKey || template.name || "",
              );
              const isSelected =
                sameId(template.code, form.templateCode) ||
                sameId(template.layoutKey, form.layoutKey) ||
                sameId(template.name, form.templateName);

              const templateSettings = reportTemplatePreviewSettingsFromForm(
                form,
                template,
              );

              return (
                <button
                  type="button"
                  key={`${activeReportType}-${templateCode || template.id || template.name}`}
                  className={`template-preview-card ${isSelected ? "selected" : ""}`}
                  onClick={() =>
                    selectReportTemplateIntoForm(
                      template,
                      updateField,
                      activeReportType,
                    )
                  }
                >
                  <span className="template-preview-card-top">
                    <strong>
                      {template.name || template.code || "Report Template"}
                    </strong>
                    <em>{isSelected ? "Selected" : "Tap to select"}</em>
                  </span>

                  <span className="template-preview-mini" aria-hidden="true">
                    <span className="template-preview-mini-scale">
                      {renderPreviewCard(template, templateSettings)}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>

          <div className="template-preview-focus">
            <div className="template-preview-focus-head">
              <strong>
                {selectedPreviewTemplate?.name ||
                  form.templateName ||
                  "Selected Template"}
              </strong>
              <span>
                Live fit-preview using the selected template and current display
                controls.
              </span>
            </div>
            {renderFocusedPreview()}
          </div>
        </section>

        <section className="branch-settings-subsection">
          <h3>
            {activeReportType === "cumulative_book"
              ? "Book Pages"
              : activeReportType === "cumulative_transcript"
                ? "Transcript Display Controls"
                : "Student Report Display Controls"}
          </h3>
          <p>
            Turn a field off to remove it from the printed output completely.
          </p>

          <div className="branch-report-toggle-grid">
            {activeControls.map((control) => (
              <label
                key={String(control.key)}
                className={`branch-report-toggle ${form[control.key] ? "is-on" : "is-off"}`}
              >
                <span>
                  <strong>{control.label}</strong>
                  <small>{control.note}</small>
                </span>

                <select
                  value={form[control.key] ? "yes" : "no"}
                  onChange={(event) =>
                    updateField(control.key, event.target.value === "yes")
                  }
                >
                  <option value="yes">Show</option>
                  <option value="no">Hide</option>
                </select>
              </label>
            ))}
          </div>
        </section>

        {(activeReportType === "student_report" ||
          activeReportType === "subject_broadsheet") && (
          <section className="branch-settings-subsection">
            <h3>Assessment hierarchy</h3>
            <p>
              Control whether printed reports use computed parent totals,
              direct child items, or both. Item rules come from the Assessment
              System editor.
            </p>

            <div className="ba-form compact">
              <Field label="Hierarchy display">
                <select
                  value={
                    activeReportType === "subject_broadsheet"
                      ? form.broadsheetAssessmentHierarchyDisplay
                      : form.assessmentHierarchyDisplay
                  }
                  onChange={(event) =>
                    updateField(
                      activeReportType === "subject_broadsheet"
                        ? "broadsheetAssessmentHierarchyDisplay"
                        : "assessmentHierarchyDisplay",
                      event.target.value,
                    )
                  }
                >
                  <option value="item_rules">Use Assessment System rules</option>
                  <option value="parents_only">Parent totals only</option>
                  <option value="children_only">Child items only</option>
                  <option value="parents_and_children">
                    Parents and child items
                  </option>
                  <option value="compact">Compact hierarchy</option>
                </select>
              </Field>

              <Field label="Maximum visible depth">
                <input
                  type="number"
                  min={0}
                  placeholder="No limit"
                  value={
                    (activeReportType === "subject_broadsheet"
                      ? form.broadsheetMaximumAssessmentDepth
                      : form.assessmentMaximumVisibleDepth) ?? ""
                  }
                  onChange={(event) =>
                    updateField(
                      activeReportType === "subject_broadsheet"
                        ? "broadsheetMaximumAssessmentDepth"
                        : "assessmentMaximumVisibleDepth",
                      event.target.value === ""
                        ? null
                        : Math.max(0, Number(event.target.value) || 0),
                    )
                  }
                />
              </Field>
            </div>

            <div className="branch-report-toggle-grid">
              {(activeReportType === "student_report"
                ? [
                    {
                      key: "showAssessmentBreakdown",
                      label: "Assessment Breakdown",
                      note: "Show assessment details below each subject.",
                    },
                    {
                      key: "showAssessmentParentItems",
                      label: "Parent Totals",
                      note: "Show computed groups such as Class Work.",
                    },
                    {
                      key: "showAssessmentChildItems",
                      label: "Child Items",
                      note: "Show tests, projects and other direct entries.",
                    },
                    {
                      key: "showCalculatedAssessmentItems",
                      label: "Calculated Items",
                      note: "Show values calculated from child items.",
                    },
                    {
                      key: "showAssessmentGroupHeaders",
                      label: "Group Headers",
                      note: "Show grouped assessment headings.",
                    },
                    {
                      key: "indentAssessmentChildren",
                      label: "Indent Children",
                      note: "Visually indent nested assessment items.",
                    },
                    {
                      key: "showAssessmentMaximumScores",
                      label: "Maximum Scores",
                      note: "Show each item's maximum score.",
                    },
                    {
                      key: "showAssessmentWeights",
                      label: "Weights",
                      note: "Show contribution weights.",
                    },
                    {
                      key: "showAssessmentRawScores",
                      label: "Raw Scores",
                      note: "Show entered or calculated raw scores.",
                    },
                    {
                      key: "showAssessmentWeightedScores",
                      label: "Weighted Scores",
                      note: "Show final weighted contributions.",
                    },
                    {
                      key: "showAssessmentHierarchyPath",
                      label: "Hierarchy Path",
                      note: "Show the full parent-to-child item path.",
                    },
                    {
                      key: "flattenSingleChildAssessmentGroups",
                      label: "Flatten Single Child Groups",
                      note: "Avoid redundant one-child group headings.",
                    },
                  ]
                : [
                    {
                      key: "showBroadsheetAssessmentBreakdown",
                      label: "Assessment Breakdown",
                      note: "Show assessment component columns.",
                    },
                    {
                      key: "broadsheetShowAssessmentGroupHeaders",
                      label: "Grouped Headers",
                      note: "Group child columns under their parent item.",
                    },
                  ]
              ).map((control) => (
                <label
                  key={control.key}
                  className={`branch-report-toggle ${
                    form[control.key as keyof ReportTemplateForm]
                      ? "is-on"
                      : "is-off"
                  }`}
                >
                  <span>
                    <strong>{control.label}</strong>
                    <small>{control.note}</small>
                  </span>
                  <select
                    value={
                      form[control.key as keyof ReportTemplateForm]
                        ? "yes"
                        : "no"
                    }
                    onChange={(event) =>
                      updateField(
                        control.key as keyof ReportTemplateForm,
                        event.target.value === "yes",
                      )
                    }
                  >
                    <option value="yes">Show</option>
                    <option value="no">Hide</option>
                  </select>
                </label>
              ))}
            </div>
          </section>
        )}

        <section className="branch-settings-subsection">
          <h3>
            {activeReportType === "cumulative_book"
              ? "Book Labels"
              : activeReportType === "cumulative_transcript"
                ? "Transcript Labels"
                : "Report Labels"}
          </h3>
          <p>
            Use each school's preferred wording without changing component code.
          </p>

          <div className="ba-form compact">
            {activeReportType === "student_report" && (
              <>
                <Field label="Class Teacher Label">
                  <input
                    value={form.classTeacherLabel}
                    onChange={(event) =>
                      updateField("classTeacherLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Headteacher Label">
                  <input
                    value={form.headTeacherLabel}
                    onChange={(event) =>
                      updateField("headTeacherLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Parent Label">
                  <input
                    value={form.parentLabel}
                    onChange={(event) =>
                      updateField("parentLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Principal Label">
                  <input
                    value={form.principalLabel}
                    onChange={(event) =>
                      updateField("principalLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Current Period End Label">
                  <input
                    value={form.currentAcademicPeriodEndLabel}
                    onChange={(event) =>
                      updateField(
                        "currentAcademicPeriodEndLabel",
                        event.target.value,
                      )
                    }
                  />
                </Field>
                <Field label="Next Period Label">
                  <input
                    value={form.nextAcademicPeriodLabel}
                    onChange={(event) =>
                      updateField("nextAcademicPeriodLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Number On Roll Label">
                  <input
                    value={form.numberOnRollLabel}
                    onChange={(event) =>
                      updateField("numberOnRollLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Class Position Label">
                  <input
                    value={form.classPositionLabel}
                    onChange={(event) =>
                      updateField("classPositionLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Subject Position Label">
                  <input
                    value={form.subjectPositionLabel}
                    onChange={(event) =>
                      updateField("subjectPositionLabel", event.target.value)
                    }
                  />
                </Field>
              </>
            )}

            {activeReportType === "cumulative_book" && (
              <>
                <Field label="Book Title">
                  <input
                    value={form.bookTitleLabel}
                    onChange={(event) =>
                      updateField("bookTitleLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Book Subtitle">
                  <input
                    value={form.bookSubtitleLabel}
                    onChange={(event) =>
                      updateField("bookSubtitleLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Student Label">
                  <input
                    value={form.studentNameLabel}
                    onChange={(event) =>
                      updateField("studentNameLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Admission / Student ID Label">
                  <input
                    value={form.admissionNumberLabel}
                    onChange={(event) =>
                      updateField("admissionNumberLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Academic Period Label">
                  <input
                    value={form.academicPeriodLabel}
                    onChange={(event) =>
                      updateField("academicPeriodLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Average Label">
                  <input
                    value={form.averageLabel}
                    onChange={(event) =>
                      updateField("averageLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="GPA Label">
                  <input
                    value={form.gpaLabel}
                    onChange={(event) =>
                      updateField("gpaLabel", event.target.value)
                    }
                  />
                </Field>
              </>
            )}

            {activeReportType === "cumulative_transcript" && (
              <>
                <Field label="Student Label">
                  <input
                    value={form.studentNameLabel}
                    onChange={(event) =>
                      updateField("studentNameLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Student ID Label">
                  <input
                    value={form.admissionNumberLabel}
                    onChange={(event) =>
                      updateField("admissionNumberLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Programme / Class Label">
                  <input
                    value={form.classLabel}
                    onChange={(event) =>
                      updateField("classLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Academic Period Label">
                  <input
                    value={form.academicPeriodLabel}
                    onChange={(event) =>
                      updateField("academicPeriodLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Course / Subject Label">
                  <input
                    value={form.subjectLabel}
                    onChange={(event) =>
                      updateField("subjectLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Score / Total Label">
                  <input
                    value={form.totalLabel}
                    onChange={(event) =>
                      updateField("totalLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Average Label">
                  <input
                    value={form.averageLabel}
                    onChange={(event) =>
                      updateField("averageLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Grade Label">
                  <input
                    value={form.gradeLabel}
                    onChange={(event) =>
                      updateField("gradeLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="GPA Label">
                  <input
                    value={form.gpaLabel}
                    onChange={(event) =>
                      updateField("gpaLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Position / Rank Label">
                  <input
                    value={form.subjectPositionLabel}
                    onChange={(event) =>
                      updateField("subjectPositionLabel", event.target.value)
                    }
                  />
                </Field>
              </>
            )}

            {isBroadsheetType && (
              <>
                <Field label="Broadsheet Title">
                  <input
                    value={form.broadsheetTitleLabel}
                    onChange={(event) =>
                      updateField("broadsheetTitleLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Student Column">
                  <input
                    value={form.studentColumnLabel}
                    onChange={(event) =>
                      updateField("studentColumnLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Admission Number Column">
                  <input
                    value={form.admissionNumberColumnLabel}
                    onChange={(event) =>
                      updateField(
                        "admissionNumberColumnLabel",
                        event.target.value,
                      )
                    }
                  />
                </Field>
                <Field label="Position Column">
                  <input
                    value={form.positionColumnLabel}
                    onChange={(event) =>
                      updateField("positionColumnLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Grade Column">
                  <input
                    value={form.gradeColumnLabel}
                    onChange={(event) =>
                      updateField("gradeColumnLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Remark Column">
                  <input
                    value={form.remarkColumnLabel}
                    onChange={(event) =>
                      updateField("remarkColumnLabel", event.target.value)
                    }
                  />
                </Field>
                <Field label="Generated Date Label">
                  <input
                    value={form.broadsheetGeneratedDateLabel}
                    onChange={(event) =>
                      updateField(
                        "broadsheetGeneratedDateLabel",
                        event.target.value,
                      )
                    }
                  />
                </Field>
                <Field label="Broadsheet Footer">
                  <input
                    value={form.broadsheetFooterText}
                    onChange={(event) =>
                      updateField("broadsheetFooterText", event.target.value)
                    }
                  />
                </Field>
              </>
            )}

            {!isBroadsheetType && (
              <Field label="Generated Date Label">
                <select
                  value={
                    generatedDateLabelOptions.includes(form.generatedDateLabel)
                      ? form.generatedDateLabel
                      : "__custom__"
                  }
                  onChange={(event) => {
                    if (event.target.value === "__custom__") return;
                    updateField("generatedDateLabel", event.target.value);
                  }}
                >
                  {generatedDateLabelOptions.map((label) => (
                    <option key={label} value={label}>
                      {label}
                    </option>
                  ))}
                  <option value="__custom__">Custom label...</option>
                </select>
              </Field>
            )}

            {!isBroadsheetType && (
              <>
                <Field label="Custom Generated Date Label">
                  <input
                    value={form.generatedDateLabel}
                    onChange={(event) =>
                      updateField("generatedDateLabel", event.target.value)
                    }
                    placeholder="Generated"
                  />
                </Field>
                <Field label="Footer Text">
                  <input
                    value={form.footerText}
                    onChange={(event) =>
                      updateField("footerText", event.target.value)
                    }
                    placeholder="Official academic document generated by Eleeveon Schools."
                  />
                </Field>
              </>
            )}
          </div>
        </section>

        <div className="ba-sheet-actions">
          <button type="button" onClick={onClose}>
            Cancel
          </button>
          <button
            type="button"
            className="primary"
            disabled={saving}
            onClick={async () => {
              await saveReportCardTemplateSettings();
              onClose();
            }}
          >
            {saving
              ? "Saving..."
              : activeReportType === "cumulative_book"
                ? "Save Cumulative Book"
                : activeReportType === "cumulative_transcript"
                  ? "Save Cumulative Transcript"
                  : activeReportType === "subject_broadsheet"
                    ? "Save Subject Broadsheet"
                    : activeReportType === "class_broadsheet"
                      ? "Save Class Broadsheet"
                      : activeReportType === "annual_broadsheet"
                        ? "Save Annual Broadsheet"
                        : "Save Student Report"}
          </button>
        </div>
      </section>
    </div></EleeveonFullscreenOverlay>
  );
}

function PortalHighlightsSheet({
  title,
  description,
  entityLabel,
  emptyText,
  rows,
  draft,
  saving,
  setDraft,
  editRow,
  uploadPrimary,
  uploadPoster,
  saveRow,
  removeRow,
  onClose,
}: {
  title: string;
  description: string;
  entityLabel: string;
  emptyText: string;
  rows: PortalHighlightRow[];
  draft: PortalHighlightDraft;
  saving: boolean;
  setDraft: React.Dispatch<React.SetStateAction<PortalHighlightDraft>>;
  editRow: (row?: PortalHighlightRow | null) => void;
  uploadPrimary: (file?: File) => void | Promise<void>;
  uploadPoster: (file?: File) => void | Promise<void>;
  saveRow: () => void | Promise<void>;
  removeRow: (row: PortalHighlightRow) => void | Promise<void>;
  onClose: () => void;
}) {
  const audienceOptions: Array<[PortalAudience, string]> = [
    ["all", "All portals"],
    ["branch_admin", "Branch Admin"],
    ["admin", "School Admin"],
    ["teacher", "Teachers"],
    ["student", "Students"],
    ["parent", "Parents"],
    ["accountant", "Accountants"],
  ];

  const toggleAudience = (audience: PortalAudience) => {
    setDraft((current) => {
      if (audience === "all") {
        return { ...current, audiences: ["all"] };
      }

      const withoutAll = current.audiences.filter((item) => item !== "all");
      const exists = withoutAll.includes(audience);
      const audiences = exists
        ? withoutAll.filter((item) => item !== audience)
        : [...withoutAll, audience];

      return { ...current, audiences: audiences.length ? audiences : ["all"] };
    });
  };

  return (
    <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet portal-highlight-sheet">
        <div className="ba-sheet-head">
          <div>
            <h2>{title}</h2>
            <p>{description}</p>
          </div>
          <button type="button" onClick={onClose}>✕</button>
        </div>

        <div className="portal-highlight-layout">
          <div className="portal-highlight-list">
            <div className="portal-highlight-list-head">
              <b>Saved {title.toLowerCase()}</b>
              <button type="button" onClick={() => editRow(null)}>＋ New</button>
            </div>

            {rows.length ? rows.map((row) => (
              <article key={row.id || row.title} className="portal-highlight-row">
                <div className="portal-highlight-thumb">
                  {row.mediaType === "video" ? (
                    row._posterUrl || row.fallbackImageUrl ? (
                      <img src={row._posterUrl || row.fallbackImageUrl || ""} alt="" />
                    ) : <span>▶</span>
                  ) : row._mediaUrl || row.fallbackImageUrl ? (
                    <img src={row._mediaUrl || row.fallbackImageUrl || ""} alt="" />
                  ) : <span>🖼️</span>}
                </div>
                <div>
                  <b>{row.title}</b>
                  <small>
                    {row.mediaType} · {(row.audiences || ["all"]).join(", ")}
                  </small>
                </div>
                <div className="portal-highlight-row-actions">
                  <button type="button" onClick={() => editRow(row)}>Edit</button>
                  <button type="button" onClick={() => removeRow(row)}>×</button>
                </div>
              </article>
            )) : (
              <div className="branch-media-empty">{emptyText}</div>
            )}
          </div>

          <div className="portal-highlight-editor">
            <div className="ba-field-grid">
              <Field label="Title">
                <input
                  value={draft.title}
                  onChange={(event) => setDraft((current) => ({...current, title:event.target.value}))}
                  placeholder="Science Fair Week"
                />
              </Field>
              <Field label="Subtitle">
                <input
                  value={draft.subtitle}
                  onChange={(event) => setDraft((current) => ({...current, subtitle:event.target.value}))}
                  placeholder="Celebrating young innovators"
                />
              </Field>
              <Field label="Display Order">
                <input
                  type="number"
                  min={0}
                  value={draft.displayOrder}
                  onChange={(event) => setDraft((current) => ({...current, displayOrder:Number(event.target.value || 0)}))}
                />
              </Field>
              <Field label="Slide Duration">
                <select
                  value={draft.durationSeconds}
                  onChange={(event) => setDraft((current) => ({...current, durationSeconds:Number(event.target.value)}))}
                >
                  {[5,7,10,15,20].map((value) => (
                    <option key={value} value={value}>{value} seconds</option>
                  ))}
                </select>
              </Field>
              <Field label="Status">
                <select
                  value={draft.status}
                  onChange={(event) => setDraft((current) => ({...current, status:event.target.value as PortalHighlightDraft["status"]}))}
                >
                  <option value="published">Published</option>
                  <option value="scheduled">Scheduled</option>
                  <option value="draft">Draft</option>
                </select>
              </Field>
              <Field label="Transition">
                <select
                  value={draft.transition}
                  onChange={(event) => setDraft((current) => ({...current, transition:event.target.value as "fade" | "slide"}))}
                >
                  <option value="fade">Fade</option>
                  <option value="slide">Slide</option>
                </select>
              </Field>
              <Field label="Starts At">
                <input
                  type="datetime-local"
                  value={draft.startAtInput}
                  onChange={(event) => setDraft((current) => ({...current, startAtInput:event.target.value}))}
                />
              </Field>
              <Field label="Ends At">
                <input
                  type="datetime-local"
                  value={draft.endAtInput}
                  onChange={(event) => setDraft((current) => ({...current, endAtInput:event.target.value}))}
                />
              </Field>
            </div>

            <Field label="Description">
              <textarea
                value={draft.description}
                onChange={(event) => setDraft((current) => ({...current, description:event.target.value}))}
                placeholder="Optional short message shown with this highlight."
              />
            </Field>

            <div className="portal-highlight-media-grid">
              <label className="portal-upload-card">
                <b>Image or short video</b>
                <small>Images or MP4/WebM video. Keep hero videos short and compressed.</small>
                {draft.mediaUrl ? (
                  draft.mediaType === "video" ? (
                    <video src={draft.mediaUrl} poster={draft.posterUrl || undefined} muted controls playsInline />
                  ) : (
                    <img src={draft.mediaUrl} alt="Highlight preview" />
                  )
                ) : <span className="portal-upload-empty">＋ Select media</span>}
                <input
                  type="file"
                  accept="image/*,video/mp4,video/webm,video/quicktime"
                  onChange={async (event) => {
                    const input = event.currentTarget;
                    await uploadPrimary(input.files?.[0]);
                    input.value = "";
                  }}
                />
              </label>

              {draft.mediaType === "video" ? (
                <label className="portal-upload-card">
                  <b>Video poster</b>
                  <small>Still image shown before the video loads or when motion is reduced.</small>
                  {draft.posterUrl ? (
                    <img src={draft.posterUrl} alt="Video poster" />
                  ) : <span className="portal-upload-empty">＋ Select poster</span>}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={async (event) => {
                      const input = event.currentTarget;
                      await uploadPoster(input.files?.[0]);
                      input.value = "";
                    }}
                  />
                </label>
              ) : null}
            </div>

            <div className="portal-audiences">
              <b>Show on</b>
              <div>
                {audienceOptions.map(([value, label]) => (
                  <label key={value}>
                    <input
                      type="checkbox"
                      checked={draft.audiences.includes(value)}
                      onChange={() => toggleAudience(value)}
                    />
                    {label}
                  </label>
                ))}
              </div>
            </div>

            <div className="portal-website-publishing">
              <label>
                <input
                  type="checkbox"
                  checked={draft.publishToWebsite}
                  onChange={(event) =>
                    setDraft((current) => ({
                      ...current,
                      publishToWebsite: event.target.checked,
                    }))
                  }
                />
                <span>
                  <b>Publish to school website</b>
                  <small>
                    Also expose this {draft.placement === "gallery" ? "gallery item" : "highlight"} to source-driven website sections.
                  </small>
                </span>
              </label>

              {draft.publishToWebsite ? (
                <label>
                  <input
                    type="checkbox"
                    checked={draft.websiteFeatured}
                    onChange={(event) =>
                      setDraft((current) => ({
                        ...current,
                        websiteFeatured: event.target.checked,
                      }))
                    }
                  />
                  <span>
                    <b>Feature on website</b>
                    <small>
                      Allow website templates to prioritize this item in featured layouts.
                    </small>
                  </span>
                </label>
              ) : null}
            </div>

            <div className="ba-field-grid">
              <Field label="Action">
                <select
                  value={draft.actionType}
                  onChange={(event) => setDraft((current) => ({...current, actionType:event.target.value as PortalHighlightDraft["actionType"]}))}
                >
                  <option value="none">No action</option>
                  <option value="portal_route">Open portal module</option>
                  <option value="external_url">External link</option>
                  <option value="announcement">Announcement</option>
                  <option value="calendar_event">Calendar event</option>
                </select>
              </Field>
              <Field label="Action Label">
                <input
                  value={draft.actionLabel}
                  onChange={(event) => setDraft((current) => ({...current, actionLabel:event.target.value}))}
                  placeholder="Learn more"
                />
              </Field>
              <Field label="Action Value">
                <input
                  value={draft.actionValue}
                  onChange={(event) => setDraft((current) => ({...current, actionValue:event.target.value}))}
                  placeholder="announcements or https://..."
                />
              </Field>
              <Field label="Visibility">
                <select
                  value={draft.active ? "active" : "hidden"}
                  onChange={(event) => setDraft((current) => ({...current, active:event.target.value === "active"}))}
                >
                  <option value="active">Active</option>
                  <option value="hidden">Hidden</option>
                </select>
              </Field>
            </div>
          </div>
        </div>

        <div className="ba-sheet-actions">
          <button type="button" onClick={() => editRow(null)} disabled={saving}>Clear</button>
          <button type="button" className="primary" onClick={() => void saveRow()} disabled={saving}>
            {saving ? "Saving..." : draft.id ? `Update ${entityLabel}` : `Add ${entityLabel}`}
          </button>
        </div>
      </section>
    </div></EleeveonFullscreenOverlay>
  );
}

function MediaSheet({
  title,
  text,
  form,
  fields,
  uploadImage,
  updateForm,
  clearImage,
  onClose,
}: {
  title: string;
  text: string;
  form: SettingsForm;
  fields: [string, ImageField, string][];
  uploadImage: (field: ImageField, file?: File) => void | Promise<void>;
  updateForm: (key: keyof SettingsForm, value: any) => void;
  clearImage: (field: ImageField) => void;
  onClose: () => void;
}) {
  return (
    <EleeveonFullscreenOverlay><div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet">
        <div className="ba-sheet-head">
          <div>
            <h2>{title}</h2>
            <p>{text}</p>
          </div>
          <button type="button" onClick={onClose} aria-label={`Close ${title}`}>
            ✕
          </button>
        </div>

        <div className="branch-media-grid">
          {fields.map(([label, field, helper]) => (
            <ImageUploader
              key={field}
              label={label}
              field={field}
              helper={helper}
              value={String(form[field] || "")}
              upload={uploadImage}
              clear={() => clearImage(field)}
            />
          ))}
        </div>

        <div className="ba-sheet-actions">
          <button type="button" className="primary" onClick={onClose}>
            Done
          </button>
        </div>
      </section>
    </div></EleeveonFullscreenOverlay>
  );
}

const css = `
@keyframes spin { to { transform: rotate(360deg); } }

.ba-page {
  --ease: cubic-bezier(.2,.8,.2,1);
  min-height: 100dvh;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  padding: calc(8px * var(--local-density-scale, 1));
  padding-bottom: max(40px, env(safe-area-inset-bottom));
  background:
    radial-gradient(circle at top left, color-mix(in srgb, var(--ba-primary) 9%, transparent), transparent 30rem),
    var(--bg, #f7f8fb);
  color: var(--text, #111827);
  font-family: var(--font-family, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif);
  font-size: var(--font-size, 14px);
  overflow-x: hidden;
}

.ba-page *,
.ba-page *::before,
.ba-page *::after {
  box-sizing: border-box;
  min-width: 0;
}

.ba-page button,
.ba-page input,
.ba-page select,
.ba-page textarea {
  font: inherit;
  max-width: 100%;
}

.ba-page button {
  -webkit-tap-highlight-color: transparent;
}

.ba-page input,
.ba-page select,
.ba-page textarea {
  width: 100%;
  min-height: 44px;
  border: 1px solid var(--input-border, var(--border, rgba(0,0,0,.10)));
  border-radius: 16px;
  padding: 0 12px;
  background: var(--input-bg, var(--surface, #fff));
  color: var(--input-text, var(--text, #111827));
  outline: none;
  font-weight: 750;
}

.ba-page input:focus,
.ba-page select:focus,
.ba-page textarea:focus {
  border-color: color-mix(in srgb, var(--ba-primary) 52%, var(--border, rgba(0,0,0,.10)));
  box-shadow: 0 0 0 4px color-mix(in srgb, var(--ba-primary) 12%, transparent);
}

.ba-state,
.ba-search-card,
.ba-summary-line,
.ba-card,
.ba-table-card,
.ba-analysis,
.ba-empty,
.ba-sheet,
.ba-modal,
.student-row {
  background: var(--card-bg, var(--surface, #fff));
  border: 1px solid var(--border, rgba(0,0,0,.10));
  box-shadow: 0 12px 28px rgba(15,23,42,.045);
}

.ba-state {
  min-height: min(420px, calc(100dvh - 32px));
  width: min(520px, 100%);
  margin: 0 auto;
  display: grid;
  place-items: center;
  align-content: center;
  gap: 10px;
  padding: 22px;
  border-radius: 28px;
  text-align: center;
}

.ba-spinner {
  width: 38px;
  height: 38px;
  border-radius: 999px;
  border: 4px solid color-mix(in srgb, var(--ba-primary) 18%, transparent);
  border-top-color: var(--ba-primary);
  animation: spin .8s linear infinite;
}

.ba-state h2 {
  margin: 0;
  font-size: 22px;
  font-weight: 1000;
  letter-spacing: -.04em;
}

.ba-state p {
  max-width: 34rem;
  margin: 0;
  color: var(--muted, #64748b);
  font-size: 13px;
  line-height: 1.6;
}

.ba-state-button {
  min-height: 42px;
  border: 0;
  border-radius: 999px;
  padding: 0 16px;
  background: var(--ba-primary);
  color: #fff;
  font-weight: 950;
  cursor: pointer;
}

.ba-toast {
  position: sticky;
  top: 8px;
  z-index: 40;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
  padding: 12px 14px;
  border-radius: 18px;
  font-size: 13px;
  font-weight: 850;
  box-shadow: 0 18px 40px rgba(15,23,42,.12);
}

.ba-toast.success { background: rgba(34,197,94,.14); color: #166534; }
.ba-toast.error { background: rgba(239,68,68,.12); color: #991b1b; }
.ba-toast.info { background: rgba(59,130,246,.13); color: #1d4ed8; }

.ba-toast button {
  border: 0;
  background: transparent;
  color: currentColor;
  font-weight: 1000;
  cursor: pointer;
}

/* Compact search/action strip. The page intentionally has no duplicate title header. */
.ba-topbar,
.ba-title,
.ba-topbar-actions {
  display: none;
}

.ba-icon-button,
.ba-filter-button,
.ba-add-inline {
  width: 42px;
  height: 42px;
  border: 1px solid var(--border, rgba(0,0,0,.10));
  border-radius: 999px;
  display: grid;
  place-items: center;
  background: var(--card-bg, var(--surface,#fff));
  color: var(--text,#111827);
  font-size: 18px;
  font-weight: 1000;
  cursor: pointer;
  box-shadow: 0 10px 22px rgba(15,23,42,.045);
}


.ba-add-inline {
  flex: 0 0 42px;
  border-color: var(--ba-primary);
  background: var(--ba-primary);
  color: #fff;
  font-size: 25px;
  line-height: 1;
  box-shadow: 0 12px 28px color-mix(in srgb, var(--ba-primary) 22%, transparent);
}

.ba-search-card {
  display: grid;
  grid-template-columns: minmax(0, 1fr) repeat(3, 42px);
  gap: 8px;
  align-items: center;
  margin-top: 2px;
  padding: 8px;
  border-radius: 24px;
}

.ba-search {
  min-width: 0;
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  align-items: center;
  gap: 8px;
  min-height: 44px;
  padding: 0 11px;
  border-radius: 18px;
  background: color-mix(in srgb, var(--muted,#64748b) 7%, transparent);
}

.ba-search span {
  color: var(--muted,#64748b);
  font-size: 17px;
  font-weight: 1000;
}

.ba-search input {
  min-height: 42px;
  border: 0;
  padding: 0;
  border-radius: 0;
  background: transparent;
  box-shadow: none;
  font-size: 14px;
}

.ba-slider-icon {
  width: 21px;
  height: 21px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2.2;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.ba-filter-button {
  position: relative;
  background: color-mix(in srgb, var(--ba-primary) 8%, var(--card-bg,#fff));
  color: var(--ba-primary);
}

.ba-filter-button.active {
  background: var(--ba-primary);
  color: #fff;
  border-color: var(--ba-primary);
}

.ba-filter-button b {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 19px;
  height: 19px;
  display: grid;
  place-items: center;
  border-radius: 999px;
  background: #ef4444;
  color: #fff;
  font-size: 10px;
  border: 2px solid var(--card-bg,#fff);
}

.ba-summary-line {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-top: 8px;
  padding: 10px 12px;
  border-radius: 20px;
}

.ba-summary-line div {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
}

.ba-summary-line strong {
  font-size: 21px;
  font-weight: 1000;
  letter-spacing: -.05em;
}

.ba-summary-line span,
.ba-summary-line p {
  color: var(--muted,#64748b);
  font-size: 12px;
  font-weight: 850;
}

.ba-summary-line p {
  margin: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ba-filter-chips {
  display: flex;
  gap: 7px;
  overflow-x: auto;
  padding: 8px 1px 0;
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.ba-filter-chips::-webkit-scrollbar {
  display: none;
}

.ba-filter-chips button {
  flex: 0 0 auto;
  min-height: 31px;
  border: 0;
  border-radius: 999px;
  padding: 0 10px;
  background: color-mix(in srgb, var(--ba-primary) 11%, transparent);
  color: var(--ba-primary);
  font-size: 11px;
  font-weight: 950;
  white-space: nowrap;
  cursor: pointer;
}

.ba-list {
  display: grid;
  gap: 7px;
  margin-top: 10px;
}

.student-row {
  width: 100%;
  display: grid;
  grid-template-columns: auto minmax(0,1fr) auto;
  align-items: center;
  gap: 10px;
  padding: 10px;
  border-radius: 22px;
  text-align: left;
  cursor: pointer;
  transition: transform .16s var(--ease), box-shadow .16s var(--ease), border-color .16s var(--ease);
}

.student-row:hover {
  transform: translateY(-1px);
  border-color: color-mix(in srgb, var(--ba-primary) 24%, var(--border, rgba(0,0,0,.10)));
  box-shadow: 0 16px 34px rgba(15,23,42,.07);
}

.ba-avatar {
  width: 48px;
  height: 48px;
  flex: 0 0 auto;
  display: grid;
  place-items: center;
  border-radius: 18px;
  color: #fff;
  font-size: 17px;
  font-weight: 1000;
  box-shadow: 0 12px 24px rgba(15,23,42,.12);
}

.student-main,
.student-main strong,
.student-main small,
.student-main em {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.student-main strong {
  color: var(--text,#111827);
  font-size: 14px;
  font-weight: 1000;
  letter-spacing: -.02em;
}

.student-main small {
  margin-top: 3px;
  color: var(--muted,#64748b);
  font-size: 12px;
  font-weight: 850;
  font-style: normal;
}

.student-main em {
  margin-top: 3px;
  color: color-mix(in srgb, var(--muted,#64748b) 86%, var(--text,#111827));
  font-size: 11px;
  font-weight: 750;
  font-style: normal;
}

.student-side {
  display: grid;
  justify-items: end;
  gap: 6px;
  flex: 0 0 auto;
}

.student-side i {
  color: var(--muted,#64748b);
  font-style: normal;
  font-size: 18px;
  font-weight: 1000;
  line-height: 1;
}

.ba-chip {
  max-width: 100%;
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 950;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  text-transform: capitalize;
}

.ba-chip.green { background: rgba(34,197,94,.12); color: #16a34a; }
.ba-chip.red { background: rgba(239,68,68,.12); color: #dc2626; }
.ba-chip.blue { background: rgba(59,130,246,.12); color: #2563eb; }
.ba-chip.gray { background: color-mix(in srgb,var(--muted,#64748b) 14%,transparent); color: var(--muted,#64748b); }
.ba-chip.orange { background: rgba(245,158,11,.14); color: #b45309; }
.ba-chip.purple { background: rgba(147,51,234,.12); color: #7e22ce; }

.status-dot-mini {
  width: 10px;
  height: 10px;
  display: inline-block;
  border-radius: 999px;
  background: var(--muted,#64748b);
  box-shadow: 0 0 0 4px color-mix(in srgb, currentColor 10%, transparent);
}

.status-dot-mini.green { background: #22c55e; }
.status-dot-mini.red { background: #ef4444; }
.status-dot-mini.blue { background: #3b82f6; }
.status-dot-mini.orange { background: #f59e0b; }
.status-dot-mini.gray { background: var(--muted,#64748b); }

.status-sheet-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0,1fr));
  gap: 8px;
}

.status-sheet-grid span {
  display: grid;
  gap: 5px;
  padding: 11px;
  border: 1px solid var(--border,rgba(0,0,0,.08));
  border-radius: 18px;
  background: color-mix(in srgb, var(--muted,#64748b) 7%, transparent);
}

.status-sheet-grid b {
  color: var(--muted,#64748b);
  font-size: 10px;
  font-weight: 950;
  text-transform: uppercase;
  letter-spacing: .08em;
}

.status-sheet-grid em {
  display: flex;
  align-items: center;
  gap: 7px;
  color: var(--text,#111827);
  font-size: 12px;
  font-style: normal;
  font-weight: 900;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}


.ba-sheet-backdrop,
.ba-modal-backdrop {
  position: fixed;
  inset: 0;
  z-index: 80;
  display: grid;
  place-items: end center;
  padding: 10px;
  background: rgba(15,23,42,.50);
  backdrop-filter: blur(12px);
}

.ba-sheet {
  width: min(760px, 100%);
  max-height: min(88dvh, 760px);
  overflow-y: auto;
  padding: 14px;
  border-radius: 28px 28px 22px 22px;
  box-shadow: 0 30px 90px rgba(15,23,42,.32);
  animation: sheetIn .18s var(--ease);
}

.ba-sheet.small {
  width: min(520px, 100%);
}

.template-preview-studio {
  display: grid;
  gap: 12px;
}

.template-preview-studio-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}

.template-preview-studio-head h3,
.template-preview-focus-head strong {
  margin: 0;
}

.template-preview-badge {
  flex: 0 0 auto;
  padding: 6px 9px;
  border-radius: 999px;
  background: color-mix(in srgb, var(--ba-primary, var(--primary-color, #2563eb)) 12%, transparent);
  color: var(--ba-primary, var(--primary-color, #2563eb));
  font-size: 10px;
  font-weight: 1000;
  text-transform: uppercase;
  letter-spacing: .06em;
}

.template-preview-gallery {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(176px, 1fr));
  gap: 10px;
}

.template-preview-card {
  appearance: none;
  -webkit-appearance: none;
  min-width: 0;
  display: grid;
  gap: 8px;
  padding: 9px;
  border-radius: 18px;
  border: 1px solid var(--border, rgba(0,0,0,.10));
  background: var(--card-bg, var(--surface, #fff));
  color: var(--text, #111827);
  text-align: left;
  cursor: pointer;
  box-shadow: 0 14px 30px rgba(15,23,42,.07);
}

.template-preview-card.selected {
  border-color: var(--ba-primary, var(--primary-color, #2563eb));
  box-shadow:
    0 18px 40px rgba(15,23,42,.10),
    0 0 0 3px color-mix(in srgb, var(--ba-primary, var(--primary-color, #2563eb)) 16%, transparent);
}

.template-preview-card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.template-preview-card-top strong,
.template-preview-card-top em {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.template-preview-card-top strong {
  color: var(--text, #111827);
  font-size: 12px;
  font-weight: 1000;
}

.template-preview-card-top em {
  color: var(--muted, #64748b);
  font-size: 10px;
  font-style: normal;
  font-weight: 900;
}

.template-preview-card.selected .template-preview-card-top em {
  color: var(--ba-primary, var(--primary-color, #2563eb));
}

.template-preview-mini {
  height: 230px;
  overflow: hidden;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  border-radius: 14px;
  background:
    linear-gradient(180deg, rgba(148,163,184,.10), rgba(148,163,184,.05));
  border: 1px solid rgba(148,163,184,.18);
}

.template-preview-mini-scale {
  width: 210mm;
  min-width: 210mm;
  transform: scale(.235);
  transform-origin: top center;
  pointer-events: none;
}

.template-preview-mini .student-report-card-page,
.template-preview-mini .src-a4-page {
  margin: 0 !important;
  box-shadow: none !important;
}

.template-preview-focus {
  display: grid;
  gap: 9px;
  padding: 10px;
  border-radius: 20px;
  border: 1px solid var(--border, rgba(0,0,0,.10));
  background: color-mix(in srgb, var(--muted, #64748b) 6%, transparent);
}

.template-preview-focus-head {
  display: grid;
  gap: 2px;
}

.template-preview-focus-head strong {
  color: var(--text, #111827);
  font-size: 13px;
  font-weight: 1000;
}

.template-preview-focus-head span {
  color: var(--muted, #64748b);
  font-size: 11px;
  font-weight: 800;
}

@media screen and (max-width: 520px) {
  .template-preview-gallery {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .template-preview-mini {
    height: 180px;
  }

  .template-preview-mini-scale {
    transform: scale(.18);
  }
}



.report-template-suite-sheet {
  width: min(980px, 100%);
}

.report-template-tab-groups {
  display: grid;
  gap: 12px;
  margin-bottom: 12px;
}

.report-template-tab-group {
  min-width: 0;
  padding: 10px;
  border: 1px solid rgba(148,163,184,.22);
  border-radius: 18px;
  background: color-mix(in srgb, var(--surface, #fff) 94%, var(--ba-primary) 6%);
}

.report-template-tab-group-title {
  margin-bottom: 8px;
  color: var(--text, #0f172a);
  font-size: 12px;
  font-weight: 950;
}

.report-template-tabs {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  margin: 10px 0 12px;
}

.report-template-tabs button {
  appearance: none;
  -webkit-appearance: none;
  display: grid;
  gap: 3px;
  min-width: 0;
  padding: 10px;
  border: 1px solid var(--border, rgba(148,163,184,.26));
  border-radius: 16px;
  background: var(--card-bg, var(--surface, #fff));
  color: var(--text, #0f172a);
  text-align: left;
  cursor: pointer;
  box-shadow: 0 10px 24px rgba(15,23,42,.045);
}

.report-template-tabs button.active {
  border-color: var(--ba-primary, var(--primary-color, #2563eb));
  background:
    linear-gradient(135deg, color-mix(in srgb, var(--ba-primary, #2563eb) 14%, transparent), transparent 64%),
    var(--card-bg, var(--surface, #fff));
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--ba-primary, #2563eb) 13%, transparent);
}

.report-template-tabs strong,
.report-template-tabs span {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}

.report-template-tabs strong {
  font-size: 12px;
  font-weight: 1000;
  white-space: nowrap;
}

.report-template-tabs span {
  color: var(--muted, #64748b);
  font-size: 10px;
  font-weight: 760;
  line-height: 1.25;
}

.template-preview-mini .cumulative-book-page,
.template-preview-mini .cumulative-transcript-page {
  margin: 0 !important;
  box-shadow: none !important;
}

@media(max-width:720px) {
  .report-template-tabs {
    grid-template-columns: minmax(0, 1fr);
  }
}

@keyframes sheetIn {
  from { transform: translateY(16px); opacity: .7; }
  to { transform: translateY(0); opacity: 1; }
}

.ba-sheet-head,
.ba-sheet-profile {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  padding-bottom: 12px;
}

.ba-sheet-head h2,
.ba-sheet-profile h2,
.ba-modal-head h2 {
  margin: 0;
  color: var(--text,#111827);
  font-size: 21px;
  font-weight: 1000;
  letter-spacing: -.05em;
}

.ba-sheet-head p,
.ba-sheet-profile p,
.ba-modal-head p {
  margin: 5px 0 0;
  color: var(--muted,#64748b);
  font-size: 12px;
  line-height: 1.5;
  font-weight: 750;
}

.ba-sheet-head button,
.ba-sheet-profile button,
.ba-modal-head button {
  width: 38px;
  height: 38px;
  border: 1px solid var(--border,rgba(0,0,0,.10));
  border-radius: 999px;
  background: var(--surface,#fff);
  color: var(--text,#111827);
  font-weight: 1000;
  cursor: pointer;
  flex: 0 0 auto;
}

.ba-sheet-actions,
.ba-modal-actions {
  position: sticky;
  bottom: -14px;
  display: flex;
  justify-content: flex-end;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 14px;
  padding: 12px 0 2px;
  background: linear-gradient(to top, var(--card-bg,var(--surface,#fff)) 70%, transparent);
}

.ba-sheet-actions button,
.ba-modal-actions button {
  min-height: 42px;
  border: 1px solid var(--border,rgba(0,0,0,.10));
  border-radius: 999px;
  padding: 0 16px;
  background: color-mix(in srgb,var(--muted,#64748b) 8%,var(--surface,#fff));
  color: var(--text,#111827);
  font-size: 12px;
  font-weight: 950;
  cursor: pointer;
}

.ba-sheet-actions button.primary,
.ba-modal-actions button:last-child {
  border-color: var(--ba-primary);
  background: var(--ba-primary);
  color: #fff;
  box-shadow: 0 14px 32px color-mix(in srgb, var(--ba-primary) 25%, transparent);
}

.ba-modal-actions button:disabled {
  opacity: .65;
  cursor: not-allowed;
}

.ba-menu-list {
  display: grid;
  gap: 8px;
}

.ba-menu-list button {
  width: 100%;
  display: grid;
  grid-template-columns: 42px minmax(0,1fr);
  column-gap: 10px;
  align-items: center;
  min-height: 58px;
  border: 1px solid var(--border,rgba(0,0,0,.10));
  border-radius: 18px;
  padding: 9px;
  background: var(--surface,#fff);
  color: var(--text,#111827);
  text-align: left;
  cursor: pointer;
}

.ba-menu-list button span {
  grid-row: span 2;
  width: 42px;
  height: 42px;
  display: grid;
  place-items: center;
  border-radius: 16px;
  background: color-mix(in srgb, var(--ba-primary) 10%, transparent);
  color: var(--ba-primary);
  font-weight: 1000;
}

.ba-menu-list button b,
.ba-menu-list button small {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ba-menu-list button b {
  font-size: 13px;
  font-weight: 1000;
}

.ba-menu-list button small {
  margin-top: 2px;
  color: var(--muted,#64748b);
  font-size: 11px;
  font-weight: 750;
}

.ba-menu-list button.active {
  border-color: color-mix(in srgb, var(--ba-primary) 34%, var(--border,rgba(0,0,0,.10)));
  background: color-mix(in srgb, var(--ba-primary) 8%, var(--surface,#fff));
}

.ba-menu-list button.danger span {
  background: color-mix(in srgb, #dc2626 10%, transparent);
  color: #dc2626;
}

.ba-menu-list button.danger b {
  color: #991b1b;
}

.student-detail-strip {
  display: grid;
  grid-template-columns: repeat(3, minmax(0,1fr));
  gap: 7px;
  margin-bottom: 10px;
}

.student-detail-strip span {
  display: block;
  padding: 9px;
  border-radius: 16px;
  background: color-mix(in srgb, var(--muted,#64748b) 8%, transparent);
  color: var(--muted,#64748b);
  font-size: 11px;
  font-weight: 850;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.student-detail-strip b {
  display: block;
  margin-bottom: 3px;
  color: var(--text,#111827);
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: .05em;
}

.ba-form {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 10px;
}

.ba-form.two {
  grid-template-columns: minmax(0,1fr);
}

.ba-form.compact {
  gap: 9px;
}

.ba-form label {
  display: grid;
  gap: 6px;
  min-width: 0;
}

.ba-form span {
  color: var(--muted,#64748b);
  font-size: 11px;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: .06em;
}

.ba-media-hint {
  color: var(--muted,#64748b);
  font-size: 11px;
  font-weight: 750;
  line-height: 1.4;
}

.ba-form .wide {
  grid-column: 1 / -1;
}

.ba-form-section {
  padding: 12px 0;
  border-top: 1px solid var(--border,rgba(0,0,0,.08));
}

.ba-form-section:first-of-type {
  border-top: 0;
  padding-top: 0;
}

.ba-form-section h3 {
  margin: 0 0 10px;
  color: var(--text,#111827);
  font-size: 14px;
  font-weight: 1000;
  letter-spacing: -.03em;
}

.ba-page input[type="file"] {
  padding: 10px;
  font-size: 12px;
}

.ba-page textarea {
  min-height: 92px;
  padding: 12px;
  resize: vertical;
  line-height: 1.55;
}


.ba-media-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 2px;
}

.ba-media-button {
  width: auto;
  min-height: 40px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid var(--ba-primary);
  border-radius: 999px;
  padding: 0 14px;
  background: var(--ba-primary);
  color: #fff !important;
  font-size: 12px;
  font-weight: 950;
  letter-spacing: 0 !important;
  text-transform: none !important;
  cursor: pointer;
  box-shadow: 0 10px 22px color-mix(in srgb, var(--ba-primary) 18%, transparent);
}

.ba-media-button.secondary {
  background: var(--surface, #fff);
  color: var(--ba-primary) !important;
  box-shadow: none;
}

.ba-media-button input {
  display: none;
}

.ba-preview-photo {
  width: 96px;
  height: 96px;
  object-fit: cover;
  border-radius: 22px;
  border: 1px solid var(--border,rgba(0,0,0,.10));
}

.ba-preview-banner {
  width: 100%;
  height: 130px;
  object-fit: cover;
  border-radius: 22px;
  border: 1px solid var(--border,rgba(0,0,0,.10));
}

.ba-modal {
  width: min(980px, 100%);
  max-height: min(92dvh, 900px);
  overflow-y: auto;
  padding: 14px;
  border-radius: 28px;
  box-shadow: 0 30px 90px rgba(15,23,42,.35);
}

.ba-modal-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  padding: 4px 2px 14px;
}

.ba-analysis-grid {
  display: grid;
  grid-template-columns: minmax(0,1fr);
  gap: 10px;
  margin-top: 10px;
}

.ba-analysis,
.ba-table-card,
.ba-empty {
  padding: 13px;
  border-radius: 24px;
}

.ba-analysis span {
  color: var(--muted,#64748b);
  font-size: 11px;
  font-weight: 950;
  text-transform: uppercase;
  letter-spacing: .08em;
}

.ba-analysis strong {
  display: block;
  margin-top: 8px;
  font-size: clamp(22px,7vw,30px);
  line-height: 1;
  font-weight: 1000;
  letter-spacing: -.06em;
  overflow-wrap: anywhere;
}

.ba-analysis p {
  margin: 8px 0 0;
  color: var(--muted,#64748b);
  font-size: 12px;
  line-height: 1.5;
}

.ba-analysis-list {
  display: grid;
  gap: 10px;
  margin-top: 12px;
}

.ba-analysis-list section {
  display: grid;
  gap: 6px;
  padding: 10px;
  border-radius: 16px;
  background: color-mix(in srgb,var(--muted,#64748b) 8%,transparent);
}

.ba-analysis-list section > div:first-child {
  display: flex;
  justify-content: space-between;
  gap: 10px;
}

.ba-analysis-list b,
.ba-analysis-list small {
  font-size: 12px;
}

.ba-analysis-list small {
  color: var(--muted,#64748b);
  font-weight: 850;
}

.ba-progress {
  height: 8px;
  border-radius: 999px;
  background: color-mix(in srgb,var(--muted,#64748b) 18%,transparent);
  overflow: hidden;
}

.ba-progress i {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: var(--ba-primary);
}

.ba-empty {
  display: grid;
  place-items: center;
  align-content: center;
  gap: 8px;
  min-height: 220px;
  text-align: center;
  border-style: dashed;
}

.ba-empty-icon {
  width: 56px;
  height: 56px;
  display: grid;
  place-items: center;
  border-radius: 22px;
  background: color-mix(in srgb,var(--ba-primary) 12%,var(--surface,#fff));
  font-size: 28px;
}

.ba-empty h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 1000;
}

.ba-empty p {
  margin: 0;
  color: var(--muted,#64748b);
  font-size: 13px;
  line-height: 1.6;
}

.ba-table-card {
  margin-top: 10px;
}

.ba-table-scroll {
  width: 100%;
  max-width: 100%;
  overflow-x: auto;
  border-radius: 18px;
  border: 1px solid var(--border,rgba(0,0,0,.08));
}

.ba-table-scroll table {
  width: 100%;
  min-width: 1120px;
  border-collapse: collapse;
  background: var(--card-bg, var(--surface, var(--bg, transparent)));
}

.ba-table-scroll th,
.ba-table-scroll td {
  padding: 10px;
  border-bottom: 1px solid var(--border,rgba(0,0,0,.08));
  vertical-align: top;
  text-align: left;
  font-size: 13px;
}

.ba-table-scroll th {
  background: var(--table-header-bg, color-mix(in srgb, var(--ba-primary) 6%, var(--card-bg, var(--surface, var(--bg, transparent)))));
  color: var(--table-header-text, var(--muted, var(--text)));
  font-size: 11px;
  font-weight: 1000;
  text-transform: uppercase;
  letter-spacing: .07em;
}

.ba-table-scroll td strong,
.ba-table-scroll td span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ba-table-scroll td span {
  margin-top: 3px;
  color: var(--muted,#64748b);
  font-size: 11px;
}

.ba-table-actions {
  display: flex;
  flex-wrap: nowrap;
  gap: 7px;
  width: 100%;
  max-width: 100%;
  overflow-x: auto;
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.ba-table-actions::-webkit-scrollbar {
  display: none;
}

.ba-table-actions button {
  flex: 0 0 auto;
  min-height: 34px;
  border: 1px solid var(--border,rgba(0,0,0,.10));
  border-radius: 999px;
  padding: 0 10px;
  background: var(--surface,#fff);
  color: var(--text,#111827);
  font-size: 11px;
  font-weight: 950;
  cursor: pointer;
  white-space: nowrap;
}

.ba-table-actions button:first-child {
  background: var(--ba-primary);
  color: #fff;
  border-color: var(--ba-primary);
}

.ba-delete,
.ba-table-actions button.ba-delete {
  color: #991b1b;
  background: color-mix(in srgb,#dc2626 7%,var(--surface,#fff));
  border-color: color-mix(in srgb,#dc2626 24%,var(--border,rgba(0,0,0,.10)));
}

.ba-empty-table {
  padding: 22px;
  text-align: center;
  color: var(--muted,#64748b);
  font-weight: 850;
}

@media (min-width: 680px) {
  .ba-page {
    padding: calc(12px * var(--local-density-scale,1));
    padding-bottom: 44px;
  }

  .ba-search-card {
    grid-template-columns: minmax(0,1fr) repeat(3, 42px);
  }

  .ba-list {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;
  }

  .student-row {
    border-radius: 24px;
    padding: 12px;
  }

  .ba-analysis-grid {
    grid-template-columns: repeat(2, minmax(0,1fr));
  }

  .ba-form {
    grid-template-columns: repeat(2, minmax(0,1fr));
  }

  .ba-form.two {
    grid-template-columns: repeat(2, minmax(0,1fr));
  }

  .ba-modal-backdrop,
  .ba-sheet-backdrop {
    place-items: center;
    padding: 18px;
  }

  .ba-sheet {
    border-radius: 28px;
    padding: 18px;
  }

  .ba-modal {
    padding: 18px;
  }

}

@media (min-width: 1040px) {
  .ba-page {
    padding: calc(16px * var(--local-density-scale,1));
    padding-bottom: 48px;
  }

  .ba-search-card,
  .ba-summary-line,
  .ba-list,
  .ba-analysis-grid,
  .ba-table-card,
  .ba-filter-chips {
    max-width: 1180px;
    margin-left: auto;
    margin-right: auto;
  }

  .ba-list {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  .ba-analysis-grid {
    grid-template-columns: repeat(4, minmax(0,1fr));
  }

  .ba-current-filter {
    grid-column: span 2;
  }

  .ba-form {
    grid-template-columns: repeat(3, minmax(0,1fr));
  }

  .ba-form.two {
    grid-template-columns: repeat(2, minmax(0,1fr));
  }

}

@media (max-width: 520px) {
  .ba-page {
    padding: calc(7px * var(--local-density-scale,1));
    padding-bottom: max(38px, env(safe-area-inset-bottom));
  }

  .ba-title h1 {
    font-size: 28px;
  }

  .ba-icon-button,
  .ba-filter-button,
  .ba-add-inline {
    width: 40px;
    height: 40px;
  }

  .ba-summary-line {
    align-items: flex-start;
    flex-direction: column;
    gap: 2px;
  }

  .student-detail-strip {
    grid-template-columns: minmax(0,1fr);
  }

  .ba-sheet,
  .ba-modal {
    border-radius: 24px 24px 18px 18px;
    padding: 12px;
  }

  .ba-sheet-actions,
  .ba-modal-actions {
    display: grid;
    grid-template-columns: minmax(0,1fr);
  }

  .ba-sheet-actions button,
  .ba-modal-actions button {
    width: 100%;
  }
}


.ba-media-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 4px;
}

.ba-media-button {
  min-height: 40px;
  border: 1px solid var(--ba-primary);
  border-radius: 999px;
  padding: 0 14px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: var(--ba-primary);
  color: #fff;
  font-size: 12px;
  font-weight: 950;
  cursor: pointer;
  text-align: center;
  box-shadow: 0 12px 26px color-mix(in srgb, var(--ba-primary) 18%, transparent);
}

.ba-media-button.secondary {
  background: var(--surface, #fff);
  color: var(--ba-primary);
  box-shadow: none;
}

.ba-media-hint {
  display: block;
  color: var(--muted, #64748b);
  font-size: 11px;
  font-weight: 750;
  line-height: 1.45;
}

.camera-backdrop {
  z-index: 100;
  place-items: center;
}

.ba-camera-modal {
  width: min(720px, 100%);
  max-height: min(92dvh, 880px);
  overflow-y: auto;
  padding: 14px;
  border-radius: 28px;
  background: var(--card-bg, var(--surface, #fff));
  border: 1px solid var(--border, rgba(0,0,0,.10));
  box-shadow: 0 30px 90px rgba(15,23,42,.35);
}

.ba-camera-preview {
  position: relative;
  width: 100%;
  aspect-ratio: 4 / 3;
  overflow: hidden;
  border-radius: 24px;
  background: #020617;
  border: 1px solid var(--border, rgba(0,0,0,.10));
}

.ba-camera-preview video {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
  background: #020617;
}

.ba-camera-loading {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  background: rgba(2,6,23,.72);
  color: #fff;
  font-size: 13px;
  font-weight: 950;
}

.ba-camera-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 12px;
}

.ba-camera-actions button {
  min-height: 42px;
  border-radius: 999px;
  padding: 0 14px;
  font-size: 12px;
  font-weight: 950;
  cursor: pointer;
}

.ba-camera-secondary {
  border: 1px solid var(--border, rgba(0,0,0,.10));
  background: color-mix(in srgb, var(--muted, #64748b) 8%, var(--surface, #fff));
  color: var(--text, #111827);
}

.ba-camera-primary {
  border: 1px solid var(--ba-primary);
  background: var(--ba-primary);
  color: #fff;
  box-shadow: 0 14px 32px color-mix(in srgb, var(--ba-primary) 25%, transparent);
}

.ba-camera-actions button:disabled {
  opacity: .62;
  cursor: not-allowed;
}

@media (max-width: 520px) {
  .ba-media-actions {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .ba-media-button,
  .ba-camera-actions button {
    width: 100%;
  }

  .ba-camera-actions {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
  }

  .ba-camera-modal {
    border-radius: 22px;
    padding: 11px;
  }
}

/* Student Reports golden additions */

/* Extra compact report-only layout */
.student-reports-page .ba-print-card{margin-top:8px;border-radius:22px}
.student-reports-page .ba-print-head{padding:8px 10px}
.student-reports-page .ba-print-head strong{font-size:14px}
.student-reports-page .ba-print-head p{font-size:11px;margin-top:2px}
.student-reports-page .ba-print-zone{padding:8px}


.student-reports-page .ba-list {
  grid-template-columns: minmax(0, 1fr);
}

.ba-report-icon {
  width: 40px;
  height: 40px;
  display: grid;
  place-items: center;
  border-radius: 16px;
  background: color-mix(in srgb, var(--ba-primary) 11%, transparent);
  font-size: 18px;
  color: var(--ba-primary);
}

.ba-print-card {
  margin-top: 10px;
  background: var(--card-bg, var(--surface,#fff));
  border: 1px solid var(--border, rgba(0,0,0,.10));
  border-radius: 24px;
  box-shadow: 0 12px 28px rgba(15,23,42,.045);
  overflow: hidden;
}

.ba-print-head {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 10px;
  padding: 10px;
  border-bottom: 1px solid var(--border, rgba(0,0,0,.08));
  background: color-mix(in srgb, var(--muted,#64748b) 6%, transparent);
}

.ba-print-head span {
  color: var(--muted,#64748b);
  font-size: 10px;
  font-weight: 950;
  text-transform: uppercase;
  letter-spacing: .08em;
}

.ba-print-head strong {
  display: block;
  margin-top: 3px;
  color: var(--text,#111827);
  font-size: 15px;
  font-weight: 1000;
  letter-spacing: -.03em;
}

.ba-print-head p {
  margin: 3px 0 0;
  color: var(--muted,#64748b);
  font-size: 11px;
  line-height: 1.4;
}

.ba-print-zone {
  padding: 10px;
  background: var(--card-bg, var(--surface,#fff));
}

.ba-report-toolbar {
  display: flex;
  gap: 8px;
  flex-wrap: nowrap;
  align-items: center;
  justify-content: flex-end;
}

.ba-report-toolbar button {
  min-height: 34px;
  border: 0;
  border-radius: 999px;
  padding: 0 10px;
  background: color-mix(in srgb, var(--ba-primary) 10%, var(--card-bg,#fff));
  color: var(--ba-primary);
  font-size: 11px;
  font-weight: 950;
  cursor: pointer;
  white-space: nowrap;
}

.ba-report-toolbar button.primary {
  background: var(--ba-primary);
  color: #fff;
}

.report-analytics-card {
  grid-column: 1 / -1;
}

.report-analytics-card > div {
  margin-top: 10px;
}

@media (min-width: 680px) {
  .student-reports-page .ba-list {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (min-width: 1040px) {
  .student-reports-page .ba-list {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}

@media (min-width: 1320px) {
  .student-reports-page .ba-list {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
}

@media print {
  .report-no-print,
  .ba-search-card,
  .ba-filter-chips,
  .ba-sheet-backdrop,
  .ba-modal-backdrop,
  .ba-toast,
  .ba-print-head,
  .ba-report-toolbar {
    display: none !important;
  }

  .ba-page,
  .ba-print-card,
  .ba-print-zone {
    padding: 0 !important;
    margin: 0 !important;
    background: #fff !important;
    box-shadow: none !important;
    border: 0 !important;
    border-radius: 0 !important;
    overflow: visible !important;
  }
}


/* StudentReports final golden fixes: one-row action strip, theme-safe buttons/tables, clean preview */
.student-reports-page .ba-search-card {
  grid-template-columns: minmax(0, 1fr) repeat(4, 42px) !important;
  gap: 7px;
  align-items: center;
  overflow: hidden;
}

.student-reports-page .ba-search {
  min-width: 0;
  overflow: hidden;
}

.student-reports-page .ba-icon-button,
.student-reports-page .ba-filter-button,
.student-reports-page .ba-view-button,
.student-reports-page .ba-add-inline {
  width: 42px;
  height: 42px;
  min-width: 42px;
  min-height: 42px;
  flex: 0 0 42px;
  border-color: var(--border, rgba(0,0,0,.10));
  background: var(--card-bg, var(--surface,#fff));
  color: var(--text,#111827);
}

.student-reports-page .ba-add-inline {
  border-color: var(--ba-primary);
  background: var(--ba-primary);
  color: #fff;
}

.student-reports-page .ba-filter-button {
  background: color-mix(in srgb, var(--ba-primary) 8%, var(--card-bg,#fff));
  color: var(--ba-primary);
}

.student-reports-page .ba-filter-button.active {
  border-color: var(--ba-primary);
  background: var(--ba-primary);
  color: #fff;
}

.student-reports-page .ba-view-button {
  background: color-mix(in srgb, var(--muted,#64748b) 8%, var(--card-bg,#fff));
  color: var(--text,#111827);
}

.student-reports-page .ba-icon-button:hover,
.student-reports-page .ba-view-button:hover {
  border-color: color-mix(in srgb, var(--ba-primary) 28%, var(--border,rgba(0,0,0,.10)));
  color: var(--ba-primary);
}

.student-reports-page .ba-table-scroll th {
  background: var(--table-header-bg, color-mix(in srgb, var(--ba-primary) 6%, var(--card-bg, var(--surface,#fff))));
  color: var(--table-header-text, var(--muted, var(--text,#111827)));
}

.student-reports-page .ba-table-scroll table,
.student-reports-page .ba-table-scroll td {
  background: var(--card-bg, var(--surface,#fff));
  color: var(--text,#111827);
}

.student-reports-page .ba-print-head {
  align-items: center;
}

@media (max-width: 520px) {
  .student-reports-page .ba-search-card {
    grid-template-columns: minmax(0, 1fr) repeat(4, 38px) !important;
    gap: 5px;
    padding: 6px;
  }

  .student-reports-page .ba-icon-button,
  .student-reports-page .ba-filter-button,
  .student-reports-page .ba-view-button,
  .student-reports-page .ba-add-inline {
    width: 38px;
    height: 38px;
    min-width: 38px;
    min-height: 38px;
    flex-basis: 38px;
  }

  .student-reports-page .ba-search {
    min-height: 38px;
    padding: 0 8px;
  }

  .student-reports-page .ba-search input {
    min-height: 38px;
    font-size: 13px;
  }
}



/* Branch settings golden compact additions */
.branch-settings-page .ba-search-card {
  grid-template-columns: minmax(0, 1fr) auto auto auto;
}

.branch-settings-page .settings-save-button {
  width: auto;
  min-width: 46px;
  padding: 0 10px;
  font-size: 11px;
  letter-spacing: 0;
}

.branch-settings-page .branch-settings-list {
  grid-template-columns: minmax(0, 1fr);
}

.branch-settings-icon {
  width: 40px;
  height: 40px;
  display: grid;
  place-items: center;
  border-radius: 16px;
  background: color-mix(in srgb, var(--ba-primary) 11%, transparent);
  color: var(--ba-primary);
  font-size: 18px;
}

.branch-live-preview {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  align-items: center;
  gap: 10px;
  margin-top: 8px;
  padding: 10px;
  border-radius: 20px;
  background: var(--card-bg, var(--surface, #ffffff));
  border: 1px solid var(--border, rgba(0,0,0,.10));
  box-shadow: 0 12px 28px rgba(15,23,42,.045);
}

.branch-live-preview.sheet-preview {
  margin-top: 12px;
}

.branch-preview-aa {
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  border-radius: 15px;
  font-size: 15px;
  font-weight: 1000;
}

.branch-live-preview strong,
.branch-live-preview span {
  display: block;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.branch-live-preview strong {
  color: var(--text, #111111);
  font-size: 13px;
  font-weight: 1000;
  letter-spacing: -.02em;
}

.branch-live-preview span {
  margin-top: 2px;
  color: var(--muted,#64748b);
  font-size: 11px;
  font-weight: 800;
}

.branch-field {
  display: grid;
  gap: 6px;
  min-width: 0;
}

.branch-field > span {
  color: var(--muted,#64748b);
  font-size: 11px;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: .06em;
}

.branch-color-input {
  padding: 4px !important;
  height: 44px;
}

.branch-media-grid {
  display: grid;
  grid-template-columns: minmax(0,1fr);
  gap: 10px;
  margin-top: 12px;
}

.branch-media-block {
  display: grid;
  gap: 8px;
  min-width: 0;
  padding: 10px;
  border-radius: 18px;
  background: color-mix(in srgb, var(--muted,#64748b) 7%, transparent);
  border: 1px solid var(--border,rgba(0,0,0,.08));
}

.branch-media-title {
  color: var(--text,#111827);
  font-size: 13px;
  font-weight: 1000;
  letter-spacing: -.02em;
}

.branch-media-block p {
  margin: 0;
  color: var(--muted,#64748b);
  font-size: 11px;
  line-height: 1.5;
}

.branch-media-block input[type="file"] {
  min-height: auto;
  padding: 9px;
  font-size: 11px;
}

.branch-image-preview {
  position: relative;
  overflow: hidden;
  min-height: 130px;
  border-radius: 16px;
  background: color-mix(in srgb, var(--muted,#64748b) 12%, transparent);
}

.branch-image-preview img {
  width: 100%;
  height: 150px;
  display: block;
  object-fit: cover;
}

.branch-image-preview button {
  position: absolute;
  right: 8px;
  bottom: 8px;
  min-height: 30px;
  border: 0;
  border-radius: 999px;
  padding: 0 10px;
  background: rgba(15,23,42,.72);
  color: #fff;
  font-size: 11px;
  font-weight: 950;
  cursor: pointer;
}

.branch-gallery-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0,1fr));
  gap: 8px;
  margin-top: 12px;
}

.branch-gallery-item {
  position: relative;
  overflow: hidden;
  border-radius: 16px;
  background: color-mix(in srgb, var(--muted,#64748b) 10%, transparent);
}

.branch-gallery-item img {
  width: 100%;
  height: 120px;
  display: block;
  object-fit: cover;
}

.branch-gallery-item button {
  position: absolute;
  top: 7px;
  right: 7px;
  width: 28px;
  height: 28px;
  border: 0;
  border-radius: 999px;
  background: rgba(15,23,42,.72);
  color: #fff;
  font-weight: 1000;
  cursor: pointer;
}

.ba-menu-list button:disabled,
.ba-add-inline:disabled {
  opacity: .55;
  cursor: not-allowed;
}

@media(min-width:680px) {
  .branch-settings-page .branch-settings-list {
    grid-template-columns: repeat(2, minmax(0,1fr));
  }

  .branch-media-grid {
    grid-template-columns: repeat(2, minmax(0,1fr));
  }

  .branch-gallery-grid {
    grid-template-columns: repeat(3, minmax(0,1fr));
  }
}

@media(min-width:1040px) {
  .branch-settings-page .branch-settings-list {
    grid-template-columns: repeat(3, minmax(0,1fr));
  }
}

@media(min-width:1320px) {
  .branch-settings-page .branch-settings-list {
    grid-template-columns: repeat(4, minmax(0,1fr));
  }
}

@media(max-width:520px) {
  .branch-settings-page .settings-save-button {
    min-width: 42px;
    width: 42px;
    padding: 0;
    font-size: 10px;
  }

  .branch-gallery-grid {
    grid-template-columns: minmax(0,1fr);
  }
}


.branch-settings-subsection {
  margin-top: 16px;
  padding: 12px;
  border: 1px solid rgba(148,163,184,.22);
  border-radius: 18px;
  background: var(--card-bg, var(--surface, #ffffff));
}

.branch-settings-subsection h3 {
  margin: 0;
  color: var(--text, #0f172a);
  font-size: 13px;
  font-weight: 950;
}

.branch-settings-subsection p {
  margin: 4px 0 12px;
  color: var(--muted, #64748b);
  font-size: 11px;
  font-weight: 750;
}

.branch-report-toggle-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}

.branch-report-toggle {
  min-width: 0;
  display: grid;
  grid-template-columns: minmax(0, 1fr) 92px;
  align-items: center;
  gap: 8px;
  padding: 10px;
  border: 1px solid var(--border, rgba(148,163,184,.24));
  border-radius: 16px;
  background: var(--card-bg, var(--surface, #ffffff));
  color: var(--text, #0f172a);
  box-shadow: 0 10px 24px rgba(15,23,42,.045);
  transition:
    border-color .18s var(--ease),
    background .18s var(--ease),
    box-shadow .18s var(--ease),
    transform .18s var(--ease);
}

.branch-report-toggle.is-on {
  border-color: color-mix(in srgb, var(--ba-primary, #2563eb) 34%, var(--border, rgba(148,163,184,.24)));
  background:
    linear-gradient(135deg, color-mix(in srgb, var(--ba-primary, #2563eb) 10%, transparent), transparent 62%),
    var(--card-bg, var(--surface, #ffffff));
}

.branch-report-toggle.is-off {
  background: color-mix(in srgb, var(--muted, #64748b) 7%, var(--card-bg, var(--surface, #ffffff)));
  opacity: .92;
}

.branch-report-toggle:hover {
  transform: translateY(-1px);
  border-color: color-mix(in srgb, var(--ba-primary, #2563eb) 42%, var(--border, rgba(148,163,184,.24)));
  box-shadow: 0 14px 30px rgba(15,23,42,.075);
}

.branch-report-toggle span,
.branch-report-toggle strong,
.branch-report-toggle small {
  display: block;
  min-width: 0;
}

.branch-report-toggle strong {
  color: var(--text, #0f172a);
  font-size: 12px;
  font-weight: 950;
  line-height: 1.15;
  letter-spacing: -.01em;
}

.branch-report-toggle small {
  margin-top: 3px;
  color: var(--muted, #64748b);
  font-size: 10px;
  font-weight: 750;
  line-height: 1.28;
}

.branch-report-toggle.is-off strong {
  color: var(--muted, #64748b);
}

.branch-report-toggle select {
  min-height: 34px;
  height: 34px;
  border-radius: 999px;
  padding: 0 26px 0 12px;
  border: 1px solid color-mix(in srgb, var(--ba-primary, #2563eb) 30%, var(--border, rgba(148,163,184,.26)));
  background: var(--input-bg, var(--surface, #ffffff));
  color: var(--input-text, var(--text, #0f172a));
  font-size: 11px;
  font-weight: 950;
  cursor: pointer;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.12);
}

.branch-report-toggle.is-on select {
  background: var(--ba-primary, #2563eb);
  color: #ffffff;
  border-color: var(--ba-primary, #2563eb);
}

.branch-report-toggle.is-off select {
  background: var(--input-bg, var(--surface, #ffffff));
  color: var(--muted, #64748b);
  border-color: var(--border, rgba(148,163,184,.26));
}

.branch-report-toggle select option {
  background: var(--input-bg, var(--surface, #ffffff));
  color: var(--input-text, var(--text, #0f172a));
}

@media(max-width:720px) {
  .branch-report-toggle-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}



.portal-highlight-sheet{width:min(980px,100%);max-height:min(94dvh,900px);overflow:auto}
.portal-highlight-layout{display:grid;gap:12px}
.portal-highlight-list,.portal-highlight-editor{padding:12px;border:1px solid var(--border,rgba(0,0,0,.1));border-radius:20px;background:color-mix(in srgb,var(--muted,#64748b) 4%,transparent)}
.portal-highlight-list-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:9px}
.portal-highlight-list-head button,.portal-highlight-row-actions button{border:1px solid var(--border,rgba(0,0,0,.1));border-radius:999px;background:var(--surface,#fff);color:inherit;padding:6px 9px;font-size:11px;font-weight:900}
.portal-highlight-row{display:grid;grid-template-columns:64px minmax(0,1fr) auto;align-items:center;gap:9px;padding:8px;border-radius:16px;background:var(--surface,#fff);border:1px solid var(--border,rgba(0,0,0,.08));margin-top:7px}
.portal-highlight-thumb{width:64px;height:46px;border-radius:12px;overflow:hidden;display:grid;place-items:center;background:#0f172a;color:#fff}
.portal-highlight-thumb img{width:100%;height:100%;object-fit:cover}
.portal-highlight-row b,.portal-highlight-row small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.portal-highlight-row b{font-size:12px}.portal-highlight-row small{margin-top:3px;color:var(--muted,#64748b);font-size:9px}
.portal-highlight-row-actions{display:flex;gap:5px}
.portal-highlight-media-grid{display:grid;gap:10px;margin-top:10px}
.portal-upload-card{position:relative;display:grid;gap:7px;padding:11px;border:1px dashed color-mix(in srgb,var(--ba-primary) 45%,var(--border,rgba(0,0,0,.1)));border-radius:18px;background:color-mix(in srgb,var(--ba-primary) 5%,transparent);cursor:pointer;overflow:hidden}
.portal-upload-card small{color:var(--muted,#64748b);font-size:10px;line-height:1.5}
.portal-upload-card img,.portal-upload-card video{width:100%;height:170px;object-fit:cover;border-radius:14px;background:#0f172a}
.portal-upload-card input{position:absolute;inset:0;opacity:0;cursor:pointer}
.portal-upload-empty{min-height:110px;display:grid;place-items:center;border-radius:14px;background:color-mix(in srgb,var(--muted,#64748b) 7%,transparent);font-size:12px;font-weight:900}
.portal-audiences{margin-top:12px}.portal-audiences>b{display:block;font-size:11px;margin-bottom:7px}.portal-audiences>div{display:flex;flex-wrap:wrap;gap:7px}
.portal-audiences label{display:flex;align-items:center;gap:6px;padding:7px 9px;border-radius:999px;background:color-mix(in srgb,var(--muted,#64748b) 7%,transparent);font-size:10px;font-weight:850}
.portal-website-publishing{display:grid;gap:7px;margin:12px 0;padding:10px;border:1px solid color-mix(in srgb,var(--ba-primary) 22%,var(--border,rgba(0,0,0,.1)));border-radius:17px;background:color-mix(in srgb,var(--ba-primary) 5%,transparent)}
.portal-website-publishing label{display:grid;grid-template-columns:auto minmax(0,1fr);align-items:start;gap:8px;cursor:pointer}
.portal-website-publishing input{margin-top:2px}
.portal-website-publishing b,.portal-website-publishing small{display:block}
.portal-website-publishing b{font-size:11px}
.portal-website-publishing small{margin-top:2px;color:var(--muted,#64748b);font-size:9px;line-height:1.45}
@media(min-width:820px){.portal-highlight-layout{grid-template-columns:320px minmax(0,1fr)}.portal-highlight-media-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}

/* Role-portal modal/sheet containment -------------------------------- */
@media (min-width:980px){
  .ba-sheet-backdrop,
  .ba-modal-backdrop{
    position:fixed;
    top:var(--eds-shell-top-offset,0px) !important;
    right:0 !important;
    bottom:0 !important;
    left:var(--portal-content-left,0px) !important;
    inset:auto 0 0 var(--portal-content-left,0px) !important;
    width:auto;
    height:auto;
    max-width:calc(100vw - var(--portal-content-left,0px));
    min-width:0;
    overflow-x:hidden;
  }

  .ba-sheet,
  .ba-modal{
    min-width:0;
    max-width:calc(100vw - var(--portal-content-left,0px) - 20px);
  }
}

/* Shared portal styling: scope changes only to Branch / Report settings. */
.branch-settings-page { min-height:0; background:transparent; padding:3px 0 14px; }
.role-shell.branch-workspace-layout .branch-settings-page > .ba-search-card {display:none;}
.branch-settings-page .branch-live-preview { margin:0 0 8px; border-radius:12px; box-shadow:none; padding:8px 10px; }
.branch-settings-page .branch-settings-list { margin-top:4px; gap:7px; }
.branch-settings-page .branch-settings-list .student-row {border-radius:13px; padding:10px; box-shadow:0 2px 9px rgba(15,23,42,.035);}
.branch-settings-page .branch-settings-icon {width:34px;height:34px;border-radius:10px;font-size:16px;flex-shrink:0;}
.branch-settings-page .ba-table-card.branch-settings-table-card {overflow-x:auto;border-radius:12px;margin-top:4px;box-shadow:0 3px 12px rgba(15,23,42,.045);}
.branch-settings-table {width:100%;border-collapse:collapse;table-layout:auto;font-size:12px;}
.branch-settings-table th {background:var(--surface-2,var(--bg,#f7f8fb));font-size:10px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted,#64748b);font-weight:800;}
.branch-settings-table th, .branch-settings-table td {text-align:left;padding:10px 12px;border-bottom:1px solid var(--border,rgba(148,163,184,.15));vertical-align:middle;}
.branch-settings-table tbody tr:last-child td {border-bottom:0;}
.branch-settings-table tbody tr:hover {background:color-mix(in srgb,var(--ba-primary) 3%,transparent);}
.branch-settings-table td:nth-child(2) {font-weight:650;}
.branch-settings-table td:nth-child(3) {font-size:11px;color:var(--muted,#64748b);}
.branch-setting-table-name {display:flex;align-items:center;gap:9px;min-width:155px;}
.branch-setting-table-name strong {font-size:12px;font-weight:850;}
.branch-settings-page .branch-setting-table-edit {width:auto;min-height:30px;padding:5px 12px;border-radius:8px;background:color-mix(in srgb,var(--ba-primary) 8%,var(--surface,#fff));color:var(--ba-primary);border:1px solid color-mix(in srgb,var(--ba-primary) 25%,var(--border,#d6dce4));font-weight:750;cursor:pointer;}
.branch-settings-page .branch-setting-table-edit:hover {background:color-mix(in srgb,var(--ba-primary) 15%,var(--surface,#fff));}
.branch-settings-page .ba-sheet,.branch-settings-page .ba-modal {border-radius:15px;}
@media (max-width:899px) {.branch-settings-table {min-width:620px;}}

/* V10 — STUDENTS.tsx RECORD SURFACE PARITY. Keep complex editor sheets unchanged. */
.ba-page {
  width:100%; max-width:none; min-width:0; min-height:0;
  margin:0; padding:5px; padding-bottom:max(20px,env(safe-area-inset-bottom));
  background:var(--bg,var(--background,#f2f4f7)); overflow-x:clip;
}
.ba-page .ba-list,.ba-page .ba-table-card,.ba-page .ba-analysis-grid {
  box-sizing:border-box; width:100%; max-width:none; min-width:0;
  margin-left:0; margin-right:0;
}
.ba-page .ba-list {display:grid;gap:9px;margin-top:2px;align-items:stretch;grid-template-columns:minmax(0,1fr)}
.ba-page .ba-list > .student-row {
  box-sizing:border-box;position:relative;width:100%;min-width:0;margin:0;
  padding:9px 10px;display:grid;grid-template-columns:auto minmax(0,1fr) auto;
  align-items:center;gap:10px;text-align:left;cursor:pointer;
  background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 93%,var(--text,#182235) 7%);
  border:1px solid color-mix(in srgb,var(--border,#d4dae3) 85%,var(--text,#182235) 15%);
  color:var(--text,#182235);box-shadow:none;border-radius:13px;
  transition:border-color .12s ease;
}
.ba-page .ba-list > .student-row:hover,.ba-page .ba-list > .student-row:focus-visible {
  transform:none;box-shadow:none;border-color:color-mix(in srgb,var(--ba-primary) 45%,var(--border,#d4dae3));
}
.ba-page .ba-list > .student-row::before {display:none}
.ba-page .student-main,.ba-page .student-main strong,.ba-page .student-main small,.ba-page .student-main em {
  display:block;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
}
.ba-page .student-main strong {color:var(--text,#182235);font-size:14px;font-weight:850;letter-spacing:-.02em}
.ba-page .student-main small {margin-top:3px;color:var(--muted,#64748b);font-size:12px;font-weight:700;font-style:normal}
.ba-page .student-main em {margin-top:3px;color:var(--muted,#64748b);font-size:11px;font-weight:650;font-style:normal}
.ba-page .student-side {display:grid;justify-items:end;gap:6px;flex:0 0 auto}
.ba-page .student-side i {color:var(--muted,#64748b);font-size:18px;font-weight:900;font-style:normal;line-height:1}
.ba-page .grading-icon,.ba-page .rule-icon,.ba-page .branch-settings-icon {
  width:40px;height:40px;flex:0 0 auto;display:grid;place-items:center;
  border-radius:12px;box-shadow:none;font-size:17px;
  color:var(--ba-primary);background:color-mix(in srgb,var(--ba-primary) 11%,var(--card-bg,var(--surface,#fff)));
}
.ba-page .ba-table-card {
  display:block;width:100%;max-width:none;min-width:0;margin-top:2px;padding:4px;overflow:visible;
  background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 93%,var(--text,#182235) 7%);
  border:1px solid color-mix(in srgb,var(--border,#d4dae3) 85%,var(--text,#182235) 15%);
  border-radius:13px;box-shadow:none;
}
.ba-page .ba-table-scroll {
  box-sizing:border-box;width:100%;max-width:100%;min-width:0;margin:0;
  overflow-x:auto;overflow-y:auto;overscroll-behavior-x:contain;
  -webkit-overflow-scrolling:touch;border-radius:10px;
  border:1px solid var(--border,#d4dae3);
}
.ba-page .ba-table-scroll table {
  width:100%;min-width:780px;max-width:none;margin:0;border-collapse:collapse;
  background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 95%,var(--text,#182235) 5%);
}
.ba-page .ba-table-scroll th,.ba-page .ba-table-scroll td {
  padding:9px 10px;vertical-align:middle;text-align:left;font-size:12px;
  border-bottom:1px solid var(--border,rgba(148,163,184,.18));
}
.ba-page .ba-table-scroll thead th {
  position:sticky;top:0;z-index:2;
  color:var(--muted,#64748b);font-size:10px;font-weight:850;text-transform:uppercase;letter-spacing:.045em;
  background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 85%,var(--text,#182235) 15%);
}
.ba-page .ba-table-scroll tbody tr:nth-child(even) {
  background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 89%,var(--text,#182235) 11%);
}
.ba-page .ba-table-scroll tbody tr:hover {background:color-mix(in srgb,var(--ba-primary) 5%,transparent)}
.ba-page .ba-table-scroll td {background:transparent}
.ba-page .ba-table-person {display:flex;align-items:center;gap:9px;min-width:160px}
.ba-page .ba-table-person .table-avatar {width:32px;height:32px;flex:0 0 32px;border-radius:10px;font-size:13px}
.ba-page .ba-table-person > div {min-width:0}
.ba-page .ba-table-person strong,.ba-page .ba-table-person span {display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ba-page .ba-table-person span {color:var(--muted,#64748b);font-size:11px;margin-top:2px}
.ba-page .ba-table-actions {display:flex;align-items:center;gap:7px;flex-wrap:nowrap;width:100%;max-width:100%;overflow-x:auto;scrollbar-width:none}
.ba-page .ba-table-actions::-webkit-scrollbar {display:none}
.ba-page .ba-table-actions button,.ba-page .branch-setting-table-edit {
  flex:0 0 auto;min-height:34px;padding:0 10px;border-radius:999px;
  border:1px solid var(--border,#d4dae3);background:var(--surface,#fff);
  color:var(--text,#182235);font-size:11px;font-weight:800;cursor:pointer;white-space:nowrap;
}
.ba-page .ba-table-actions button:first-child,.ba-page .branch-setting-table-edit {
  background:var(--ba-primary);color:#fff;border-color:var(--ba-primary);
}
.ba-page .ba-table-actions button.ba-delete {
  background:color-mix(in srgb,#dc2626 7%,var(--surface,#fff));color:#991b1b;
  border-color:color-mix(in srgb,#dc2626 24%,var(--border,#d4dae3));
}
/* Students uses the shell toolbar, not duplicated content toolbar/chips. */
.role-shell.branch-workspace-layout .ba-page > .ba-search-card,
.role-shell.branch-workspace-layout .ba-page > .ba-filter-chips {display:none!important}
@media(min-width:680px) and (max-width:1023px){.ba-page .ba-list{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(min-width:1024px){.ba-page .ba-list{grid-template-columns:repeat(4,minmax(0,1fr))}}
@media(max-width:679px){.ba-page .ba-list{grid-template-columns:minmax(0,1fr)}}
@media(max-width:639px){.ba-page{padding:3px;padding-bottom:max(14px,env(safe-area-inset-bottom))}.ba-page .ba-list{gap:7px}.ba-page .ba-list>.student-row{padding:9px}.ba-page .ba-table-scroll th,.ba-page .ba-table-scroll td{padding:8px 9px}}
@media(prefers-reduced-motion:reduce){.ba-page .ba-list>.student-row{transition:none}}

/* Branch/Report Settings: exactly the same Students compact record presentation. */
.branch-settings-page .branch-settings-list{grid-template-columns:minmax(0,1fr);gap:9px;margin-top:2px}
.branch-settings-page .branch-settings-list>.student-row {border-radius:13px;box-shadow:none;padding:9px 10px}
.branch-settings-page .branch-settings-icon {width:40px;height:40px;border-radius:12px;font-size:17px;flex-shrink:0;box-shadow:none}
.branch-settings-page .ba-table-card.branch-settings-table-card {padding:4px;border-radius:13px;box-shadow:none;overflow:visible;margin-top:2px}
.branch-settings-page .branch-settings-table {width:100%;min-width:780px;border-collapse:collapse;font-size:12px}
.branch-settings-page .branch-settings-table th,.branch-settings-page .branch-settings-table td{padding:9px 10px;border-bottom:1px solid var(--border,#d4dae3);text-align:left;vertical-align:middle}
.branch-settings-page .branch-settings-table th{position:sticky;top:0;background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 85%,var(--text,#182235) 15%);font-size:10px}
.branch-settings-page .branch-settings-table td:nth-child(2){font-weight:650}
.branch-settings-page .branch-settings-table td:nth-child(3){color:var(--muted,#64748b);font-size:11px}
.branch-settings-page .branch-setting-table-name {display:flex;align-items:center;gap:9px;min-width:160px}
.branch-settings-page .branch-setting-table-name strong{font-weight:850;font-size:12px}
.branch-settings-page .ba-table-person .branch-settings-icon{color:var(--ba-primary);font-size:16px;display:grid;margin:0}
.branch-settings-page .branch-setting-table-edit{min-height:34px;border-radius:999px;color:#fff;background:var(--ba-primary)}
.branch-settings-page .ba-sheet,.branch-settings-page .ba-modal{border-radius:15px}
@media(min-width:680px) and (max-width:1023px){.branch-settings-page .branch-settings-list{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(min-width:1024px){.branch-settings-page .branch-settings-list{grid-template-columns:repeat(4,minmax(0,1fr))}}
@media(max-width:679px){.branch-settings-page .branch-settings-list{grid-template-columns:minmax(0,1fr)}}

`;
/** Operational branch settings; report controls have their own module. */
export default function Branchsettings() { return <BranchSettingsWorkspace view="branch" />; }
