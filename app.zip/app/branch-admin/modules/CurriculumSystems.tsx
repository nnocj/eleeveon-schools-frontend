"use client";

/**
 * app/branch-admin/modules/CurriculumSystems.tsx
 * Unified single-file curriculum and pathway workspace.
 * V36 — Students-style responsive setup: shared actions, compact
 * Curriculums/Pathways switch, viewport forms, and retained offline CRUD.
 */

import React, { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useRegisterBranchWorkspaceToolbar } from "../../components/role-portals/shell/BranchWorkspaceToolbar";
import BranchViewportPortal from "../../components/role-portals/shell/BranchViewportPortal";

import { useAccount } from "../../context/account-context";
import { useSettings } from "../../context/settings-context";
import { useActiveBranch } from "../../context/active-branch-context";
import { useActiveMembership } from "../../context/active-membership-context";
import {
  db,
  type AcademicStructure,
  type Curriculum,
  type CurriculumPathway,
  type CurriculumSubject,
  type Organization,
  type Program,
  type StudentCurriculum,
} from "../../lib/db/db";
import { createLocal, listActiveLocal, softDeleteLocal, updateLocal } from "../../lib/sync/syncUtils";
import { useDataRevision } from "../../hooks/useDataRevision";
import { useBackgroundLoader } from "../../hooks/useBackgroundLoader";
import { useEntityMediaUrls } from "../../hooks/useEntityMediaUrls";
import { useBranchWorkspaceScope } from "../../hooks/useBranchWorkspaceScope";
import { useBranchTableRevision } from "../../hooks/useBranchTableRevision";
import {
  softDeleteOwnerFieldAssets,
  MediaOwners,
  commitMediaAssetsToOwner,
  createMediaSessionKey,
  saveImageAsset,
} from "../../lib/media/mediaAssetUtils";

type CurriculumSystemsMode = "curriculums" | "pathways";
const CURRICULUM_SYSTEMS_MODE_KEY = "eleeveon_curriculum_systems_mode";

function readCurriculumSystemsMode(): CurriculumSystemsMode {
  if (typeof window === "undefined") return "curriculums";
  try {
    return window.localStorage.getItem(CURRICULUM_SYSTEMS_MODE_KEY) === "pathways"
      ? "pathways"
      : "curriculums";
  } catch {
    return "curriculums";
  }
}

const CurriculumsModule = (() => {
type ViewMode = "cards" | "table" | "summary";
type ToastTone = "success" | "error" | "info";

type TenantRow = {
  accountId?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  isDeleted?: boolean;
  active?: boolean;
  status?: string;
};

type CurriculumView = {
  id: string;
  row: Curriculum;
  academicStructureName: string;
  programName: string;
  organizationName: string;
  pathwayCount: number;
  subjectCount: number;
  studentCount: number;
  active: boolean;
  locked: boolean;
};

type FormState = {
  id?: string;
  academicStructureId: string;
  programId: string;
  organizationId: string;
  name: string;
  code: string;
  description: string;
  curriculumVersion: string;
  totalCredits: string;
  durationPeriods: string;
  effectiveFrom: string;
  effectiveTo: string;
  photo: string;
  photoMediaId?: string;
  bannerImage: string;
  bannerImageMediaId?: string;
  active: boolean;
  locked: boolean;
};

const CURRICULUM_MEDIA_OWNER_TABLE = MediaOwners.CURRICULUMS;

const emptyForm: FormState = {
  academicStructureId: "",
  programId: "",
  organizationId: "",
  name: "",
  code: "",
  description: "",
  curriculumVersion: "",
  totalCredits: "",
  durationPeriods: "",
  effectiveFrom: "",
  effectiveTo: "",
  photo: "",
  photoMediaId: undefined,
  bannerImage: "",
  bannerImageMediaId: undefined,
  active: true,
  locked: false,
};

const safeRecordMediaValue = (value?: string) => {
  const media = String(value || "").trim();
  if (!media || media.startsWith("blob:") || media.startsWith("data:"))
    return undefined;
  return media;
};

const idOf = (value: any): string => {
  if (value === undefined || value === null) return "";
  return String(value).trim();
};


const cleanId = (value: unknown): string => {
  const normalized =
    value === undefined ||
    value === null
      ? ""
      : String(value).trim();

  return normalized &&
    normalized !== "0" &&
    normalized !== "undefined" &&
    normalized !== "null"
    ? normalized
    : "";
};

/**
 * syncUtils create/update helpers may return an ID directly, a saved row,
 * or an object containing id/localId. Media cannot be committed until the
 * permanent owner ID is resolved safely.
 */
const savedEntityId = (
  result: unknown,
  fallback?: unknown,
): string => {
  if (
    typeof result === "string" ||
    typeof result === "number"
  ) {
    return cleanId(result);
  }

  if (
    result &&
    typeof result === "object"
  ) {
    const record =
      result as Record<
        string,
        unknown
      >;

    return cleanId(
      record.id ||
        record.localId ||
        record.curriculumId ||
        record.entityId ||
        record.recordId ||
        fallback,
    );
  }

  return cleanId(fallback);
};

const OPEN_WORKSPACE_KEY = "eleeveon_open_workspace";

type OpenWorkspaceSession = {
  membership?: Record<string, any> | null;
  membershipId?: string | null;
  role?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  teacherId?: string | null;
  studentId?: string | null;
  parentId?: string | null;
  memberName?: string | null;
  fullName?: string | null;
  userName?: string | null;
  openedAt?: number;
};

function safeStorageRead(key: string) {
  if (typeof window === "undefined") return null;

  try {
    return (
      window.localStorage.getItem(key) || window.sessionStorage.getItem(key)
    );
  } catch {
    return null;
  }
}

function safeJsonRead<T>(key: string): T | null {
  const raw = safeStorageRead(key);
  if (!raw) return null;

  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

function readOpenWorkspaceSession() {
  return safeJsonRead<OpenWorkspaceSession>(OPEN_WORKSPACE_KEY);
}

function readStoredActiveMembership() {
  return safeJsonRead<Record<string, any>>("activeMembership");
}

function firstLocalId(...values: unknown[]): string {
  for (const value of values) {
    const parsed = idOf(value);
    if (parsed) return parsed;
  }

  return "";
}

function selectedWorkspaceSchoolId(args: {
  openWorkspace?: OpenWorkspaceSession | null;
  activeMembership?: Record<string, any> | null;
  activeSchoolId?: unknown;
  activeSchool?: Record<string, any> | null;
  settings?: Record<string, any> | null;
}) {
  const storedMembership = readStoredActiveMembership();
  const membership =
    args.openWorkspace?.membership ||
    args.activeMembership ||
    storedMembership ||
    null;

  return firstLocalId(
    args.openWorkspace?.schoolId,
    membership?.schoolId,
    membership?.school?.id,
    args.activeSchoolId,
    args.activeSchool?.id,
    args.settings?.schoolId,
    safeStorageRead("activeSchoolId"),
  );
}

function selectedWorkspaceBranchId(args: {
  openWorkspace?: OpenWorkspaceSession | null;
  activeMembership?: Record<string, any> | null;
  activeBranchId?: unknown;
  activeBranch?: Record<string, any> | null;
  settings?: Record<string, any> | null;
}) {
  const storedMembership = readStoredActiveMembership();
  const membership =
    args.openWorkspace?.membership ||
    args.activeMembership ||
    storedMembership ||
    null;

  return firstLocalId(
    args.openWorkspace?.branchId,
    membership?.branchId,
    membership?.schoolBranchId,
    membership?.branch?.id,
    args.activeBranchId,
    args.activeBranch?.id,
    args.settings?.branchId,
    safeStorageRead("activeBranchId"),
  );
}

const sameId = (a: any, b: any) => String(a ?? "") === String(b ?? "");
const safeLower = (value: any) =>
  String(value || "")
    .toLowerCase()
    .trim();
const tableSafe = (name: string) => (db as any)[name];

const isActiveRow = (row: any) => {
  const status = safeLower(row?.status);
  if (row?.isDeleted) return false;
  if (row?.active === false) return false;
  if (["inactive", "deleted", "archived", "suspended"].includes(status))
    return false;
  return true;
};

const timeText = (value?: string | number | null) => {
  if (!value) return "Not set";
  const time = typeof value === "number" ? value : new Date(value).getTime();
  if (!Number.isFinite(time)) return "Not set";
  try {
    return new Intl.DateTimeFormat("en-GH", {
      month: "short",
      day: "2-digit",
      year: "numeric",
    }).format(new Date(time));
  } catch {
    return "Not set";
  }
};

const periodText = (from?: string, to?: string) => {
  if (!from && !to) return "Not set";
  if (from && to) return `${timeText(from)} → ${timeText(to)}`;
  return from ? `From ${timeText(from)}` : `Until ${timeText(to)}`;
};

function Chip({
  children,
  tone = "gray",
}: {
  children: React.ReactNode;
  tone?: "green" | "red" | "blue" | "gray" | "orange" | "purple";
}) {
  return <span className={`ba-chip ${tone}`}>{children}</span>;
}

function Empty({
  icon,
  title,
  text,
}: {
  icon: string;
  title: string;
  text: string;
}) {
  return (
    <section className="ba-empty">
      <div className="ba-empty-icon">{icon}</div>
      <h3>{title}</h3>
      <p>{text}</p>
    </section>
  );
}

function MiniStat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <span>
      <b>{value}</b>
      {label}
    </span>
  );
}

function CurriculumsWorkspace() {
  const dataRevision = useBranchTableRevision([
    "curriculums",
    "academicStructures",
    "programs",
    "organizations",
    "curriculumPathways",
    "curriculumSubjects",
    "studentCurriculums",
    "mediaAssets",
    "mediaBlobs",
  ]);
  const mediaSessionKeyRef = useRef(
    createMediaSessionKey(CURRICULUM_MEDIA_OWNER_TABLE),
  );

  const uploadedMediaAssetIds = useRef<{
    photo?: string;
    bannerImage?: string;
  }>({});
  const router = useRouter();
  const { settings, loading: settingsLoading } = useSettings();
  const workspace = useBranchWorkspaceScope();
  const {
    accountId,
    schoolId,
    branchId,
    membership: activeMembership,
    authenticated,
    restoring: accountLoading,
    branchLoading: contextLoading,
    ready: workspaceReady,
    error: workspaceError,
  } = workspace;

  const primary = settings?.primaryColor || "var(--primary-color, #2563eb)";

  const { loading, setLoading } = useBackgroundLoader();
  const [saving, setSaving] = useState(false);
  const [rows, setRows] = useState<Curriculum[]>([]);
  const resolvedMediaById = useEntityMediaUrls({
    accountId,
    ownerTable: "curriculums",
    rows: rows,
    fields: [
      { fieldKey: "photo", mediaIdKey: "photoMediaId" },
      { fieldKey: "bannerImage", mediaIdKey: "bannerImageMediaId" },
    ],
  });
  const [academicStructures, setAcademicStructures] = useState<
    AcademicStructure[]
  >([]);
  const [programs, setPrograms] = useState<Program[]>([]);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [pathways, setPathways] = useState<CurriculumPathway[]>([]);
  const [curriculumSubjects, setCurriculumSubjects] = useState<
    CurriculumSubject[]
  >([]);
  const [studentCurriculums, setStudentCurriculums] = useState<
    StudentCurriculum[]
  >([]);

  const [viewMode, setViewMode] = useState<ViewMode>("cards");
  useEffect(() => { if (typeof window !== "undefined") setViewMode(window.matchMedia("(min-width: 900px)").matches ? "table" : "cards"); }, []);
  const [search, setSearch] = useState("");
  const [filterAcademicStructureId, setFilterAcademicStructureId] =
    useState("all");
  const [filterProgramId, setFilterProgramId] = useState("all");
  const [filterOrganizationId, setFilterOrganizationId] = useState("all");
  const [filterStatus, setFilterStatus] = useState<
    "all" | "active" | "inactive" | "locked"
  >("active");

  const [filterOpen, setFilterOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<CurriculumView | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [toast, setToast] = useState<{
    tone: ToastTone;
    message: string;
  } | null>(null);

  useEffect(() => {
    if (accountLoading || contextLoading) return;
    if (!authenticated || !accountId) router.replace("/login");
    // Missing branch workspace is handled locally so the selected-role flow is not broken.
  }, [
    accountLoading,
    contextLoading,
    authenticated,
    accountId,
    schoolId,
    branchId,
    router,
  ]);

  const sameTenant = (row: TenantRow) =>
    (!row.accountId || row.accountId === accountId) &&
    (!row.schoolId || sameId(row.schoolId, schoolId)) &&
    (!row.branchId || sameId(row.branchId, branchId)) &&
    !row.isDeleted;

  const showToast = (tone: ToastTone, message: string) => {
    setToast({ tone, message });
    window.setTimeout(
      () =>
        setToast((current) => (current?.message === message ? null : current)),
      4200,
    );
  };

  const clearData = () => {
    setRows([]);
    setAcademicStructures([]);
    setPrograms([]);
    setOrganizations([]);
    setPathways([]);
    setCurriculumSubjects([]);
    setStudentCurriculums([]);
  };

  const load = async () => {
    if (!authenticated || !accountId || !schoolId || !branchId) {
      clearData();
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const [
        curriculumRows,
        academicStructureRows,
        programRows,
        organizationRows,
        pathwayRows,
        curriculumSubjectRows,
        studentCurriculumRows,
      ] = await Promise.all([
        tableSafe("curriculums")?.toArray?.() || [],
        listActiveLocal("academicStructures", {
          accountId,
          schoolId: schoolId,
          branchId: branchId,
        } as any),
        listActiveLocal("programs", {
          accountId,
          schoolId: schoolId,
          branchId: branchId,
        } as any),
        listActiveLocal("organizations", {
          accountId,
          schoolId: schoolId,
          branchId: branchId,
        } as any),
        tableSafe("curriculumPathways")?.toArray?.() || [],
        tableSafe("curriculumSubjects")?.toArray?.() || [],
        tableSafe("studentCurriculums")?.toArray?.() || [],
      ]);

      setRows(
        (curriculumRows as Curriculum[])
          .filter((row) => sameTenant(row as TenantRow))
          .sort((a: any, b: any) =>
            String(a.name || "").localeCompare(String(b.name || "")),
          ),
      );
      setAcademicStructures(
        (academicStructureRows as AcademicStructure[]).sort((a: any, b: any) =>
          String(a.name || "").localeCompare(String(b.name || "")),
        ),
      );
      setPrograms(
        (programRows as Program[]).sort((a: any, b: any) =>
          String(a.name || "").localeCompare(String(b.name || "")),
        ),
      );
      setOrganizations(
        (organizationRows as Organization[]).sort((a: any, b: any) =>
          String(a.name || "").localeCompare(String(b.name || "")),
        ),
      );
      setPathways(
        (pathwayRows as CurriculumPathway[]).filter((row) =>
          sameTenant(row as TenantRow),
        ),
      );
      setCurriculumSubjects(
        (curriculumSubjectRows as CurriculumSubject[]).filter((row) =>
          sameTenant(row as TenantRow),
        ),
      );
      setStudentCurriculums(
        (studentCurriculumRows as StudentCurriculum[]).filter((row) =>
          sameTenant(row as TenantRow),
        ),
      );
    } catch (error) {
      console.error(error);
      clearData();
      showToast("error", "Failed to load curriculums.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (accountLoading || settingsLoading || contextLoading) return;
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    authenticated,
    accountId,
    schoolId,
    branchId,
    accountLoading,
    settingsLoading,
    contextLoading,
    dataRevision,
  ]);

  const academicStructureMap = useMemo(
    () => new Map(academicStructures.map((row: any) => [idOf(row.id), row])),
    [academicStructures],
  );
  const programMap = useMemo(
    () => new Map(programs.map((row: any) => [idOf(row.id), row])),
    [programs],
  );
  const organizationMap = useMemo(
    () => new Map(organizations.map((row: any) => [idOf(row.id), row])),
    [organizations],
  );

  const usage = useMemo(() => {
    const pathwayMap = new Map<string, number>();
    const subjectMap = new Map<string, number>();
    const studentMap = new Map<string, number>();

    pathways.forEach((row: any) => {
      const id = idOf(row.curriculumId);
      if (id) pathwayMap.set(id, (pathwayMap.get(id) || 0) + 1);
    });

    curriculumSubjects.forEach((row: any) => {
      const id = idOf(row.curriculumId);
      if (id) subjectMap.set(id, (subjectMap.get(id) || 0) + 1);
    });

    studentCurriculums.forEach((row: any) => {
      const id = idOf(row.curriculumId);
      if (id) studentMap.set(id, (studentMap.get(id) || 0) + 1);
    });

    return { pathwayMap, subjectMap, studentMap };
  }, [curriculumSubjects, pathways, studentCurriculums]);

  const viewRows = useMemo<CurriculumView[]>(
    () =>
      rows.map((row: any) => {
        const id = idOf(row.id);
        const academicStructure = academicStructureMap.get(
          idOf(row.academicStructureId),
        );
        const program = programMap.get(idOf(row.programId));
        const organization = organizationMap.get(idOf(row.organizationId));

        return {
          id,
          row,
          academicStructureName:
            academicStructure?.name || "No academic structure",
          programName: program?.name || "No program",
          organizationName: organization?.name || "No organization",
          pathwayCount: usage.pathwayMap.get(id) || 0,
          subjectCount: usage.subjectMap.get(id) || 0,
          studentCount: usage.studentMap.get(id) || 0,
          active: isActiveRow(row),
          locked: row.locked === true,
        };
      }),
    [academicStructureMap, organizationMap, programMap, rows, usage],
  );

  const filteredRows = useMemo(() => {
    const term = search.trim().toLowerCase();
    return viewRows
      .filter((item) => {
        const row: any = item.row;
        if (
          filterAcademicStructureId !== "all" &&
          !sameId(row.academicStructureId, filterAcademicStructureId)
        )
          return false;
        if (
          filterProgramId !== "all" &&
          !sameId(row.programId, filterProgramId)
        )
          return false;
        if (
          filterOrganizationId !== "all" &&
          !sameId(row.organizationId, filterOrganizationId)
        )
          return false;
        if (filterStatus === "active" && !item.active) return false;
        if (filterStatus === "inactive" && item.active) return false;
        if (filterStatus === "locked" && !item.locked) return false;
        if (!term) return true;
        return `${row.name} ${row.code || ""} ${row.description || ""} ${row.curriculumVersion || ""} ${item.academicStructureName} ${item.programName} ${item.organizationName}`
          .toLowerCase()
          .includes(term);
      })
      .sort((a, b) =>
        String((a.row as any).name || "").localeCompare(
          String((b.row as any).name || ""),
        ),
      );
  }, [
    filterAcademicStructureId,
    filterOrganizationId,
    filterProgramId,
    filterStatus,
    search,
    viewRows,
  ]);

  const summary = useMemo(
    () => ({
      total: viewRows.length,
      active: viewRows.filter((item) => item.active).length,
      inactive: viewRows.filter((item) => !item.active).length,
      locked: viewRows.filter((item) => item.locked).length,
      pathways: viewRows.reduce((sum, item) => sum + item.pathwayCount, 0),
      subjects: viewRows.reduce((sum, item) => sum + item.subjectCount, 0),
      students: viewRows.reduce((sum, item) => sum + item.studentCount, 0),
      showing: filteredRows.length,
    }),
    [filteredRows.length, viewRows],
  );

  const activeFilterCount = useMemo(
    () =>
      [
        filterAcademicStructureId,
        filterProgramId,
        filterOrganizationId,
        filterStatus,
      ].filter((value) => value !== "all" && value !== "active").length,
    [
      filterAcademicStructureId,
      filterOrganizationId,
      filterProgramId,
      filterStatus,
    ],
  );

  const countsByAcademicStructure = useMemo(
    () => groupedCounts(viewRows, (item) => item.academicStructureName),
    [viewRows],
  );
  const countsByProgram = useMemo(
    () => groupedCounts(viewRows, (item) => item.programName),
    [viewRows],
  );
  const countsByStatus = useMemo(
    () =>
      groupedCounts(viewRows, (item) =>
        item.locked ? "Locked" : item.active ? "Active" : "Inactive",
      ),
    [viewRows],
  );

  const updateForm = (patch: Partial<FormState>) =>
    setForm((current) => ({ ...current, ...patch }));

  const handleImageUpload = async (
    field: "photo" | "bannerImage",
    file?: File,
  ) => {
    if (!file || !accountId || !schoolId || !branchId) return;

    try {
      const result = await saveImageAsset(file, {
        accountId: String(accountId),
        schoolId: schoolId,
        branchId: branchId,
        ownerTable: CURRICULUM_MEDIA_OWNER_TABLE,
        ownerId: undefined,
        ownerTempKey: mediaSessionKeyRef.current,
        fieldKey: field,
        variant: field === "photo" ? "avatar" : "cover",
        replaceExisting: true,
      });

      uploadedMediaAssetIds.current[field] =
        cleanId(result.assetId);

      updateForm({
        [field]: result.previewUrl,
        [field === "photo"
          ? "photoMediaId"
          : "bannerImageMediaId"]:
          result.assetId,
      } as Partial<FormState>);

      showToast(
        "info",
        `${field === "photo" ? "Photo" : "Banner"} prepared. Save to attach and upload it.`,
      );
    } catch (error: any) {
      showToast("error", error?.message || "Failed to process image.");
    }
  };

  const clearFilters = () => {
    setFilterAcademicStructureId("all");
    setFilterProgramId("all");
    setFilterOrganizationId("all");
    setFilterStatus("active");
  };

  const requireTenant = () => {
    if (!authenticated || !accountId || !schoolId || !branchId) {
      showToast("error", "Sign in and select a school branch first.");
      return false;
    }
    return true;
  };

  const openCreate = () => {
    if (!requireTenant()) return;
    mediaSessionKeyRef.current = createMediaSessionKey(
      CURRICULUM_MEDIA_OWNER_TABLE,
    );
    uploadedMediaAssetIds.current = {};
    setSelectedItem(null);
    setForm({
      ...emptyForm,
      academicStructureId:
        filterAcademicStructureId !== "all"
          ? filterAcademicStructureId
          : academicStructures[0]?.id
            ? String(academicStructures[0].id)
            : "",
      programId: filterProgramId !== "all" ? filterProgramId : "",
      organizationId:
        filterOrganizationId !== "all" ? filterOrganizationId : "",
    });
    setModalOpen(true);
  };

  const openEdit = (item: CurriculumView) => {
    const row: any = item.row;
    const curriculumId = idOf(item.id);

    mediaSessionKeyRef.current = createMediaSessionKey(
      CURRICULUM_MEDIA_OWNER_TABLE,
    );
    uploadedMediaAssetIds.current = {};
    setSelectedItem(null);
    setForm({
      id: curriculumId,
      academicStructureId: row.academicStructureId
        ? String(row.academicStructureId)
        : "",
      programId: row.programId ? String(row.programId) : "",
      organizationId: row.organizationId ? String(row.organizationId) : "",
      name: row.name || "",
      code: row.code || "",
      description: row.description || "",
      curriculumVersion: row.curriculumVersion || "",
      totalCredits: row.totalCredits == null ? "" : String(row.totalCredits),
      durationPeriods:
        row.durationPeriods == null ? "" : String(row.durationPeriods),
      effectiveFrom: row.effectiveFrom || "",
      effectiveTo: row.effectiveTo || "",
      photo:
        resolvedMediaById[curriculumId]?.photo ||
        safeRecordMediaValue(row.photo) ||
        "",
      photoMediaId: row.photoMediaId ? String(row.photoMediaId) : undefined,
      bannerImage:
        resolvedMediaById[curriculumId]?.bannerImage ||
        safeRecordMediaValue(row.bannerImage) ||
        "",
      bannerImageMediaId: row.bannerImageMediaId
        ? String(row.bannerImageMediaId)
        : undefined,
      active: item.active,
      locked: item.locked,
    });
    setModalOpen(true);
  };

  const validate = () => {
    if (!authenticated || !accountId) return "Sign in first.";
    if (!schoolId || !branchId) return "Select a school branch first.";
    if (!form.academicStructureId) return "Select academic structure.";
    if (!form.name.trim()) return "Enter curriculum name.";

    const duplicate = rows.find((row: any) => {
      if (form.id && sameId(row.id, form.id)) return false;
      if (row.isDeleted) return false;
      const sameName = safeLower(row.name) === safeLower(form.name);
      const sameCode =
        !!form.code.trim() && safeLower(row.code) === safeLower(form.code);
      return sameName || sameCode;
    });

    if (duplicate)
      return "A curriculum with this name or code already exists in this branch.";
    return "";
  };

  const save = async (event?: React.FormEvent) => {
    event?.preventDefault();
    const error = validate();
    if (error) {
      showToast("error", error);
      return;
    }

    try {
      setSaving(true);
      const existing = form.id
        ? rows.find((row: any) => sameId(row.id, form.id))
        : undefined;
      const payload: Partial<Curriculum> = {
        accountId: String(accountId),
        schoolId: schoolId,
        branchId: branchId,
        academicStructureId: idOf(form.academicStructureId),
        programId: form.programId ? idOf(form.programId) : undefined,
        organizationId: form.organizationId
          ? idOf(form.organizationId)
          : undefined,
        name: form.name.trim(),
        code: form.code.trim() || undefined,
        description: form.description.trim() || undefined,
        curriculumVersion: form.curriculumVersion.trim() || undefined,
        totalCredits:
          form.totalCredits === "" ? undefined : Number(form.totalCredits),
        durationPeriods:
          form.durationPeriods === ""
            ? undefined
            : Number(form.durationPeriods),
        effectiveFrom: form.effectiveFrom || undefined,
        effectiveTo: form.effectiveTo || undefined,
        photo:
          safeRecordMediaValue(
            existing?.photo,
          ),
        photoMediaId:
          existing?.photoMediaId ||
          undefined,
        bannerImage:
          safeRecordMediaValue(
            existing?.bannerImage,
          ),
        bannerImageMediaId:
          existing?.bannerImageMediaId ||
          undefined,
        active: form.active,
        locked: form.locked,
        isDeleted: false,
      } as Partial<Curriculum>;

      const savedCurriculum =
        form.id && existing
          ? await updateLocal("curriculums", String(form.id), payload)
          : await createLocal("curriculums", payload as Curriculum);

      const savedCurriculumId =
        savedEntityId(
          savedCurriculum,
          form.id,
        );

      if (!savedCurriculumId) {
        throw new Error(
          "The curriculum was saved, but its permanent ID could not be resolved for image attachment.",
        );
      }

      const committedMedia =
        await commitMediaAssetsToOwner({
          accountId: String(accountId),
          ownerTable:
            CURRICULUM_MEDIA_OWNER_TABLE,
          ownerId: savedCurriculumId,
          ownerTempKey:
            mediaSessionKeyRef.current,
          assets: [
            {
              assetId:
                cleanId(
                  uploadedMediaAssetIds
                    .current.photo,
                ) || undefined,
              fieldKey: "photo",
            },
            {
              assetId:
                cleanId(
                  uploadedMediaAssetIds
                    .current.bannerImage,
                ) || undefined,
              fieldKey: "bannerImage",
            },
          ],
        });

      const committedPhotoId =
        committedMedia.find(
          (item) =>
            item.fieldKey === "photo",
        )?.assetId;

      const committedBannerImageId =
        committedMedia.find(
          (item) =>
            item.fieldKey ===
            "bannerImage",
        )?.assetId;

      if (
        committedPhotoId ||
        committedBannerImageId
      ) {
        await updateLocal(
          "curriculums",
          savedCurriculumId,
          {
            photoMediaId:
              committedPhotoId ||
              existing?.photoMediaId ||
              undefined,
            bannerImageMediaId:
              committedBannerImageId ||
              existing?.bannerImageMediaId ||
              undefined,

            /*
             * New images are resolved from mediaAssets/mediaBlobs.
             * Never store staged blob/data preview strings in sync rows.
             */
            photo:
              safeRecordMediaValue(
                existing?.photo,
              ),
            bannerImage:
              safeRecordMediaValue(
                existing?.bannerImage,
              ),
          } as Partial<Curriculum>,
        );
      }

      uploadedMediaAssetIds.current = {};
      mediaSessionKeyRef.current = createMediaSessionKey(
        CURRICULUM_MEDIA_OWNER_TABLE,
      );
      setModalOpen(false);
      showToast("success", "Curriculum saved.");
      await load();
    } catch (error) {
      console.error(error);
      showToast("error", "Could not save curriculum.");
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (item: CurriculumView) => {
    if (!item.id) return;
    try {
      await updateLocal("curriculums", item.id, {
        active: !item.active,
        isDeleted: false,
      } as Partial<Curriculum>);
      setSelectedItem(null);
      showToast(
        "success",
        item.active ? "Curriculum deactivated." : "Curriculum activated.",
      );
      await load();
    } catch (error) {
      console.error(error);
      showToast("error", "Could not update curriculum status.");
    }
  };

  const toggleLocked = async (item: CurriculumView) => {
    if (!item.id) return;
    try {
      await updateLocal("curriculums", item.id, {
        locked: !item.locked,
        isDeleted: false,
      } as Partial<Curriculum>);
      setSelectedItem(null);
      showToast(
        "success",
        item.locked ? "Curriculum unlocked." : "Curriculum locked.",
      );
      await load();
    } catch (error) {
      console.error(error);
      showToast("error", "Could not update curriculum lock.");
    }
  };

  const remove = async (item: CurriculumView) => {
    const totalUsage =
      item.pathwayCount + item.subjectCount + item.studentCount;
    const ok = window.confirm(
      totalUsage
        ? `"${(item.row as any).name}" has ${totalUsage} linked record(s). Delete anyway?`
        : `Delete "${(item.row as any).name}"?`,
    );
    if (!ok) return;
    try {
      await Promise.all(
        ["photo", "bannerImage"].map((fieldKey) =>
          softDeleteOwnerFieldAssets({
            accountId: String(accountId),

            ownerTable: "curriculums",

            ownerId: idOf(item.id) || undefined,

            fieldKey,
          }),
        ),
      );

      await softDeleteLocal("curriculums", item.id);
      setSelectedItem(null);
      showToast("success", "Curriculum deleted.");
      await load();
    } catch (error) {
      console.error(error);
      showToast("error", "Could not delete curriculum.");
    }
  };

  // Shared Setup actions for the currently mounted Curriculums/Pathways editor.
  useRegisterBranchWorkspaceToolbar("setupWorkspace", {
    add: () => openCreate(), search: setSearch,
    filter: () => setFilterOpen(true), more: () => setMoreOpen(true),
  });
  useRegisterBranchWorkspaceToolbar("curriculumSystems", {
    add: () => openCreate(), search: setSearch,
    filter: () => setFilterOpen(true), more: () => setMoreOpen(true),
  });

  if (accountLoading || settingsLoading || contextLoading || loading) {
    return (
      <State
        primary={primary}
        title="Opening Curriculum Setup..."
        text="Checking branch context, academic structures, programs, organizations, and curriculums."
      />
    );
  }

  if (!authenticated || !accountId)
    return (
      <State
        primary={primary}
        title="Redirecting to login..."
        text="You must sign in before managing curriculums."
      />
    );

  if (!schoolId || !branchId) {
    return (
      <main
        className="ba-page"
        style={{ "--ba-primary": primary } as React.CSSProperties}
      >
        <style>{css}</style>
        <section className="ba-state">
          <h2>Select a branch first</h2>
          <p>Curriculums belong to one active school branch.</p>
          <button
            type="button"
            className="ba-state-button"
            onClick={() => router.push("/account")}
          >
            Go to Account Setup
          </button>
        </section>
      </main>
    );
  }

  return (
    <main
      className="ba-page"
      style={{ "--ba-primary": primary } as React.CSSProperties}
    >
      <style>{css}</style>

      {toast && (
        <section className={`ba-toast ${toast.tone}`}>
          {toast.message}
          <button
            type="button"
            onClick={() => setToast(null)}
            aria-label="Close notification"
          >
            ✕
          </button>
        </section>
      )}

      

      {activeFilterCount > 0 && (
        <></>
      )}

      {viewMode === "summary" && (
        <section className="ba-analysis-grid">
          <AnalysisCard
            title="Curriculums by Academic Structure"
            rows={countsByAcademicStructure}
            total={summary.total}
          />
          <AnalysisCard
            title="Curriculums by Program"
            rows={countsByProgram}
            total={summary.total}
          />
          <AnalysisCard
            title="Curriculums by Status"
            rows={countsByStatus}
            total={summary.total}
          />
          <article className="ba-analysis ba-current-filter">
            <span>Current Filter</span>
            <strong>{summary.showing}</strong>
            <p>Curriculum record(s) currently match your search and filters.</p>
          </article>
          <article className="ba-analysis">
            <span>Links</span>
            <strong>
              {summary.pathways + summary.subjects + summary.students}
            </strong>
            <p>
              {summary.pathways} pathway links · {summary.subjects} subject
              links · {summary.students} student links.
            </p>
          </article>
        </section>
      )}

      {viewMode === "table" && (
        <TableView
          rows={filteredRows}
          openEdit={openEdit}
          toggleActive={toggleActive}
          toggleLocked={toggleLocked}
          remove={remove}
        />
      )}

      {viewMode === "cards" && (
        <section className="ba-grid">
          {filteredRows.map((item) => (
            <CurriculumCard
              key={String(item.id)}
              item={item}
              onOpen={() => setSelectedItem(item)}
            />
          ))}
          {!filteredRows.length && (
            <Empty
              icon="📚"
              title="No curriculums found"
              text="Create curriculum frameworks for this branch, then manage pathways on the separate pathways page."
            />
          )}
        </section>
      )}

      {filterOpen && (
        <BranchViewportPortal themeSourceClass=".curriculum-systems-root .ba-page"><FilterSheet
          search={search}
          setSearch={setSearch}
          academicStructures={academicStructures}
          programs={programs}
          organizations={organizations}
          filterAcademicStructureId={filterAcademicStructureId}
          filterProgramId={filterProgramId}
          filterOrganizationId={filterOrganizationId}
          filterStatus={filterStatus}
          setFilterAcademicStructureId={setFilterAcademicStructureId}
          setFilterProgramId={setFilterProgramId}
          setFilterOrganizationId={setFilterOrganizationId}
          setFilterStatus={setFilterStatus}
          clearFilters={clearFilters}
          onClose={() => setFilterOpen(false)}
        /></BranchViewportPortal>
      )}

      {moreOpen && (
        <BranchViewportPortal themeSourceClass=".curriculum-systems-root .ba-page"><MoreSheet
          viewMode={viewMode}
          setViewMode={(mode) => {
            setViewMode(mode);
            setMoreOpen(false);
          }}
          onRefresh={async () => {
            setMoreOpen(false);
            await load();
          }}
          onClose={() => setMoreOpen(false)}
        /></BranchViewportPortal>
      )}

      {selectedItem && (
        <BranchViewportPortal themeSourceClass=".curriculum-systems-root .ba-page"><ActionSheet
          item={selectedItem}
          openEdit={openEdit}
          toggleActive={toggleActive}
          toggleLocked={toggleLocked}
          remove={remove}
          onClose={() => setSelectedItem(null)}
        /></BranchViewportPortal>
      )}

      {modalOpen && (
        <BranchViewportPortal themeSourceClass=".curriculum-systems-root .ba-page"><CurriculumModal
          form={form}
          saving={saving}
          academicStructures={academicStructures}
          programs={programs}
          organizations={organizations}
          updateForm={updateForm}
          handleImageUpload={handleImageUpload}
          setModalOpen={setModalOpen}
          save={save}
        /></BranchViewportPortal>
      )}
    </main>
  );
}

function State({
  primary,
  title,
  text,
}: {
  primary: string;
  title: string;
  text: string;
}) {
  return (
    <main
      className="ba-page"
      style={{ "--ba-primary": primary } as React.CSSProperties}
    >
      <style>{css}</style>
      <section className="ba-state">
        <div className="ba-spinner" />
        <h2>{title}</h2>
        <p>{text}</p>
      </section>
    </main>
  );
}

function CurriculumCard({
  item,
  onOpen,
}: {
  item: CurriculumView;
  onOpen: () => void;
}) {
  const row: any = item.row;
  return (
    <button type="button" className="curriculum-row" onClick={onOpen}>
      <span className="curriculum-icon">📚</span>
      <span className="curriculum-main">
        <strong>{row.name || "Unnamed curriculum"}</strong>
        <small>
          {item.academicStructureName}
          {row.code ? ` · ${row.code}` : ""}
        </small>
        <em>
          {item.pathwayCount} pathways · {item.subjectCount} subjects ·{" "}
          {item.studentCount} students
        </em>
      </span>
      <span className="curriculum-side">
        <span
          className={`status-dot-mini ${item.locked ? "orange" : item.active ? "green" : "gray"}`}
          title={item.locked ? "Locked" : item.active ? "Active" : "Inactive"}
        />
        <i>⋯</i>
      </span>
    </button>
  );
}

function TableView({
  rows,
  openEdit,
  toggleActive,
  toggleLocked,
  remove,
}: {
  rows: CurriculumView[];
  openEdit: (item: CurriculumView) => void;
  toggleActive: (item: CurriculumView) => void;
  toggleLocked: (item: CurriculumView) => void;
  remove: (item: CurriculumView) => void;
}) {
  return (
    <section className="ba-table-card">
      <div className="ba-table-scroll">
        <table>
          <thead>
            <tr>
              <th>Curriculums ({rows.length})</th>
              <th>Code</th>
              <th>Academic Structure</th>
              <th>Program</th>
              <th>Organization</th>
              <th>Version</th>
              <th>Duration</th>
              <th>Links</th>
              <th>Status</th>
              <th>Updated</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((item) => {
              const row: any = item.row;
              return (
                <tr key={String(item.id)}>
                  <td>
                    <strong>{row.name}</strong>
                    <span>
                      {row.description ||
                        periodText(row.effectiveFrom, row.effectiveTo)}
                    </span>
                  </td>
                  <td>{row.code || "—"}</td>
                  <td>{item.academicStructureName}</td>
                  <td>{item.programName}</td>
                  <td>{item.organizationName}</td>
                  <td>{row.curriculumVersion || "—"}</td>
                  <td>
                    {row.durationPeriods
                      ? `${row.durationPeriods} period(s)`
                      : "—"}
                  </td>
                  <td>
                    {item.pathwayCount} P · {item.subjectCount} S ·{" "}
                    {item.studentCount} St
                  </td>
                  <td>
                    <Chip
                      tone={
                        item.locked ? "orange" : item.active ? "green" : "gray"
                      }
                    >
                      {item.locked
                        ? "Locked"
                        : item.active
                          ? "Active"
                          : "Inactive"}
                    </Chip>
                  </td>
                  <td>{timeText(row.updatedAt || row.createdAt)}</td>
                  <td>
                    <div className="ba-table-actions">
                      <button type="button" onClick={() => openEdit(item)}>
                        Edit
                      </button>
                      <button type="button" onClick={() => toggleActive(item)}>
                        {item.active ? "Deactivate" : "Activate"}
                      </button>
                      <button type="button" onClick={() => toggleLocked(item)}>
                        {item.locked ? "Unlock" : "Lock"}
                      </button>
                      <button
                        type="button"
                        className="ba-delete"
                        onClick={() => remove(item)}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!rows.length && (
          <div className="ba-empty-table">
            No curriculum matches your filters.
          </div>
        )}
      </div>
    </section>
  );
}

function FilterSheet(props: {
  search: string;
  setSearch: (value: string) => void;
  academicStructures: AcademicStructure[];
  programs: Program[];
  organizations: Organization[];
  filterAcademicStructureId: string;
  filterProgramId: string;
  filterOrganizationId: string;
  filterStatus: "all" | "active" | "inactive" | "locked";
  setFilterAcademicStructureId: (value: string) => void;
  setFilterProgramId: (value: string) => void;
  setFilterOrganizationId: (value: string) => void;
  setFilterStatus: (value: "all" | "active" | "inactive" | "locked") => void;
  clearFilters: () => void;
  onClose: () => void;
}) {
  return (
    <div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet">
        <div className="ba-sheet-head">
          <div>
            <h2>Filters</h2>
            <p>Choose only what you need. The page updates after applying.</p>
          </div>
          <button type="button" onClick={props.onClose}>
            ✕
          </button>
        </div>
        <div className="ba-form compact">
        <div className="ba-record-search-in-filter"><span>Search</span><input type="search" value={props.search} onChange={(e)=>props.setSearch(e.target.value)} placeholder="Search curriculums" /></div>
          <label>
            <span>Academic Structure</span>
            <select
              value={props.filterAcademicStructureId}
              onChange={(e) =>
                props.setFilterAcademicStructureId(e.target.value)
              }
            >
              <option value="all">All structures</option>
              {props.academicStructures.map((row: any) => (
                <option key={String(row.id)} value={String(row.id)}>
                  {row.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Program</span>
            <select
              value={props.filterProgramId}
              onChange={(e) => props.setFilterProgramId(e.target.value)}
            >
              <option value="all">All programs</option>
              {props.programs.map((row: any) => (
                <option key={String(row.id)} value={String(row.id)}>
                  {row.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Organization</span>
            <select
              value={props.filterOrganizationId}
              onChange={(e) => props.setFilterOrganizationId(e.target.value)}
            >
              <option value="all">All organizations</option>
              {props.organizations.map((row: any) => (
                <option key={String(row.id)} value={String(row.id)}>
                  {row.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Status</span>
            <select
              value={props.filterStatus}
              onChange={(e) => props.setFilterStatus(e.target.value as any)}
            >
              <option value="active">Active</option>
              <option value="all">All</option>
              <option value="inactive">Inactive</option>
              <option value="locked">Locked</option>
            </select>
          </label>
        </div>
        <div className="ba-sheet-actions">
          <button type="button" onClick={props.clearFilters}>
            Clear
          </button>
          <button type="button" className="primary" onClick={props.onClose}>
            Apply
          </button>
        </div>
      </section>
    </div>
  );
}

function MoreSheet({
  viewMode,
  setViewMode,
  onRefresh,
  onClose,
}: {
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  onRefresh: () => void | Promise<void>;
  onClose: () => void;
}) {
  return (
    <div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet small">
        <div className="ba-sheet-head">
          <div>
            <h2>More</h2>
            <p>Advanced views are here so the main page stays simple.</p>
          </div>
          <button type="button" onClick={onClose}>
            ✕
          </button>
        </div>
        <div className="ba-menu-list">
          <button
            type="button"
            className={viewMode === "cards" ? "active" : ""}
            onClick={() => setViewMode("cards")}
          >
            <span>☰</span>
            <b>List view</b>
            <small>Compact curriculum cards</small>
          </button>
          <button
            type="button"
            className={viewMode === "table" ? "active" : ""}
            onClick={() => setViewMode("table")}
          >
            <span>☷</span>
            <b>Table view</b>
            <small>Dense laptop work view</small>
          </button>
          <button
            type="button"
            className={viewMode === "summary" ? "active" : ""}
            onClick={() => setViewMode("summary")}
          >
            <span>◔</span>
            <b>Analytics</b>
            <small>Structure, program and status summary</small>
          </button>
          <button type="button" onClick={onRefresh}>
            <span>↻</span>
            <b>Refresh</b>
            <small>Reload local branch records</small>
          </button>
        </div>
      </section>
    </div>
  );
}

function ActionSheet({
  item,
  openEdit,
  toggleActive,
  toggleLocked,
  remove,
  onClose,
}: {
  item: CurriculumView;
  openEdit: (item: CurriculumView) => void;
  toggleActive: (item: CurriculumView) => void;
  toggleLocked: (item: CurriculumView) => void;
  remove: (item: CurriculumView) => void;
  onClose: () => void;
}) {
  const row: any = item.row;
  return (
    <div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet small">
        <div className="ba-sheet-profile">
          <div>
            <h2>{row.name || "Curriculum"}</h2>
            <p>
              {item.academicStructureName} ·{" "}
              {item.active ? "Active" : "Inactive"}
            </p>
          </div>
          <button type="button" onClick={onClose}>
            ✕
          </button>
        </div>
        <div className="student-detail-strip">
          <span>
            <b>Pathways</b>
            {item.pathwayCount}
          </span>
          <span>
            <b>Subjects</b>
            {item.subjectCount}
          </span>
          <span>
            <b>Students</b>
            {item.studentCount}
          </span>
        </div>
        <div className="ba-menu-list">
          <button type="button" onClick={() => openEdit(item)}>
            <span>✎</span>
            <b>Edit curriculum</b>
            <small>Update academic structure, name, dates and settings</small>
          </button>
          <button type="button" onClick={() => toggleActive(item)}>
            <span>{item.active ? "⏸" : "✓"}</span>
            <b>{item.active ? "Deactivate" : "Activate"}</b>
            <small>Change active status</small>
          </button>
          <button type="button" onClick={() => toggleLocked(item)}>
            <span>{item.locked ? "🔓" : "🔒"}</span>
            <b>{item.locked ? "Unlock" : "Lock"}</b>
            <small>Protect or allow edits</small>
          </button>
          <button type="button" className="danger" onClick={() => remove(item)}>
            <span>⌫</span>
            <b>Delete</b>
            <small>Soft delete this curriculum locally</small>
          </button>
        </div>
      </section>
    </div>
  );
}

function CurriculumModal({
  form,
  saving,
  academicStructures,
  programs,
  organizations,
  updateForm,
  handleImageUpload,
  setModalOpen,
  save,
}: {
  form: FormState;
  saving: boolean;
  academicStructures: AcademicStructure[];
  programs: Program[];
  organizations: Organization[];
  updateForm: (patch: Partial<FormState>) => void;
  handleImageUpload: (
    field: "photo" | "bannerImage",
    file?: File,
  ) => void | Promise<void>;
  setModalOpen: (open: boolean) => void;
  save: (event?: React.FormEvent) => void;
}) {
  return (
    <BranchViewportPortal themeSourceClass=".curriculum-systems-root .ba-page"><div className="ba-modal-backdrop">
      <form className="ba-modal" onSubmit={save}>
        <div className="ba-modal-head">
          <div>
            <h2>{form.id ? "Edit Curriculum" : "Add Curriculum"}</h2>
            <p>
              Curriculums are branch academic frameworks. Manage pathways
              separately.
            </p>
          </div>
          <button type="button" onClick={() => setModalOpen(false)}>
            ✕
          </button>
        </div>
        <section className="ba-form-section">
          <h3>Curriculum</h3>
          <div className="ba-form">
            <label>
              <span>Name</span>
              <input
                value={form.name}
                onChange={(e) => updateForm({ name: e.target.value })}
                placeholder="e.g. GES JHS Curriculum"
              />
            </label>
            <label>
              <span>Code</span>
              <input
                value={form.code}
                onChange={(e) => updateForm({ code: e.target.value })}
                placeholder="e.g. GES-JHS"
              />
            </label>
            <label>
              <span>Version</span>
              <input
                value={form.curriculumVersion}
                onChange={(e) =>
                  updateForm({ curriculumVersion: e.target.value })
                }
                placeholder="e.g. 2026"
              />
            </label>
            <label>
              <span>Academic Structure</span>
              <select
                value={form.academicStructureId}
                onChange={(e) =>
                  updateForm({ academicStructureId: e.target.value })
                }
              >
                <option value="">Select structure</option>
                {academicStructures.map((row: any) => (
                  <option key={String(row.id)} value={String(row.id)}>
                    {row.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span>Program</span>
              <select
                value={form.programId}
                onChange={(e) => updateForm({ programId: e.target.value })}
              >
                <option value="">No program</option>
                {programs.map((row: any) => (
                  <option key={String(row.id)} value={String(row.id)}>
                    {row.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span>Organization</span>
              <select
                value={form.organizationId}
                onChange={(e) => updateForm({ organizationId: e.target.value })}
              >
                <option value="">No organization</option>
                {organizations.map((row: any) => (
                  <option key={String(row.id)} value={String(row.id)}>
                    {row.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span>Total Credits</span>
              <input
                type="number"
                value={form.totalCredits}
                onChange={(e) => updateForm({ totalCredits: e.target.value })}
              />
            </label>
            <label>
              <span>Duration Periods</span>
              <input
                type="number"
                value={form.durationPeriods}
                onChange={(e) =>
                  updateForm({ durationPeriods: e.target.value })
                }
              />
            </label>
            <label>
              <span>Effective From</span>
              <input
                type="date"
                value={form.effectiveFrom}
                onChange={(e) => updateForm({ effectiveFrom: e.target.value })}
              />
            </label>
            <label>
              <span>Effective To</span>
              <input
                type="date"
                value={form.effectiveTo}
                onChange={(e) => updateForm({ effectiveTo: e.target.value })}
              />
            </label>
            <label>
              <span>Status</span>
              <select
                value={form.active ? "active" : "inactive"}
                onChange={(e) =>
                  updateForm({ active: e.target.value === "active" })
                }
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </label>
            <label>
              <span>Lock</span>
              <select
                value={form.locked ? "locked" : "open"}
                onChange={(e) =>
                  updateForm({ locked: e.target.value === "locked" })
                }
              >
                <option value="open">Open</option>
                <option value="locked">Locked</option>
              </select>
            </label>
            <label>
              <span>Curriculum Photo</span>
              <input
                type="file"
                accept="image/*"
                onChange={(e) =>
                  handleImageUpload("photo", e.target.files?.[0])
                }
              />
              {form.photo && (
                <img
                  src={form.photo}
                  alt="Curriculum preview"
                  className="ba-media-preview"
                />
              )}
            </label>
            <label>
              <span>Banner Image</span>
              <input
                type="file"
                accept="image/*"
                onChange={(e) =>
                  handleImageUpload("bannerImage", e.target.files?.[0])
                }
              />
              {form.bannerImage && (
                <img
                  src={form.bannerImage}
                  alt="Curriculum banner preview"
                  className="ba-media-preview banner"
                />
              )}
            </label>
            <label className="wide">
              <span>Description</span>
              <textarea
                value={form.description}
                onChange={(e) => updateForm({ description: e.target.value })}
                placeholder="Describe this curriculum."
              />
            </label>
          </div>
        </section>
        <div className="ba-modal-actions">
          <button type="button" onClick={() => setModalOpen(false)}>
            Cancel
          </button>
          <button type="submit" disabled={saving}>
            {saving ? "Saving..." : form.id ? "Save Changes" : "Add Curriculum"}
          </button>
        </div>
      </form>
    </div></BranchViewportPortal>
  );
}

function groupedCounts(
  rows: CurriculumView[],
  keyFn: (item: CurriculumView) => string,
) {
  const map = new Map<string, number>();
  rows.forEach((row) => {
    const key = keyFn(row) || "Unknown";
    map.set(key, (map.get(key) || 0) + 1);
  });
  return Array.from(map.entries())
    .map(([label, value]) => ({ label, value }))
    .sort((a, b) => b.value - a.value || a.label.localeCompare(b.label));
}

function AnalysisCard({
  title,
  rows,
  total,
}: {
  title: string;
  rows: { label: string; value: number }[];
  total: number;
}) {
  return (
    <article className="ba-analysis">
      <span>{title}</span>
      <strong>{rows.reduce((sum, row) => sum + row.value, 0)}</strong>
      <div className="ba-analysis-list">
        {rows.slice(0, 8).map((row) => {
          const share = total ? Math.round((row.value / total) * 100) : 0;
          return (
            <section key={row.label}>
              <div>
                <b>{row.label}</b>
                <small>
                  {row.value} · {share}%
                </small>
              </div>
              <div className="ba-progress">
                <i style={{ width: `${Math.max(4, share)}%` }} />
              </div>
            </section>
          );
        })}
        {!rows.length && <p>No data available.</p>}
      </div>
    </article>
  );
}

const css = `
@keyframes spin { to { transform: rotate(360deg); } }
.ba-page{--ease:cubic-bezier(.2,.8,.2,1);min-height:100dvh;width:100%;max-width:100%;min-width:0;padding:calc(8px * var(--local-density-scale,1));padding-bottom:max(40px,env(safe-area-inset-bottom));background:radial-gradient(circle at top left,color-mix(in srgb,var(--ba-primary) 9%,transparent),transparent 30rem),var(--bg,#f7f8fb);color:var(--text,#111827);font-family:var(--font-family,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif);font-size:var(--font-size,14px);overflow-x:hidden}.ba-page *,.ba-page *::before,.ba-page *::after{box-sizing:border-box;min-width:0}.ba-page button,.ba-page input,.ba-page select,.ba-page textarea{font:inherit;max-width:100%}.ba-page button{-webkit-tap-highlight-color:transparent}.ba-page input,.ba-page select,.ba-page textarea{width:100%;min-height:44px;border:1px solid var(--input-border,var(--border,rgba(0,0,0,.10)));border-radius:16px;padding:0 12px;background:var(--input-bg,var(--surface,#fff));color:var(--input-text,var(--text,#111827));outline:none;font-weight:750}.ba-page textarea{min-height:92px;padding-top:10px;resize:vertical}.ba-page input:focus,.ba-page select:focus,.ba-page textarea:focus{border-color:color-mix(in srgb,var(--ba-primary) 52%,var(--border,rgba(0,0,0,.10)));box-shadow:0 0 0 4px color-mix(in srgb,var(--ba-primary) 12%,transparent)}.ba-state,.ba-search-card,.ba-table-card,.ba-analysis,.ba-empty,.ba-sheet,.ba-modal,.curriculum-row{background:var(--card-bg,var(--surface,#fff));border:1px solid var(--border,rgba(0,0,0,.10));box-shadow:0 12px 28px rgba(15,23,42,.045)}.ba-state{min-height:min(420px,calc(100dvh - 32px));width:min(520px,100%);margin:0 auto;display:grid;place-items:center;align-content:center;gap:10px;padding:22px;border-radius:28px;text-align:center}.ba-spinner{width:38px;height:38px;border-radius:999px;border:4px solid color-mix(in srgb,var(--ba-primary) 18%,transparent);border-top-color:var(--ba-primary);animation:spin .8s linear infinite}.ba-state h2{margin:0;font-size:22px;font-weight:1000;letter-spacing:-.04em}.ba-state p{max-width:34rem;margin:0;color:var(--muted,#64748b);font-size:13px;line-height:1.6}.ba-state-button{min-height:42px;border:0;border-radius:999px;padding:0 16px;background:var(--ba-primary);color:#fff;font-weight:950;cursor:pointer}.ba-toast{position:sticky;top:8px;z-index:40;display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;padding:12px 14px;border-radius:18px;font-size:13px;font-weight:850;box-shadow:0 18px 40px rgba(15,23,42,.12)}.ba-toast.success{background:rgba(34,197,94,.14);color:#166534}.ba-toast.error{background:rgba(239,68,68,.12);color:#991b1b}.ba-toast.info{background:rgba(59,130,246,.13);color:#1d4ed8}.ba-toast button{border:0;background:transparent;color:currentColor;font-weight:1000;cursor:pointer}.ba-search-card{display:grid;grid-template-columns:minmax(0,1fr) auto auto auto;gap:8px;align-items:center;margin-top:2px;padding:8px;border-radius:24px}.ba-search{min-width:0;display:grid;grid-template-columns:auto minmax(0,1fr);align-items:center;gap:8px;min-height:44px;padding:0 11px;border-radius:18px;background:color-mix(in srgb,var(--muted,#64748b) 7%,transparent)}.ba-search span{color:var(--muted,#64748b);font-size:17px;font-weight:1000}.ba-search input{min-height:42px;border:0;padding:0;border-radius:0;background:transparent;box-shadow:none;font-size:14px}.ba-icon-button,.ba-filter-button,.ba-add-inline{width:42px;height:42px;border:1px solid var(--border,rgba(0,0,0,.10));border-radius:999px;display:grid;place-items:center;background:var(--card-bg,var(--surface,#fff));color:var(--text,#111827);font-size:18px;font-weight:1000;cursor:pointer;box-shadow:0 10px 22px rgba(15,23,42,.045)}.ba-add-inline{flex:0 0 42px;border-color:var(--ba-primary);background:var(--ba-primary);color:#fff;font-size:25px;line-height:1;box-shadow:0 12px 28px color-mix(in srgb,var(--ba-primary) 22%,transparent)}.ba-slider-icon{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}.ba-filter-button{position:relative;background:color-mix(in srgb,var(--ba-primary) 8%,var(--card-bg,#fff));color:var(--ba-primary)}.ba-filter-button.active{background:var(--ba-primary);color:#fff;border-color:var(--ba-primary)}.ba-filter-button b{position:absolute;top:-4px;right:-4px;min-width:19px;height:19px;display:grid;place-items:center;border-radius:999px;background:#ef4444;color:#fff;font-size:10px;border:2px solid var(--card-bg,#fff)}.ba-filter-chips{display:flex;gap:7px;overflow-x:auto;padding:8px 1px 0;scrollbar-width:none}.ba-filter-chips::-webkit-scrollbar{display:none}.ba-filter-chips button{flex:0 0 auto;min-height:31px;border:0;border-radius:999px;padding:0 10px;background:color-mix(in srgb,var(--ba-primary) 11%,transparent);color:var(--ba-primary);font-size:11px;font-weight:950;white-space:nowrap;cursor:pointer}.ba-grid{display:grid;grid-template-columns:minmax(0,1fr);gap:7px;margin-top:10px}.curriculum-row{width:100%;display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:10px;padding:10px;border-radius:22px;text-align:left;cursor:pointer;transition:transform .16s var(--ease),box-shadow .16s var(--ease),border-color .16s var(--ease)}.curriculum-row:hover{transform:translateY(-1px);border-color:color-mix(in srgb,var(--ba-primary) 32%,var(--border,rgba(0,0,0,.10)));box-shadow:0 18px 34px rgba(15,23,42,.07)}.curriculum-icon{width:46px;height:46px;display:grid;place-items:center;border-radius:18px;background:color-mix(in srgb,var(--ba-primary) 13%,var(--card-bg,#fff));font-size:22px;flex:0 0 auto}.curriculum-main{display:grid;gap:2px}.curriculum-main strong,.curriculum-main small,.curriculum-main em{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.curriculum-main strong{color:var(--text,#111827);font-size:14px;font-weight:1000}.curriculum-main small{color:var(--muted,#64748b);font-size:12px;font-weight:850}.curriculum-main em{color:var(--muted,#64748b);font-size:11px;font-style:normal;font-weight:750}.curriculum-side{display:flex;align-items:center;gap:9px;color:var(--muted,#64748b)}.curriculum-side i{font-style:normal;font-weight:1000}.status-dot-mini{width:10px;height:10px;border-radius:999px;display:inline-block;box-shadow:0 0 0 4px color-mix(in srgb,currentColor 12%,transparent)}.status-dot-mini.green{background:#22c55e;color:#22c55e}.status-dot-mini.gray{background:#94a3b8;color:#94a3b8}.status-dot-mini.orange{background:#f59e0b;color:#f59e0b}.ba-chip{max-width:100%;display:inline-flex;align-items:center;min-height:25px;padding:4px 9px;border-radius:999px;font-size:11px;font-weight:950;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ba-chip.green{background:rgba(34,197,94,.12);color:#16a34a}.ba-chip.red{background:rgba(239,68,68,.12);color:#dc2626}.ba-chip.blue{background:rgba(59,130,246,.12);color:#2563eb}.ba-chip.gray{background:rgba(107,114,128,.12);color:var(--muted,#64748b)}.ba-chip.orange{background:rgba(245,158,11,.14);color:#b45309}.ba-chip.purple{background:rgba(147,51,234,.12);color:#7e22ce}.ba-table-card{margin-top:10px;padding:0;border-radius:24px;overflow:hidden}.ba-table-scroll{width:100%;max-width:100%;overflow-x:auto;border-radius:18px;border:1px solid var(--border,rgba(0,0,0,.10))}.ba-table-scroll table{width:100%;min-width:1240px;border-collapse:collapse;background:var(--card-bg,var(--surface,#fff))}.ba-table-scroll th,.ba-table-scroll td{padding:10px;border-bottom:1px solid var(--border,rgba(0,0,0,.08));vertical-align:top;text-align:left;font-size:13px;color:var(--text,#111827)}.ba-table-scroll th{background:color-mix(in srgb,var(--ba-primary) 6%,var(--card-bg,var(--surface,#fff)));color:var(--table-header-text,var(--muted,#64748b));font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.07em;white-space:nowrap}.ba-table-scroll td strong,.ba-table-scroll td span{display:block}.ba-table-scroll td strong{font-weight:1000}.ba-table-scroll td span{margin-top:3px;color:var(--muted,#64748b);font-size:11px}.ba-table-actions{display:flex;align-items:center;gap:7px;flex-wrap:nowrap;white-space:nowrap}.ba-table-actions button{flex:0 0 auto;min-height:34px;border:0;border-radius:999px;padding:0 10px;background:color-mix(in srgb,var(--ba-primary) 10%,var(--card-bg,#fff));color:var(--ba-primary);font-size:11px;font-weight:950;cursor:pointer}.ba-table-actions button:first-child{background:var(--ba-primary);color:#fff}.ba-table-actions .ba-delete{color:var(--muted,#64748b);background:color-mix(in srgb,var(--muted,#64748b) 8%,var(--card-bg,#fff));border:1px solid color-mix(in srgb,var(--muted,#64748b) 24%,var(--border,rgba(0,0,0,.10)))}.ba-empty-table{padding:22px;text-align:center;color:var(--muted,#64748b);font-weight:850}.ba-analysis-grid{display:grid;grid-template-columns:minmax(0,1fr);gap:10px;margin-top:10px}.ba-analysis{padding:14px;border-radius:24px}.ba-analysis span{color:var(--muted,#64748b);font-size:11px;font-weight:950;text-transform:uppercase;letter-spacing:.08em}.ba-analysis strong{display:block;margin-top:8px;font-size:clamp(22px,7vw,30px);line-height:1;font-weight:1000;letter-spacing:-.06em;overflow-wrap:anywhere}.ba-analysis p{margin:8px 0 0;color:var(--muted,#64748b);font-size:12px;line-height:1.5}.ba-analysis-list{display:grid;gap:10px;margin-top:12px}.ba-analysis-list section{display:grid;gap:6px;padding:10px;border-radius:16px;background:color-mix(in srgb,var(--muted,#64748b) 8%,transparent)}.ba-analysis-list section>div:first-child{display:flex;justify-content:space-between;gap:10px}.ba-analysis-list b,.ba-analysis-list small{font-size:12px}.ba-analysis-list small{color:var(--muted,#64748b);font-weight:850}.ba-progress{height:8px;border-radius:999px;background:color-mix(in srgb,var(--muted,#64748b) 18%,transparent);overflow:hidden}.ba-progress i{display:block;height:100%;border-radius:inherit;background:var(--ba-primary)}.ba-empty{display:grid;place-items:center;align-content:center;gap:8px;min-height:220px;text-align:center;border-style:dashed;border-radius:24px;padding:13px}.ba-empty-icon{width:56px;height:56px;display:grid;place-items:center;border-radius:22px;background:color-mix(in srgb,var(--ba-primary) 12%,var(--card-bg,#fff));font-size:28px}.ba-empty h3{margin:0;font-size:18px;font-weight:1000}.ba-empty p{margin:0;color:var(--muted,#64748b);font-size:13px;line-height:1.6}.ba-sheet-backdrop,.ba-modal-backdrop{position:fixed;inset:0;z-index:80;display:grid;place-items:end center;padding:10px;background:rgba(15,23,42,.58);backdrop-filter:blur(12px)}.ba-sheet,.ba-modal{width:min(760px,100%);max-height:min(92dvh,900px);overflow-y:auto;border-radius:28px;padding:14px;background:var(--card-bg,var(--surface,#fff));color:var(--text,#111827);border:1px solid var(--border,rgba(0,0,0,.10));box-shadow:0 30px 90px rgba(15,23,42,.35)}.ba-sheet.small{width:min(460px,100%)}.ba-sheet-head,.ba-modal-head,.ba-sheet-profile{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding:4px 2px 14px}.ba-sheet-head h2,.ba-modal-head h2,.ba-sheet-profile h2{margin:0;font-size:20px;font-weight:1000;letter-spacing:-.05em}.ba-sheet-head p,.ba-modal-head p,.ba-sheet-profile p{margin:5px 0 0;color:var(--muted,#64748b);font-size:12px;line-height:1.5}.ba-sheet-head button,.ba-modal-head button,.ba-sheet-profile button{width:38px;height:38px;border:0;border-radius:999px;background:color-mix(in srgb,var(--muted,#64748b) 8%,var(--card-bg,#fff));color:var(--text,#111827);font-weight:1000;cursor:pointer}.ba-form{display:grid;grid-template-columns:minmax(0,1fr);gap:10px}.ba-form.compact{margin-top:4px}.ba-form-section{margin-top:10px}.ba-form-section h3{margin:0 0 10px;font-size:13px;font-weight:1000;color:var(--muted,#64748b);text-transform:uppercase;letter-spacing:.08em}.ba-form label{display:grid;gap:6px}.ba-form label span{color:var(--muted,#64748b);font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:.06em}.ba-form .wide{grid-column:1/-1}.ba-sheet-actions,.ba-modal-actions{display:flex;justify-content:flex-end;gap:8px;flex-wrap:wrap;margin-top:14px}.ba-sheet-actions button,.ba-modal-actions button{min-height:40px;border:0;border-radius:999px;padding:0 14px;background:color-mix(in srgb,var(--muted,#64748b) 8%,var(--card-bg,#fff));color:var(--text,#111827);font-size:12px;font-weight:950;cursor:pointer}.ba-sheet-actions button.primary,.ba-modal-actions button:last-child{background:var(--ba-primary);color:#fff}.ba-menu-list{display:grid;gap:8px}.ba-menu-list button{width:100%;display:grid;grid-template-columns:auto minmax(0,1fr);column-gap:10px;row-gap:2px;align-items:center;padding:11px;border:1px solid var(--border,rgba(0,0,0,.10));border-radius:18px;background:var(--card-bg,var(--surface,#fff));color:var(--text,#111827);text-align:left;cursor:pointer}.ba-menu-list button span{grid-row:1/3;width:34px;height:34px;display:grid;place-items:center;border-radius:14px;background:color-mix(in srgb,var(--ba-primary) 10%,transparent);color:var(--ba-primary);font-weight:1000}.ba-menu-list button b{font-size:13px;font-weight:1000}.ba-menu-list button small{color:var(--muted,#64748b);font-size:11px;font-weight:750}.ba-menu-list button.active{background:var(--ba-primary);border-color:var(--ba-primary);color:#fff;box-shadow:0 12px 26px color-mix(in srgb,var(--ba-primary) 22%,transparent)}.ba-menu-list button.active span{background:rgba(255,255,255,.18);color:#fff}.ba-menu-list button.active small{color:rgba(255,255,255,.82)}.ba-menu-list button.danger span{background:color-mix(in srgb,var(--muted,#64748b) 10%,transparent);color:var(--muted,#64748b)}.student-detail-strip{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;margin-bottom:10px}.student-detail-strip span{display:grid;gap:2px;padding:9px;border-radius:16px;background:color-mix(in srgb,var(--muted,#64748b) 8%,transparent);font-size:12px;font-weight:850}.student-detail-strip b{color:var(--muted,#64748b);font-size:10px;text-transform:uppercase;letter-spacing:.06em}.ba-media-preview{width:72px;height:72px;object-fit:cover;border-radius:18px;border:1px solid var(--border,rgba(0,0,0,.10));margin-top:6px}.ba-media-preview.banner{width:100%;height:120px}.ba-modal{width:min(960px,100%)}@media (min-width:680px){.ba-page{padding:12px}.ba-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.ba-analysis-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.ba-form{grid-template-columns:repeat(2,minmax(0,1fr))}.ba-sheet-backdrop,.ba-modal-backdrop{place-items:center;padding:18px}.ba-sheet,.ba-modal{padding:18px}}@media (min-width:1040px){.ba-page{padding:16px}.ba-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.ba-analysis-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}@media (min-width:1400px){.ba-grid{grid-template-columns:repeat(4,minmax(0,1fr))}}@media (max-width:520px){.ba-page{padding:6px}.ba-search-card{gap:6px;padding:7px;border-radius:22px}.ba-icon-button,.ba-filter-button,.ba-add-inline{width:40px;height:40px}.ba-grid{gap:7px}.ba-analysis,.ba-table-card,.ba-empty,.ba-modal,.ba-sheet{border-radius:20px;padding:11px}.student-detail-strip{grid-template-columns:1fr}.ba-modal-actions,.ba-sheet-actions{display:grid;grid-template-columns:1fr}.ba-modal-actions button,.ba-sheet-actions button{width:100%}}
@media (min-width:980px){
  .ba-modal-backdrop,
  .ba-sheet-backdrop{
    top:var(--eds-shell-top-offset,0px);
    right:0;
    bottom:0;
    left:var(--portal-content-left,0px);
    width:auto;
    max-width:calc(100vw - var(--portal-content-left,0px));
    min-width:0;
    overflow-x:hidden;
  }
  .ba-modal,
  .ba-sheet{
    min-width:0;
    max-width:calc(100vw - var(--portal-content-left,0px) - 20px);
  }
}



/* V36 SETUP: Students visual standard; source CRUD, relationships and offline sync remain unchanged. */
.curriculum-systems-root .ba-page {
  width:100%;min-width:0;max-width:none;min-height:0;margin:0;
  padding:4px 4px max(20px,env(safe-area-inset-bottom));
  background:var(--bg,var(--background,#f2f4f7));overflow-x:clip;
}
.curriculum-systems-root .ba-page .ba-search-card,.curriculum-systems-root .ba-page .ba-filter-chips,.curriculum-systems-root .ba-page .ba-hero {display:none!important;}
.curriculum-systems-root .ba-page .ba-list{width:100%;min-width:0;max-width:none;margin:2px 0 0;gap:9px;align-items:stretch;}
.curriculum-systems-root .ba-page .ba-list > .student-row,.curriculum-systems-root .ba-page .ba-list > .curriculum-row,
.curriculum-systems-root .ba-page .ba-list > .pathway-row,.curriculum-systems-root .ba-page .ba-list > .organization-row{width:100%;min-width:0;margin:0;padding:9px 10px;}
.curriculum-systems-root .ba-page .student-row,.curriculum-systems-root .ba-page .organization-row,.curriculum-systems-root .ba-page .curriculum-row,
.curriculum-systems-root .ba-page .pathway-row,.curriculum-systems-root .ba-page .ba-card,.curriculum-systems-root .ba-page .ba-table-card,.curriculum-systems-root .ba-page .ba-analysis{
 background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 93%,var(--text,#182235) 7%);
 border:1px solid color-mix(in srgb,var(--border,#d4dae3) 85%,var(--text,#182235) 15%);
 border-radius:13px;box-shadow:none;transform:none;
}
.curriculum-systems-root .ba-page .student-row:hover,.curriculum-systems-root .ba-page .curriculum-row:hover,.curriculum-systems-root .ba-page .pathway-row:hover,
.curriculum-systems-root .ba-page .organization-row:hover{transform:none;box-shadow:none;}
.curriculum-systems-root .ba-page .ba-avatar{box-shadow:none;border-radius:12px;}
.curriculum-systems-root .ba-page .ba-table-card{display:block;width:100%;max-width:none;min-width:0;margin:2px 0 0;padding:4px;overflow:visible;}
.curriculum-systems-root .ba-page .ba-table-scroll{width:100%;max-width:100%;min-width:0;overflow-x:auto;overflow-y:auto;
 overscroll-behavior-x:contain;-webkit-overflow-scrolling:touch;border-radius:10px;}
.curriculum-systems-root .ba-page .ba-table-scroll table{width:100%;margin:0;background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 95%,var(--text,#182235) 5%);}
.curriculum-systems-root .ba-page .ba-table-scroll thead th{position:sticky;top:0;z-index:2;background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 85%,var(--text,#182235) 15%);}
.curriculum-systems-root .ba-page .ba-table-scroll tbody tr:nth-child(even){background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 89%,var(--text,#182235) 11%);}
.curriculum-systems-root .ba-page .ba-table-scroll td{background:transparent;}
.curriculum-systems-root .ba-page .ba-table-scroll th,.curriculum-systems-root .ba-page .ba-table-scroll td{padding:9px 10px;}
.curriculum-systems-root .ba-page .ba-analysis-grid{width:100%;max-width:none;min-width:0;margin:2px 0 0;gap:9px;}
.ba-record-search-in-filter{display:grid;gap:6px;margin:0 0 10px;}
.ba-record-search-in-filter span{font-size:11px;font-weight:750;color:var(--muted,#64748b);}
.ba-record-search-in-filter input{min-height:40px;width:100%;border:1px solid var(--border,#d4dae3);
 border-radius:9px;padding:0 11px;background:var(--input-bg,var(--surface,#fff));color:var(--text,#182235);}
.ba-modal-head button,.ba-sheet-head button{opacity:1;visibility:visible;flex:0 0 auto;color:var(--text,#182235);}
@media(min-width:680px) and (max-width:1023px){.curriculum-systems-root .ba-page .ba-list{grid-template-columns:repeat(2,minmax(0,1fr));}}
@media(min-width:1024px){.curriculum-systems-root .ba-page .ba-list{grid-template-columns:repeat(4,minmax(0,1fr));}}
@media(max-width:679px){.curriculum-systems-root .ba-page .ba-list{grid-template-columns:minmax(0,1fr);}}
@media(max-width:639px){.curriculum-systems-root .ba-page {padding:2px 2px 14px;} .curriculum-systems-root .ba-page .ba-list{gap:7px;}}
@media(prefers-reduced-motion:reduce){.curriculum-systems-root .ba-page .student-row,.curriculum-systems-root .ba-page .curriculum-row{transition:none;}}

`;
  return CurriculumsWorkspace;
})();

const CurriculumPathwaysModule = (() => {
type ViewMode = "cards" | "table" | "summary";
type ToastTone = "success" | "error" | "info";
type AnyRow = Record<string, any>;

type TenantRow = {
  accountId?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  isDeleted?: boolean;
  active?: boolean;
  status?: string;
};

type PathwayView = {
  id: string;
  row: CurriculumPathway;
  name: string;
  code: string;
  description: string;
  curriculumId: string;
  curriculumName: string;
  subjectCount: number;
  studentCount: number;
  active: boolean;
};

type FormState = {
  id?: string;
  curriculumId: string;
  name: string;
  code: string;
  description: string;
  active: boolean;
};

const emptyForm: FormState = {
  curriculumId: "",
  name: "",
  code: "",
  description: "",
  active: true,
};

const idOf = (value: any): string => {
  if (value === undefined || value === null) return "";
  return String(value).trim();
};

const OPEN_WORKSPACE_KEY = "eleeveon_open_workspace";

type OpenWorkspaceSession = {
  membership?: Record<string, any> | null;
  membershipId?: string | null;
  role?: string | null;
  schoolId?: string | null;
  branchId?: string | null;
  teacherId?: string | null;
  studentId?: string | null;
  parentId?: string | null;
  memberName?: string | null;
  fullName?: string | null;
  userName?: string | null;
  openedAt?: number;
};

function safeStorageRead(key: string) {
  if (typeof window === "undefined") return null;

  try {
    return (
      window.localStorage.getItem(key) || window.sessionStorage.getItem(key)
    );
  } catch {
    return null;
  }
}

function safeJsonRead<T>(key: string): T | null {
  const raw = safeStorageRead(key);
  if (!raw) return null;

  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

function readOpenWorkspaceSession() {
  return safeJsonRead<OpenWorkspaceSession>(OPEN_WORKSPACE_KEY);
}

function readStoredActiveMembership() {
  return safeJsonRead<Record<string, any>>("activeMembership");
}

function firstLocalId(...values: unknown[]): string {
  for (const value of values) {
    const parsed = idOf(value);
    if (parsed) return parsed;
  }

  return "";
}

function selectedWorkspaceSchoolId(args: {
  openWorkspace?: OpenWorkspaceSession | null;
  activeMembership?: Record<string, any> | null;
  activeSchoolId?: unknown;
  activeSchool?: Record<string, any> | null;
  settings?: Record<string, any> | null;
}) {
  const storedMembership = readStoredActiveMembership();
  const membership =
    args.openWorkspace?.membership ||
    args.activeMembership ||
    storedMembership ||
    null;

  return firstLocalId(
    args.openWorkspace?.schoolId,
    membership?.schoolId,
    membership?.school?.id,
    args.activeSchoolId,
    args.activeSchool?.id,
    args.settings?.schoolId,
    safeStorageRead("activeSchoolId"),
  );
}

function selectedWorkspaceBranchId(args: {
  openWorkspace?: OpenWorkspaceSession | null;
  activeMembership?: Record<string, any> | null;
  activeBranchId?: unknown;
  activeBranch?: Record<string, any> | null;
  settings?: Record<string, any> | null;
}) {
  const storedMembership = readStoredActiveMembership();
  const membership =
    args.openWorkspace?.membership ||
    args.activeMembership ||
    storedMembership ||
    null;

  return firstLocalId(
    args.openWorkspace?.branchId,
    membership?.branchId,
    membership?.schoolBranchId,
    membership?.branch?.id,
    args.activeBranchId,
    args.activeBranch?.id,
    args.settings?.branchId,
    safeStorageRead("activeBranchId"),
  );
}

const sameId = (a: any, b: any) => String(a ?? "") === String(b ?? "");
const safeLower = (value: any) =>
  String(value || "")
    .toLowerCase()
    .trim();
const tableSafe = (name: string) => (db as any)[name];

const isActiveRow = (row: any) => {
  const status = safeLower(row?.status);
  if (row?.isDeleted) return false;
  if (row?.active === false) return false;
  if (["inactive", "deleted", "archived", "suspended"].includes(status))
    return false;
  return true;
};

const timeText = (value?: string | number | null) => {
  if (!value) return "Not set";
  const time = typeof value === "number" ? value : new Date(value).getTime();
  if (!Number.isFinite(time)) return "Not set";

  try {
    return new Intl.DateTimeFormat("en-GH", {
      month: "short",
      day: "2-digit",
      year: "numeric",
    }).format(new Date(time));
  } catch {
    return "Not set";
  }
};

function Chip({
  children,
  tone = "gray",
}: {
  children: React.ReactNode;
  tone?: "green" | "red" | "blue" | "gray" | "orange" | "purple";
}) {
  return <span className={`ba-chip ${tone}`}>{children}</span>;
}

function Empty({
  icon,
  title,
  text,
}: {
  icon: string;
  title: string;
  text: string;
}) {
  return (
    <section className="ba-empty">
      <div className="ba-empty-icon">{icon}</div>
      <h3>{title}</h3>
      <p>{text}</p>
    </section>
  );
}

function MiniStat({ label, value }: { label: string; value: string | number }) {
  return (
    <span>
      <b>{value}</b>
      {label}
    </span>
  );
}

function CurriculumPathwaysWorkspace() {
  const dataRevision = useDataRevision();

  const router = useRouter();
  const { accountId, authenticated, loading: accountLoading } = useAccount();
  const { settings, loading: settingsLoading } = useSettings();
  const {
    activeSchool,
    activeSchoolId,
    activeBranch,
    activeBranchId,
    loading: contextLoading,
  } = useActiveBranch();
  const { activeMembership } = useActiveMembership();

  const openWorkspace = useMemo(() => readOpenWorkspaceSession(), []);

  const schoolId = selectedWorkspaceSchoolId({
    openWorkspace,
    activeMembership: activeMembership as any,
    activeSchoolId,
    activeSchool: activeSchool as any,
    settings: settings as any,
  });

  const branchId = selectedWorkspaceBranchId({
    openWorkspace,
    activeMembership: activeMembership as any,
    activeBranchId,
    activeBranch: activeBranch as any,
    settings: settings as any,
  });

  const primary = settings?.primaryColor || "var(--primary-color, #2563eb)";

  const { loading, setLoading } = useBackgroundLoader();
  const [saving, setSaving] = useState(false);
  const [pathways, setPathways] = useState<CurriculumPathway[]>([]);
  const [curriculums, setCurriculums] = useState<Curriculum[]>([]);
  const [curriculumSubjects, setCurriculumSubjects] = useState<
    CurriculumSubject[]
  >([]);
  const [studentCurriculums, setStudentCurriculums] = useState<
    StudentCurriculum[]
  >([]);

  const [viewMode, setViewMode] = useState<ViewMode>("cards");
  useEffect(() => { if (typeof window !== "undefined") setViewMode(window.matchMedia("(min-width: 900px)").matches ? "table" : "cards"); }, []);
  const [search, setSearch] = useState("");
  const [curriculumFilter, setCurriculumFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("active");

  const [filterOpen, setFilterOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<PathwayView | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [toast, setToast] = useState<{
    tone: ToastTone;
    message: string;
  } | null>(null);

  useEffect(() => {
    if (accountLoading || contextLoading) return;
    if (!authenticated || !accountId) router.replace("/login");
    // Missing branch workspace is handled locally so the selected-role flow is not broken.
  }, [
    accountLoading,
    contextLoading,
    authenticated,
    accountId,
    schoolId,
    branchId,
    router,
  ]);

  const sameTenant = (row: TenantRow) =>
    (!row.accountId || row.accountId === accountId) &&
    (!row.schoolId || sameId(row.schoolId, schoolId)) &&
    (!row.branchId || sameId(row.branchId, branchId)) &&
    !row.isDeleted;

  const showToast = (tone: ToastTone, message: string) => {
    setToast({ tone, message });
    window.setTimeout(
      () =>
        setToast((current) => (current?.message === message ? null : current)),
      4200,
    );
  };

  const clearData = () => {
    setPathways([]);
    setCurriculums([]);
    setCurriculumSubjects([]);
    setStudentCurriculums([]);
  };

  const load = async () => {
    if (!authenticated || !accountId || !schoolId || !branchId) {
      clearData();
      setLoading(false);
      return;
    }

    try {
      setLoading(true);

      const [pathwayRows, curriculumRows, subjectRows, studentRows] =
        await Promise.all([
          tableSafe("curriculumPathways")?.toArray?.() || [],
          listActiveLocal("curriculums", {
            accountId,
            schoolId: schoolId,
            branchId: branchId,
          } as any),
          tableSafe("curriculumSubjects")?.toArray?.() || [],
          tableSafe("studentCurriculums")?.toArray?.() || [],
        ]);

      setPathways(
        (pathwayRows as CurriculumPathway[])
          .filter((row) => sameTenant(row as TenantRow))
          .sort((a: any, b: any) =>
            String(a.name || "").localeCompare(String(b.name || "")),
          ),
      );
      setCurriculums(
        (curriculumRows as Curriculum[]).sort((a: any, b: any) =>
          String(a.name || "").localeCompare(String(b.name || "")),
        ),
      );
      setCurriculumSubjects(
        (subjectRows as CurriculumSubject[]).filter((row) =>
          sameTenant(row as TenantRow),
        ),
      );
      setStudentCurriculums(
        (studentRows as StudentCurriculum[]).filter((row) =>
          sameTenant(row as TenantRow),
        ),
      );
    } catch (error) {
      console.error(error);
      clearData();
      showToast("error", "Failed to load curriculum pathways.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (accountLoading || settingsLoading || contextLoading) return;
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    authenticated,
    accountId,
    schoolId,
    branchId,
    accountLoading,
    settingsLoading,
    contextLoading,
    dataRevision,
  ]);

  const curriculumMap = useMemo(() => {
    const map = new Map<string, Curriculum>();
    curriculums.forEach((row: any) => map.set(idOf(row.id), row));
    return map;
  }, [curriculums]);

  const usage = useMemo(() => {
    const subjectMap = new Map<string, number>();
    const studentMap = new Map<string, number>();

    curriculumSubjects.forEach((row: any) => {
      const pathwayId = idOf(row.pathwayId);
      if (pathwayId)
        subjectMap.set(pathwayId, (subjectMap.get(pathwayId) || 0) + 1);
    });

    studentCurriculums.forEach((row: any) => {
      const pathwayId = idOf(row.pathwayId);
      if (pathwayId)
        studentMap.set(pathwayId, (studentMap.get(pathwayId) || 0) + 1);
    });

    return { subjectMap, studentMap };
  }, [curriculumSubjects, studentCurriculums]);

  const viewRows = useMemo<PathwayView[]>(() => {
    return pathways.map((row: any) => {
      const id = idOf(row.id);
      const curriculumId = idOf(row.curriculumId);
      const curriculum: any = curriculumMap.get(curriculumId);

      return {
        id,
        row,
        name: row.name || row.title || `Pathway ${id || ""}`,
        code: row.code || row.shortCode || "",
        description: row.description || row.remark || "",
        curriculumId,
        curriculumName:
          curriculum?.name || curriculum?.title || "Unknown curriculum",
        subjectCount: usage.subjectMap.get(id) || 0,
        studentCount: usage.studentMap.get(id) || 0,
        active: isActiveRow(row),
      };
    });
  }, [curriculumMap, pathways, usage]);

  const filteredRows = useMemo(() => {
    const term = search.trim().toLowerCase();

    return viewRows
      .filter((row) => {
        const haystack =
          `${row.name} ${row.code} ${row.description} ${row.curriculumName}`.toLowerCase();
        const searchOk = !term || haystack.includes(term);
        const curriculumOk =
          curriculumFilter === "all" ||
          sameId(row.curriculumId, curriculumFilter);
        const statusOk =
          statusFilter === "all" ||
          (statusFilter === "active" ? row.active : !row.active);
        return searchOk && curriculumOk && statusOk;
      })
      .sort(
        (a, b) =>
          a.curriculumName.localeCompare(b.curriculumName) ||
          a.name.localeCompare(b.name),
      );
  }, [curriculumFilter, search, statusFilter, viewRows]);

  const summary = useMemo(
    () => ({
      total: viewRows.length,
      active: viewRows.filter((row) => row.active).length,
      inactive: viewRows.filter((row) => !row.active).length,
      curriculums: curriculums.length,
      subjectLinks: curriculumSubjects.filter((row: any) => idOf(row.pathwayId))
        .length,
      studentLinks: studentCurriculums.filter((row: any) => idOf(row.pathwayId))
        .length,
      showing: filteredRows.length,
    }),
    [
      curriculumSubjects,
      curriculums.length,
      filteredRows.length,
      studentCurriculums,
      viewRows,
    ],
  );

  const activeFilterCount = useMemo(() => {
    return (
      [curriculumFilter, statusFilter].filter(
        (value) => value !== "all" && value !== "active",
      ).length + (statusFilter !== "active" ? 1 : 0)
    );
  }, [curriculumFilter, statusFilter]);

  const countsByCurriculum = useMemo(
    () => groupedCounts(viewRows, (row) => row.curriculumName),
    [viewRows],
  );
  const countsByStatus = useMemo(
    () =>
      groupedCounts(viewRows, (row) => (row.active ? "Active" : "Inactive")),
    [viewRows],
  );
  const countsBySubjects = useMemo(
    () =>
      viewRows
        .map((row) => ({ label: row.name, value: row.subjectCount }))
        .filter((row) => row.value > 0)
        .sort((a, b) => b.value - a.value),
    [viewRows],
  );
  const countsByStudents = useMemo(
    () =>
      viewRows
        .map((row) => ({ label: row.name, value: row.studentCount }))
        .filter((row) => row.value > 0)
        .sort((a, b) => b.value - a.value),
    [viewRows],
  );

  const updateForm = (patch: Partial<FormState>) =>
    setForm((current) => ({ ...current, ...patch }));

  const requireTenant = () => {
    if (!authenticated || !accountId || !schoolId || !branchId) {
      showToast("error", "Sign in and select a school branch first.");
      return false;
    }
    return true;
  };

  const openCreate = () => {
    if (!requireTenant()) return;
    setSelectedItem(null);
    setForm({
      ...emptyForm,
      curriculumId: curriculumFilter !== "all" ? String(curriculumFilter) : "",
    });
    setModalOpen(true);
  };

  const openEdit = (item: PathwayView) => {
    setSelectedItem(null);
    setForm({
      id: item.id,
      curriculumId: item.curriculumId ? String(item.curriculumId) : "",
      name: item.name,
      code: item.code,
      description: item.description,
      active: item.active,
    });
    setModalOpen(true);
  };

  const clearFilters = () => {
    setCurriculumFilter("all");
    setStatusFilter("active");
  };

  const validate = () => {
    if (!authenticated || !accountId) return "Sign in first.";
    if (!schoolId || !branchId) return "Select a school branch first.";
    if (!form.curriculumId) return "Select a curriculum.";
    if (!form.name.trim()) return "Enter pathway name.";

    const duplicate = pathways.find((row: any) => {
      if (form.id && sameId(row.id, form.id)) return false;
      if (idOf(row.curriculumId) !== idOf(form.curriculumId)) return false;
      if (row.isDeleted) return false;
      const sameName = safeLower(row.name) === safeLower(form.name);
      const sameCode =
        !!form.code.trim() && safeLower(row.code) === safeLower(form.code);
      return sameName || sameCode;
    });

    if (duplicate)
      return "A pathway with this name or code already exists under the selected curriculum.";
    return "";
  };

  const save = async (event?: React.FormEvent) => {
    event?.preventDefault();

    const error = validate();
    if (error) {
      showToast("error", error);
      return;
    }

    if (!authenticated || !accountId || !schoolId || !branchId) return;

    try {
      setSaving(true);

      const existing = form.id
        ? pathways.find((row: any) => sameId(row.id, form.id))
        : undefined;
      const payload: Partial<CurriculumPathway> = {
        accountId,
        schoolId: schoolId,
        branchId: branchId,
        curriculumId: idOf(form.curriculumId),
        name: form.name.trim(),
        code: form.code.trim() || undefined,
        description: form.description.trim() || undefined,
        active: form.active,
        isDeleted: false,
      } as Partial<CurriculumPathway>;

      if (form.id && existing)
        await updateLocal("curriculumPathways", String(form.id), payload);
      else
        await createLocal("curriculumPathways", payload as CurriculumPathway);

      setModalOpen(false);
      showToast("success", "Curriculum pathway saved.");
      await load();
    } catch (error) {
      console.error(error);
      showToast("error", "Could not save curriculum pathway.");
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (item: PathwayView) => {
    if (!item.id) return;

    await updateLocal("curriculumPathways", String(item.id), {
      active: !item.active,
      isDeleted: false,
    } as Partial<CurriculumPathway>);

    setSelectedItem(null);
    showToast(
      "success",
      item.active ? "Pathway deactivated." : "Pathway activated.",
    );
    await load();
  };

  const remove = async (item: PathwayView) => {
    const totalUsage = item.subjectCount + item.studentCount;
    const ok = window.confirm(
      totalUsage
        ? `"${item.name}" is linked to ${item.subjectCount} subject record(s) and ${item.studentCount} student curriculum record(s). Delete anyway?`
        : `Delete "${item.name}"?`,
    );

    if (!ok) return;

    await softDeleteLocal("curriculumPathways", String(item.id));
    setSelectedItem(null);
    showToast("success", "Pathway deleted.");
    await load();
  };

  // Shared Setup actions for the currently mounted Curriculums/Pathways editor.
  useRegisterBranchWorkspaceToolbar("setupWorkspace", {
    add: () => openCreate(), search: setSearch,
    filter: () => setFilterOpen(true), more: () => setMoreOpen(true),
  });
  useRegisterBranchWorkspaceToolbar("curriculumSystems", {
    add: () => openCreate(), search: setSearch,
    filter: () => setFilterOpen(true), more: () => setMoreOpen(true),
  });

  if (accountLoading || settingsLoading || contextLoading || loading) {
    return (
      <State
        primary={primary}
        title="Opening Curriculum Pathways..."
        text="Checking curriculums, pathways, subject links and student links."
      />
    );
  }

  if (!authenticated || !accountId) {
    return (
      <State
        primary={primary}
        title="Redirecting to login..."
        text="You must sign in before managing curriculum pathways."
      />
    );
  }

  if (!schoolId || !branchId) {
    return (
      <main
        className="ba-page"
        style={{ "--ba-primary": primary } as React.CSSProperties}
      >
        <style>{css}</style>
        <section className="ba-state">
          <h2>Select a branch first</h2>
          <p>Curriculum pathways belong to one active school branch.</p>
          <button
            type="button"
            className="ba-state-button"
            onClick={() => router.push("/account")}
          >
            Go to Account Setup
          </button>
        </section>
      </main>
    );
  }

  return (
    <main
      className="ba-page"
      style={{ "--ba-primary": primary } as React.CSSProperties}
    >
      <style>{css}</style>

      {toast && (
        <section className={`ba-toast ${toast.tone}`}>
          {toast.message}
          <button
            type="button"
            onClick={() => setToast(null)}
            aria-label="Close notification"
          >
            ✕
          </button>
        </section>
      )}

      

      {(curriculumFilter !== "all" || statusFilter !== "active") && (
        <></>
      )}

      {viewMode === "summary" && (
        <section className="ba-analysis-grid">
          <AnalysisCard
            title="Pathways by Curriculum"
            rows={countsByCurriculum}
            total={summary.total}
          />
          <AnalysisCard
            title="Pathways by Status"
            rows={countsByStatus}
            total={summary.total}
          />
          <AnalysisCard
            title="Subject Links by Pathway"
            rows={countsBySubjects}
            total={Math.max(summary.subjectLinks, 1)}
          />
          <AnalysisCard
            title="Student Links by Pathway"
            rows={countsByStudents}
            total={Math.max(summary.studentLinks, 1)}
          />
          <article className="ba-analysis ba-current-filter">
            <span>Current Filter</span>
            <strong>{summary.showing}</strong>
            <p>
              Pathway record(s) currently match your search and filter
              conditions.
            </p>
          </article>
        </section>
      )}

      {viewMode === "table" && (
        <TableView
          rows={filteredRows}
          openEdit={openEdit}
          toggleActive={toggleActive}
          remove={remove}
        />
      )}

      {viewMode === "cards" && (
        <section className="ba-list pathway-grid">
          {filteredRows.map((item) => (
            <PathwayCard
              key={String(item.id)}
              item={item}
              onOpen={() => setSelectedItem(item)}
            />
          ))}
          {!filteredRows.length && (
            <Empty
              icon="🗺️"
              title="No pathways found"
              text="Create streams such as General, Science, Business, Arts, Technical, or Vocational under a curriculum."
            />
          )}
        </section>
      )}

      {filterOpen && (
        <BranchViewportPortal themeSourceClass=".curriculum-systems-root .ba-page"><FilterSheet
          search={search}
          setSearch={setSearch}
          curriculums={curriculums}
          curriculumFilter={curriculumFilter}
          statusFilter={statusFilter}
          setCurriculumFilter={setCurriculumFilter}
          setStatusFilter={setStatusFilter}
          clearFilters={clearFilters}
          onClose={() => setFilterOpen(false)}
        /></BranchViewportPortal>
      )}

      {moreOpen && (
        <BranchViewportPortal themeSourceClass=".curriculum-systems-root .ba-page"><MoreSheet
          viewMode={viewMode}
          setViewMode={(mode) => {
            setViewMode(mode);
            setMoreOpen(false);
          }}
          onRefresh={async () => {
            setMoreOpen(false);
            await load();
          }}
          onClose={() => setMoreOpen(false)}
        /></BranchViewportPortal>
      )}

      {selectedItem && (
        <BranchViewportPortal themeSourceClass=".curriculum-systems-root .ba-page"><ActionSheet
          item={selectedItem}
          openEdit={openEdit}
          toggleActive={toggleActive}
          remove={remove}
          onClose={() => setSelectedItem(null)}
        /></BranchViewportPortal>
      )}

      {modalOpen && (
        <BranchViewportPortal themeSourceClass=".curriculum-systems-root .ba-page"><PathwayModal
          form={form}
          saving={saving}
          curriculums={curriculums}
          setModalOpen={setModalOpen}
          updateForm={updateForm}
          save={save}
        /></BranchViewportPortal>
      )}
    </main>
  );
}

function State({
  primary,
  title,
  text,
}: {
  primary: string;
  title: string;
  text: string;
}) {
  return (
    <main
      className="ba-page"
      style={{ "--ba-primary": primary } as React.CSSProperties}
    >
      <style>{css}</style>
      <section className="ba-state">
        <div className="ba-spinner" />
        <h2>{title}</h2>
        <p>{text}</p>
      </section>
    </main>
  );
}

function PathwayCard({
  item,
  onOpen,
}: {
  item: PathwayView;
  onOpen: () => void;
}) {
  return (
    <button type="button" className="pathway-row" onClick={onOpen}>
      <span className="pathway-avatar">🗺️</span>
      <span className="pathway-main">
        <strong>{item.name || "Unnamed pathway"}</strong>
        <small>
          {item.curriculumName}
          {item.code ? ` · ${item.code}` : ""}
        </small>
        <em>
          {item.subjectCount} subject link(s) · {item.studentCount} student
          link(s)
        </em>
      </span>
      <span className="pathway-side">
        <span
          className={`status-dot-mini ${item.active ? "green" : "gray"}`}
          title={item.active ? "Active" : "Inactive"}
          aria-label={item.active ? "Active" : "Inactive"}
        />
        <i>⋯</i>
      </span>
    </button>
  );
}

function FilterSheet({
  search,
  setSearch,
  curriculums,
  curriculumFilter,
  statusFilter,
  setCurriculumFilter,
  setStatusFilter,
  clearFilters,
  onClose,
}: {
  search: string;
  setSearch: (value: string) => void;
  curriculums: Curriculum[];
  curriculumFilter: string;
  statusFilter: string;
  setCurriculumFilter: (value: string) => void;
  setStatusFilter: (value: string) => void;
  clearFilters: () => void;
  onClose: () => void;
}) {
  return (
    <div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet">
        <div className="ba-sheet-head">
          <div>
            <h2>Filters</h2>
            <p>Choose only what you need. The list updates after applying.</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close filters">
            ✕
          </button>
        </div>

        <div className="ba-form compact">
        <div className="ba-record-search-in-filter"><span>Search</span><input type="search" value={search} onChange={(e)=>setSearch(e.target.value)} placeholder="Search pathways" /></div>
          <label>
            <span>Curriculum</span>
            <select
              value={curriculumFilter}
              onChange={(event) => setCurriculumFilter(event.target.value)}
            >
              <option value="all">All curriculums</option>
              {curriculums.map((row: any) => (
                <option key={String(row.id)} value={String(row.id)}>
                  {row.name || row.title || `Curriculum ${row.id}`}
                </option>
              ))}
            </select>
          </label>

          <label>
            <span>Status</span>
            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
            >
              <option value="active">Active</option>
              <option value="all">All</option>
              <option value="inactive">Inactive/Deleted</option>
            </select>
          </label>
        </div>

        <div className="ba-sheet-actions">
          <button type="button" onClick={clearFilters}>
            Clear
          </button>
          <button type="button" className="primary" onClick={onClose}>
            Apply
          </button>
        </div>
      </section>
    </div>
  );
}

function MoreSheet({
  viewMode,
  setViewMode,
  onRefresh,
  onClose,
}: {
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  onRefresh: () => void | Promise<void>;
  onClose: () => void;
}) {
  return (
    <div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet small">
        <div className="ba-sheet-head">
          <div>
            <h2>More</h2>
            <p>Advanced views are here so the main page stays simple.</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close menu">
            ✕
          </button>
        </div>

        <div className="ba-menu-list">
          <button
            type="button"
            className={viewMode === "cards" ? "active" : ""}
            onClick={() => setViewMode("cards")}
          >
            <span>☰</span>
            <b>List view</b>
            <small>Simple pathway records</small>
          </button>
          <button
            type="button"
            className={viewMode === "table" ? "active" : ""}
            onClick={() => setViewMode("table")}
          >
            <span>☷</span>
            <b>Table view</b>
            <small>Dense records for laptop work</small>
          </button>
          <button
            type="button"
            className={viewMode === "summary" ? "active" : ""}
            onClick={() => setViewMode("summary")}
          >
            <span>◔</span>
            <b>Analytics</b>
            <small>Curriculum, status and usage summaries</small>
          </button>
          <button type="button" onClick={onRefresh}>
            <span>↻</span>
            <b>Refresh</b>
            <small>Reload local branch records</small>
          </button>
        </div>
      </section>
    </div>
  );
}

function ActionSheet({
  item,
  openEdit,
  toggleActive,
  remove,
  onClose,
}: {
  item: PathwayView;
  openEdit: (item: PathwayView) => void;
  toggleActive: (item: PathwayView) => void;
  remove: (item: PathwayView) => void;
  onClose: () => void;
}) {
  return (
    <div className="ba-sheet-backdrop" role="dialog" aria-modal="true">
      <section className="ba-sheet small">
        <div className="ba-sheet-profile">
          <div>
            <h2>{item.name || "Pathway"}</h2>
            <p>
              {item.curriculumName} · {item.active ? "Active" : "Inactive"}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close pathway actions"
          >
            ✕
          </button>
        </div>

        <div className="pathway-detail-strip">
          <span>
            <b>Code</b>
            {item.code || "Not set"}
          </span>
          <span>
            <b>Subjects</b>
            {item.subjectCount}
          </span>
          <span>
            <b>Students</b>
            {item.studentCount}
          </span>
        </div>

        <div className="ba-menu-list">
          <button type="button" onClick={() => openEdit(item)}>
            <span>✎</span>
            <b>Edit pathway</b>
            <small>Update curriculum, name, code and description</small>
          </button>
          <button type="button" onClick={() => toggleActive(item)}>
            <span>{item.active ? "⏸" : "✓"}</span>
            <b>{item.active ? "Deactivate" : "Activate"}</b>
            <small>
              {item.active
                ? "Hide this pathway from active use"
                : "Restore this pathway for active use"}
            </small>
          </button>
          <button type="button" className="danger" onClick={() => remove(item)}>
            <span>⌫</span>
            <b>Delete</b>
            <small>Soft delete this pathway locally</small>
          </button>
        </div>
      </section>
    </div>
  );
}

function TableView({
  rows,
  openEdit,
  toggleActive,
  remove,
}: {
  rows: PathwayView[];
  openEdit: (item: PathwayView) => void;
  toggleActive: (item: PathwayView) => void;
  remove: (item: PathwayView) => void;
}) {
  return (
    <section className="ba-table-card">
      <div className="ba-table-scroll">
        <table>
          <thead>
            <tr>
              <th>Pathways ({rows.length})</th>
              <th>Curriculum</th>
              <th>Code</th>
              <th>Subjects</th>
              <th>Students</th>
              <th>Status</th>
              <th>Updated</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((item) => (
              <tr key={String(item.id)}>
                <td>
                  <strong>{item.name}</strong>
                  <span>{item.description || "No description"}</span>
                </td>
                <td>{item.curriculumName}</td>
                <td>{item.code || "—"}</td>
                <td>{item.subjectCount}</td>
                <td>{item.studentCount}</td>
                <td>
                  <Chip tone={item.active ? "green" : "gray"}>
                    {item.active ? "Active" : "Inactive"}
                  </Chip>
                </td>
                <td>
                  {timeText(
                    (item.row as AnyRow).updatedAt ||
                      (item.row as AnyRow).createdAt,
                  )}
                </td>
                <td>
                  <div className="ba-table-actions">
                    <button type="button" onClick={() => openEdit(item)}>
                      Edit
                    </button>
                    <button type="button" onClick={() => toggleActive(item)}>
                      {item.active ? "Deactivate" : "Activate"}
                    </button>
                    <button
                      type="button"
                      className="ba-delete"
                      onClick={() => remove(item)}
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!rows.length && (
          <div className="ba-empty-table">No pathway matches your filters.</div>
        )}
      </div>
    </section>
  );
}

function PathwayModal({
  form,
  saving,
  curriculums,
  setModalOpen,
  updateForm,
  save,
}: {
  form: FormState;
  saving: boolean;
  curriculums: Curriculum[];
  setModalOpen: (open: boolean) => void;
  updateForm: (patch: Partial<FormState>) => void;
  save: (event?: React.FormEvent) => void;
}) {
  return (
    <BranchViewportPortal themeSourceClass=".curriculum-systems-root .ba-page"><div className="ba-modal-backdrop">
      <form className="ba-modal" onSubmit={save}>
        <div className="ba-modal-head">
          <div>
            <h2>{form.id ? "Edit Pathway" : "Add Pathway"}</h2>
            <p>
              Pathway will be saved under the selected school branch and
              curriculum.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setModalOpen(false)}
            aria-label="Close pathway form"
          >
            ✕
          </button>
        </div>

        <section className="ba-form-section">
          <h3>Pathway Details</h3>
          <div className="ba-form two">
            <label>
              <span>Curriculum</span>
              <select
                value={form.curriculumId}
                onChange={(event) =>
                  updateForm({ curriculumId: event.target.value })
                }
              >
                <option value="">Select curriculum</option>
                {curriculums.map((row: any) => (
                  <option key={String(row.id)} value={String(row.id)}>
                    {row.name || row.title || `Curriculum ${row.id}`}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span>Pathway Name</span>
              <input
                value={form.name}
                onChange={(event) => updateForm({ name: event.target.value })}
                placeholder="e.g. Science Track"
              />
            </label>
            <label>
              <span>Code</span>
              <input
                value={form.code}
                onChange={(event) => updateForm({ code: event.target.value })}
                placeholder="e.g. SCI, GEN, BUS"
              />
            </label>
            <label>
              <span>Status</span>
              <select
                value={form.active ? "active" : "inactive"}
                onChange={(event) =>
                  updateForm({ active: event.target.value === "active" })
                }
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </label>
            <label className="wide">
              <span>Description</span>
              <textarea
                value={form.description}
                onChange={(event) =>
                  updateForm({ description: event.target.value })
                }
                placeholder="Describe this stream, track, or specialization."
              />
            </label>
          </div>
        </section>

        <div className="ba-modal-actions">
          <button type="button" onClick={() => setModalOpen(false)}>
            Cancel
          </button>
          <button type="submit" disabled={saving}>
            {saving ? "Saving..." : form.id ? "Save Changes" : "Add Pathway"}
          </button>
        </div>
      </form>
    </div></BranchViewportPortal>
  );
}

function groupedCounts(
  rows: PathwayView[],
  keyFn: (item: PathwayView) => string,
) {
  const map = new Map<string, number>();
  rows.forEach((row) => {
    const key = keyFn(row) || "Unknown";
    map.set(key, (map.get(key) || 0) + 1);
  });
  return Array.from(map.entries())
    .map(([label, value]) => ({ label, value }))
    .sort((a, b) => b.value - a.value || a.label.localeCompare(b.label));
}

function AnalysisCard({
  title,
  rows,
  total,
}: {
  title: string;
  rows: { label: string; value: number }[];
  total: number;
}) {
  return (
    <article className="ba-analysis">
      <span>{title}</span>
      <strong>{rows.reduce((sum, row) => sum + row.value, 0)}</strong>
      <div className="ba-analysis-list">
        {rows.slice(0, 8).map((row) => {
          const share = total ? Math.round((row.value / total) * 100) : 0;
          return (
            <section key={row.label}>
              <div>
                <b>{row.label}</b>
                <small>
                  {row.value} · {share}%
                </small>
              </div>
              <div className="ba-progress">
                <i style={{ width: `${Math.max(4, share)}%` }} />
              </div>
            </section>
          );
        })}
        {!rows.length && <p>No data available.</p>}
      </div>
    </article>
  );
}

const css = `
@keyframes spin { to { transform: rotate(360deg); } }

.ba-page{--ease:cubic-bezier(.2,.8,.2,1);min-height:100dvh;width:100%;max-width:100%;min-width:0;padding:calc(8px * var(--local-density-scale,1));padding-bottom:max(40px,env(safe-area-inset-bottom));background:radial-gradient(circle at top left,color-mix(in srgb,var(--ba-primary) 9%,transparent),transparent 30rem),var(--bg,#f7f8fb);color:var(--text,#111827);font-family:var(--font-family,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif);font-size:var(--font-size,14px);overflow-x:hidden}.ba-page *,.ba-page *::before,.ba-page *::after{box-sizing:border-box;min-width:0}.ba-page button,.ba-page input,.ba-page select,.ba-page textarea{font:inherit;max-width:100%}.ba-page button{-webkit-tap-highlight-color:transparent}.ba-page input,.ba-page select,.ba-page textarea{width:100%;min-height:44px;border:1px solid var(--input-border,var(--border,rgba(0,0,0,.10)));border-radius:16px;padding:0 12px;background:var(--input-bg,var(--surface,#fff));color:var(--input-text,var(--text,#111827));outline:none;font-weight:750}.ba-page textarea{min-height:104px;padding-top:10px;resize:vertical}.ba-page input:focus,.ba-page select:focus,.ba-page textarea:focus{border-color:color-mix(in srgb,var(--ba-primary) 52%,var(--border,rgba(0,0,0,.10)));box-shadow:0 0 0 4px color-mix(in srgb,var(--ba-primary) 12%,transparent)}.ba-state,.ba-search-card,.pathway-row,.ba-table-card,.ba-analysis,.ba-empty,.ba-sheet,.ba-modal{background:var(--card-bg,var(--surface,#fff));border:1px solid var(--border,rgba(0,0,0,.10));box-shadow:0 12px 28px rgba(15,23,42,.045)}.ba-state{min-height:min(420px,calc(100dvh - 32px));width:min(520px,100%);margin:0 auto;display:grid;place-items:center;align-content:center;gap:10px;padding:22px;border-radius:28px;text-align:center}.ba-spinner{width:38px;height:38px;border-radius:999px;border:4px solid color-mix(in srgb,var(--ba-primary) 18%,transparent);border-top-color:var(--ba-primary);animation:spin .8s linear infinite}.ba-state h2{margin:0;font-size:22px;font-weight:1000;letter-spacing:-.04em}.ba-state p{max-width:34rem;margin:0;color:var(--muted,#64748b);font-size:13px;line-height:1.6}.ba-state-button{min-height:42px;border:0;border-radius:999px;padding:0 16px;background:var(--ba-primary);color:#fff;font-weight:950;cursor:pointer}.ba-toast{position:sticky;top:8px;z-index:40;display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;padding:12px 14px;border-radius:18px;font-size:13px;font-weight:850;box-shadow:0 18px 40px rgba(15,23,42,.12)}.ba-toast.success{background:rgba(34,197,94,.14);color:#166534}.ba-toast.error{background:rgba(239,68,68,.12);color:#991b1b}.ba-toast.info{background:rgba(59,130,246,.13);color:#1d4ed8}.ba-toast button{border:0;background:transparent;color:currentColor;font-weight:1000;cursor:pointer}.ba-search-card{display:grid;grid-template-columns:minmax(0,1fr) auto auto auto;gap:8px;align-items:center;margin-top:2px;padding:8px;border-radius:24px}.ba-search{min-width:0;display:grid;grid-template-columns:auto minmax(0,1fr);align-items:center;gap:8px;min-height:44px;padding:0 11px;border-radius:18px;background:color-mix(in srgb,var(--muted,#64748b) 7%,transparent)}.ba-search span{color:var(--muted,#64748b);font-size:17px;font-weight:1000}.ba-search input{min-height:42px;border:0;padding:0;border-radius:0;background:transparent;box-shadow:none;font-size:14px}.ba-icon-button,.ba-filter-button,.ba-add-inline{width:42px;height:42px;border:1px solid var(--border,rgba(0,0,0,.10));border-radius:999px;display:grid;place-items:center;background:var(--card-bg,var(--surface,#fff));color:var(--text,#111827);font-size:18px;font-weight:1000;cursor:pointer;box-shadow:0 10px 22px rgba(15,23,42,.045)}.ba-add-inline{flex:0 0 42px;border-color:var(--ba-primary);background:var(--ba-primary);color:#fff;font-size:25px;line-height:1;box-shadow:0 12px 28px color-mix(in srgb,var(--ba-primary) 22%,transparent)}.ba-slider-icon{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}.ba-filter-button{position:relative;background:color-mix(in srgb,var(--ba-primary) 8%,var(--card-bg,#fff));color:var(--ba-primary)}.ba-filter-button.active{background:var(--ba-primary);color:#fff;border-color:var(--ba-primary)}.ba-filter-button b{position:absolute;top:-4px;right:-4px;min-width:19px;height:19px;display:grid;place-items:center;border-radius:999px;background:#ef4444;color:#fff;font-size:10px;border:2px solid var(--card-bg,#fff)}.ba-filter-chips{display:flex;gap:7px;overflow-x:auto;padding:8px 1px 0;scrollbar-width:none}.ba-filter-chips::-webkit-scrollbar{display:none}.ba-filter-chips button{flex:0 0 auto;min-height:31px;border:0;border-radius:999px;padding:0 10px;background:color-mix(in srgb,var(--ba-primary) 11%,transparent);color:var(--ba-primary);font-size:11px;font-weight:950;white-space:nowrap;cursor:pointer}.ba-list{display:grid;gap:7px;margin-top:10px}.pathway-row{width:100%;display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:10px;padding:10px;border-radius:22px;text-align:left;cursor:pointer;transition:transform .16s var(--ease),box-shadow .16s var(--ease),border-color .16s var(--ease)}.pathway-row:hover{transform:translateY(-1px);border-color:color-mix(in srgb,var(--ba-primary) 28%,var(--border,rgba(0,0,0,.10)));box-shadow:0 16px 34px rgba(15,23,42,.07)}.pathway-avatar{width:42px;height:42px;border-radius:16px;display:grid;place-items:center;flex:0 0 auto;background:color-mix(in srgb,var(--ba-primary) 12%,var(--surface,#fff));color:var(--ba-primary);font-weight:1000}.pathway-main{display:grid;gap:2px;min-width:0}.pathway-main strong,.pathway-main small,.pathway-main em{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pathway-main strong{color:var(--text,#111827);font-size:14px;font-weight:1000;letter-spacing:-.02em}.pathway-main small{color:var(--muted,#64748b);font-size:12px;font-weight:800}.pathway-main em{color:var(--muted,#64748b);font-size:11px;font-style:normal;font-weight:750}.pathway-side{display:flex;align-items:center;gap:8px;color:var(--muted,#64748b)}.pathway-side i{font-style:normal;font-size:18px;line-height:1}.status-dot-mini{width:10px;height:10px;border-radius:999px;display:inline-block;box-shadow:0 0 0 3px color-mix(in srgb,currentColor 15%,transparent)}.status-dot-mini.green{background:#22c55e;color:#22c55e}.status-dot-mini.gray{background:#94a3b8;color:#94a3b8}.ba-chip{max-width:100%;display:inline-flex;align-items:center;min-height:25px;padding:4px 9px;border-radius:999px;font-size:11px;font-weight:950;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ba-chip.green{background:rgba(34,197,94,.12);color:#16a34a}.ba-chip.red{background:rgba(239,68,68,.12);color:#dc2626}.ba-chip.blue{background:rgba(59,130,246,.12);color:#2563eb}.ba-chip.gray{background:rgba(107,114,128,.12);color:var(--muted,#64748b)}.ba-chip.orange{background:rgba(245,158,11,.14);color:#b45309}.ba-chip.purple{background:rgba(147,51,234,.12);color:#7e22ce}.ba-table-card{margin-top:10px;border-radius:22px;overflow:hidden}.ba-table-scroll{width:100%;max-width:100%;overflow-x:auto}.ba-table-scroll table{width:100%;min-width:980px;border-collapse:collapse;background:var(--card-bg,var(--surface,#fff))}.ba-table-scroll th,.ba-table-scroll td{padding:10px;border-bottom:1px solid var(--border,rgba(0,0,0,.10));vertical-align:top;text-align:left;font-size:13px;color:var(--text,#111827)}.ba-table-scroll th{background:color-mix(in srgb,var(--ba-primary) 7%,var(--card-bg,var(--surface,#fff)));color:var(--muted,#64748b);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.07em}.ba-table-scroll td strong,.ba-table-scroll td span{display:block}.ba-table-scroll td strong{font-weight:1000}.ba-table-scroll td span{margin-top:3px;color:var(--muted,#64748b);font-size:11px}.ba-table-actions{display:flex;align-items:center;gap:6px;flex-wrap:nowrap;white-space:nowrap}.ba-table-actions button{flex:0 0 auto;min-height:32px;border:0;border-radius:999px;padding:0 10px;background:color-mix(in srgb,var(--ba-primary) 10%,var(--surface,#fff));color:var(--ba-primary);font-size:11px;font-weight:950;cursor:pointer}.ba-table-actions button:first-child{background:var(--ba-primary);color:#fff}.ba-table-actions .ba-delete{background:color-mix(in srgb,#ef4444 9%,var(--surface,#fff));color:#dc2626;border:1px solid color-mix(in srgb,#ef4444 24%,transparent)}.ba-empty-table{padding:22px;text-align:center;color:var(--muted,#64748b);font-weight:850}.ba-analysis-grid{display:grid;grid-template-columns:minmax(0,1fr);gap:10px;margin-top:10px}.ba-analysis{border-radius:22px;padding:13px}.ba-analysis span{color:var(--muted,#64748b);font-size:11px;font-weight:950;text-transform:uppercase;letter-spacing:.08em}.ba-analysis strong{display:block;margin-top:8px;font-size:clamp(22px,7vw,30px);line-height:1;font-weight:1000;letter-spacing:-.06em;overflow-wrap:anywhere}.ba-analysis p{margin:8px 0 0;color:var(--muted,#64748b);font-size:12px;line-height:1.5}.ba-analysis-list{display:grid;gap:10px;margin-top:12px}.ba-analysis-list section{display:grid;gap:6px;padding:10px;border-radius:16px;background:color-mix(in srgb,var(--muted,#64748b) 8%,transparent)}.ba-analysis-list section>div:first-child{display:flex;justify-content:space-between;gap:10px}.ba-analysis-list b,.ba-analysis-list small{font-size:12px}.ba-analysis-list small{color:var(--muted,#64748b);font-weight:850}.ba-progress{height:8px;border-radius:999px;background:color-mix(in srgb,var(--muted,#64748b) 18%,transparent);overflow:hidden}.ba-progress i{display:block;height:100%;border-radius:inherit;background:var(--ba-primary)}.ba-empty{display:grid;place-items:center;align-content:center;gap:8px;min-height:220px;text-align:center;border-style:dashed;border-radius:22px;padding:18px}.ba-empty-icon{width:56px;height:56px;display:grid;place-items:center;border-radius:22px;background:color-mix(in srgb,var(--ba-primary) 12%,var(--surface,#fff));font-size:28px}.ba-empty h3{margin:0;font-size:18px;font-weight:1000}.ba-empty p{margin:0;color:var(--muted,#64748b);font-size:13px;line-height:1.6}.ba-sheet-backdrop,.ba-modal-backdrop{position:fixed;inset:0;z-index:80;display:grid;place-items:end center;padding:10px;background:rgba(15,23,42,.58);backdrop-filter:blur(12px)}.ba-sheet,.ba-modal{width:min(720px,100%);max-height:min(92dvh,900px);overflow-y:auto;border-radius:28px;padding:14px}.ba-sheet.small{width:min(480px,100%)}.ba-sheet-head,.ba-modal-head,.ba-sheet-profile{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding:4px 2px 14px}.ba-sheet-head h2,.ba-modal-head h2,.ba-sheet-profile h2{margin:0;font-size:20px;font-weight:1000;letter-spacing:-.05em;color:var(--text,#111827)}.ba-sheet-head p,.ba-modal-head p,.ba-sheet-profile p{margin:5px 0 0;color:var(--muted,#64748b);font-size:12px;line-height:1.5}.ba-sheet-head button,.ba-modal-head button,.ba-sheet-profile button{width:40px;height:40px;flex:0 0 auto;display:grid;place-items:center;border-radius:999px;background:var(--surface,#fff);color:var(--muted,#64748b);border:1px solid var(--border,rgba(0,0,0,.10));font-weight:1000;cursor:pointer}.ba-form{display:grid;grid-template-columns:minmax(0,1fr);gap:10px}.ba-form.two{grid-template-columns:minmax(0,1fr)}.ba-form.compact{gap:10px}.ba-form label{display:grid;gap:6px}.ba-form span,.ba-form-section h3{color:var(--muted,#64748b);font-size:11px;font-weight:950;letter-spacing:.06em;text-transform:uppercase}.ba-form .wide{grid-column:1/-1}.ba-form-section{margin-top:8px}.ba-form-section h3{margin:0 0 10px}.ba-sheet-actions,.ba-modal-actions{display:flex;justify-content:flex-end;gap:8px;flex-wrap:wrap;margin-top:14px}.ba-sheet-actions button,.ba-modal-actions button{min-height:40px;border:0;border-radius:999px;padding:0 14px;background:color-mix(in srgb,var(--muted,#64748b) 8%,var(--surface,#fff));color:var(--text,#111827);font-size:12px;font-weight:950;cursor:pointer}.ba-sheet-actions .primary,.ba-modal-actions button:last-child{background:var(--ba-primary);color:#fff}.ba-menu-list{display:grid;gap:8px}.ba-menu-list button{width:100%;display:grid;grid-template-columns:auto minmax(0,1fr);grid-template-areas:"icon title" "icon text";align-items:center;column-gap:10px;text-align:left;border:1px solid var(--border,rgba(0,0,0,.10));border-radius:18px;padding:11px;background:var(--surface,#fff);color:var(--text,#111827);cursor:pointer}.ba-menu-list button span{grid-area:icon;width:36px;height:36px;display:grid;place-items:center;border-radius:14px;background:color-mix(in srgb,var(--ba-primary) 10%,transparent);color:var(--ba-primary);font-weight:1000}.ba-menu-list button b{grid-area:title;font-size:13px;font-weight:1000}.ba-menu-list button small{grid-area:text;color:var(--muted,#64748b);font-size:11px;font-weight:750}.ba-menu-list button.active{border-color:var(--ba-primary);background:color-mix(in srgb,var(--ba-primary) 10%,var(--surface,#fff))}.ba-menu-list button.active span{background:var(--ba-primary);color:#fff}.ba-menu-list button.danger{border-color:color-mix(in srgb,#ef4444 24%,transparent);background:color-mix(in srgb,#ef4444 8%,var(--surface,#fff))}.ba-menu-list button.danger span{background:color-mix(in srgb,#ef4444 14%,transparent);color:#dc2626}.pathway-detail-strip{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;margin-bottom:10px}.pathway-detail-strip span{padding:9px;border-radius:16px;background:color-mix(in srgb,var(--muted,#64748b) 8%,transparent);color:var(--muted,#64748b);font-size:11px;font-weight:800;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pathway-detail-strip b{display:block;color:var(--text,#111827);font-size:12px;font-weight:1000;margin-bottom:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}@media (min-width:680px){.ba-page{padding:12px}.ba-form.two,.ba-form{grid-template-columns:repeat(2,minmax(0,1fr))}.ba-analysis-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.ba-sheet-backdrop,.ba-modal-backdrop{place-items:center;padding:18px}.ba-sheet,.ba-modal{padding:18px}.pathway-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (min-width:1040px){.ba-page{padding:16px}.pathway-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.ba-analysis-grid{grid-template-columns:repeat(4,minmax(0,1fr))}}@media (min-width:1400px){.pathway-grid{grid-template-columns:repeat(4,minmax(0,1fr))}}@media (max-width:520px){.ba-page{padding:6px}.ba-sheet,.ba-modal,.ba-empty{border-radius:20px;padding:11px}.ba-sheet-actions,.ba-modal-actions{display:grid;grid-template-columns:1fr}.ba-sheet-actions button,.ba-modal-actions button{width:100%}.pathway-detail-strip{grid-template-columns:minmax(0,1fr)}}
@media (min-width:980px){
  .ba-modal-backdrop,
  .ba-sheet-backdrop{
    top:var(--eds-shell-top-offset,0px);
    right:0;
    bottom:0;
    left:var(--portal-content-left,0px);
    width:auto;
    max-width:calc(100vw - var(--portal-content-left,0px));
    min-width:0;
    overflow-x:hidden;
  }
  .ba-modal,
  .ba-sheet{
    min-width:0;
    max-width:calc(100vw - var(--portal-content-left,0px) - 20px);
  }
}



/* V36 SETUP: Students visual standard; source CRUD, relationships and offline sync remain unchanged. */
.curriculum-systems-root .ba-page {
  width:100%;min-width:0;max-width:none;min-height:0;margin:0;
  padding:4px 4px max(20px,env(safe-area-inset-bottom));
  background:var(--bg,var(--background,#f2f4f7));overflow-x:clip;
}
.curriculum-systems-root .ba-page .ba-search-card,.curriculum-systems-root .ba-page .ba-filter-chips,.curriculum-systems-root .ba-page .ba-hero {display:none!important;}
.curriculum-systems-root .ba-page .ba-list{width:100%;min-width:0;max-width:none;margin:2px 0 0;gap:9px;align-items:stretch;}
.curriculum-systems-root .ba-page .ba-list > .student-row,.curriculum-systems-root .ba-page .ba-list > .curriculum-row,
.curriculum-systems-root .ba-page .ba-list > .pathway-row,.curriculum-systems-root .ba-page .ba-list > .organization-row{width:100%;min-width:0;margin:0;padding:9px 10px;}
.curriculum-systems-root .ba-page .student-row,.curriculum-systems-root .ba-page .organization-row,.curriculum-systems-root .ba-page .curriculum-row,
.curriculum-systems-root .ba-page .pathway-row,.curriculum-systems-root .ba-page .ba-card,.curriculum-systems-root .ba-page .ba-table-card,.curriculum-systems-root .ba-page .ba-analysis{
 background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 93%,var(--text,#182235) 7%);
 border:1px solid color-mix(in srgb,var(--border,#d4dae3) 85%,var(--text,#182235) 15%);
 border-radius:13px;box-shadow:none;transform:none;
}
.curriculum-systems-root .ba-page .student-row:hover,.curriculum-systems-root .ba-page .curriculum-row:hover,.curriculum-systems-root .ba-page .pathway-row:hover,
.curriculum-systems-root .ba-page .organization-row:hover{transform:none;box-shadow:none;}
.curriculum-systems-root .ba-page .ba-avatar{box-shadow:none;border-radius:12px;}
.curriculum-systems-root .ba-page .ba-table-card{display:block;width:100%;max-width:none;min-width:0;margin:2px 0 0;padding:4px;overflow:visible;}
.curriculum-systems-root .ba-page .ba-table-scroll{width:100%;max-width:100%;min-width:0;overflow-x:auto;overflow-y:auto;
 overscroll-behavior-x:contain;-webkit-overflow-scrolling:touch;border-radius:10px;}
.curriculum-systems-root .ba-page .ba-table-scroll table{width:100%;margin:0;background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 95%,var(--text,#182235) 5%);}
.curriculum-systems-root .ba-page .ba-table-scroll thead th{position:sticky;top:0;z-index:2;background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 85%,var(--text,#182235) 15%);}
.curriculum-systems-root .ba-page .ba-table-scroll tbody tr:nth-child(even){background:color-mix(in srgb,var(--card-bg,var(--surface,#fff)) 89%,var(--text,#182235) 11%);}
.curriculum-systems-root .ba-page .ba-table-scroll td{background:transparent;}
.curriculum-systems-root .ba-page .ba-table-scroll th,.curriculum-systems-root .ba-page .ba-table-scroll td{padding:9px 10px;}
.curriculum-systems-root .ba-page .ba-analysis-grid{width:100%;max-width:none;min-width:0;margin:2px 0 0;gap:9px;}
.ba-record-search-in-filter{display:grid;gap:6px;margin:0 0 10px;}
.ba-record-search-in-filter span{font-size:11px;font-weight:750;color:var(--muted,#64748b);}
.ba-record-search-in-filter input{min-height:40px;width:100%;border:1px solid var(--border,#d4dae3);
 border-radius:9px;padding:0 11px;background:var(--input-bg,var(--surface,#fff));color:var(--text,#182235);}
.ba-modal-head button,.ba-sheet-head button{opacity:1;visibility:visible;flex:0 0 auto;color:var(--text,#182235);}
@media(min-width:680px) and (max-width:1023px){.curriculum-systems-root .ba-page .ba-list{grid-template-columns:repeat(2,minmax(0,1fr));}}
@media(min-width:1024px){.curriculum-systems-root .ba-page .ba-list{grid-template-columns:repeat(4,minmax(0,1fr));}}
@media(max-width:679px){.curriculum-systems-root .ba-page .ba-list{grid-template-columns:minmax(0,1fr);}}
@media(max-width:639px){.curriculum-systems-root .ba-page {padding:2px 2px 14px;} .curriculum-systems-root .ba-page .ba-list{gap:7px;}}
@media(prefers-reduced-motion:reduce){.curriculum-systems-root .ba-page .student-row,.curriculum-systems-root .ba-page .curriculum-row{transition:none;}}

`;
  return CurriculumPathwaysWorkspace;
})();


export default function CurriculumSystems() {
  const [mode, setMode] = useState<CurriculumSystemsMode>("curriculums");
  const [modeReady, setModeReady] = useState(false);

  useEffect(() => {
    setMode(readCurriculumSystemsMode());
    setModeReady(true);
  }, []);

  const changeMode = (next: CurriculumSystemsMode) => {
    setMode(next);
    try {
      window.localStorage.setItem(CURRICULUM_SYSTEMS_MODE_KEY, next);
    } catch {}
  };

  const ActiveWorkspace = mode === "pathways"
    ? CurriculumPathwaysModule
    : CurriculumsModule;

  return (
    <main className="curriculum-systems-root" data-mode={mode}>
      <style>{curriculumSystemsShellCss}</style>
      <section className="curriculum-systems-command" aria-label="Curriculum systems workspace">


        <div className="curriculum-systems-mode-switch" role="tablist" aria-label="Curriculum system areas">
          <button
            type="button"
            role="tab"
            aria-selected={mode === "curriculums"}
            className={mode === "curriculums" ? "active" : ""}
            onClick={() => changeMode("curriculums")}
          >
            <span aria-hidden="true">▤</span>
            <span><strong>Curriculums</strong><small>Programs and versions</small></span>
          </button>

          <button
            type="button"
            role="tab"
            aria-selected={mode === "pathways"}
            className={mode === "pathways" ? "active" : ""}
            onClick={() => changeMode("pathways")}
          >
            <span aria-hidden="true">⤳</span>
            <span><strong>Pathways</strong><small>Tracks and options</small></span>
          </button>
        </div>
      </section>

      <section className="curriculum-systems-workspace" role="tabpanel">
        {modeReady ? <ActiveWorkspace /> : <section className="curriculum-systems-boot">Opening curriculum systems…</section>}
      </section>
    </main>
  );
}

const curriculumSystemsShellCss = `
.curriculum-systems-root { width: 100%; min-width: 0; max-width: 100%; display: grid; gap: 10px; overflow-x: clip; overflow-y: visible; color: var(--eds-text, var(--text, #111827)); }
.curriculum-systems-command { position: relative; z-index: 5; width: 100%; min-width: 0; display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 8px 10px; border: 1px solid var(--eds-border, var(--border, rgba(15,23,42,.09))); border-radius: var(--eds-radius-card, 16px); background: color-mix(in srgb, var(--eds-header-bg, var(--surface, #fff)) 96%, transparent); box-shadow: var(--eds-shadow-soft, 0 8px 22px rgba(15,23,42,.06)); backdrop-filter: blur(14px) saturate(1.06); }
.curriculum-systems-command-copy { min-width: 0; flex: 1; }
.curriculum-systems-command-copy strong, .curriculum-systems-command-copy small { display: block; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.curriculum-systems-command-copy strong { color: var(--eds-text-strong, var(--text, #111827)); font-size: 13px; font-weight: 900; }
.curriculum-systems-command-copy small { margin-top: 3px; color: var(--eds-text-muted, var(--muted, #667085)); font-size: 9px; font-weight: 650; }
.curriculum-systems-mode-switch { flex: 0 0 auto; display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 4px; padding: 3px; border: 1px solid var(--eds-divider, var(--border, rgba(15,23,42,.08))); border-radius: var(--eds-radius-control, 13px); background: var(--eds-surface-sunken, color-mix(in srgb, var(--surface,#fff) 82%, var(--bg,#f4f7fb))); }
.curriculum-systems-mode-switch button { min-width: 132px; min-height: 40px; display: grid; grid-template-columns: 27px minmax(0,1fr); align-items: center; gap: 7px; padding: 4px 7px; border: 1px solid transparent; border-radius: calc(var(--eds-radius-control,13px) - 3px); background: transparent; color: var(--eds-text,var(--text,#111827)); text-align: left; cursor: pointer; }
.curriculum-systems-mode-switch button:hover { background: var(--eds-primary-softer, color-mix(in srgb,var(--primary-color,#2563eb) 7%,transparent)); }
.curriculum-systems-mode-switch button.active { background: var(--eds-surface-raised,var(--surface,#fff)); color: var(--eds-primary,var(--primary-color,#2563eb)); border-color: color-mix(in srgb,var(--eds-primary,var(--primary-color,#2563eb)) 25%,var(--eds-border,transparent)); box-shadow: var(--eds-shadow-soft,0 4px 12px rgba(15,23,42,.07)); }
.curriculum-systems-mode-switch button > span:first-child { width: 27px; height: 27px; display: grid; place-items: center; border-radius: 9px; background: var(--eds-primary-soft,color-mix(in srgb,var(--primary-color,#2563eb) 13%,transparent)); color: var(--eds-primary,var(--primary-color,#2563eb)); font-size: 13px; font-weight: 900; }
.curriculum-systems-mode-switch button > span:last-child { min-width: 0; }
.curriculum-systems-mode-switch strong, .curriculum-systems-mode-switch small { display: block; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.curriculum-systems-mode-switch strong { color: inherit; font-size: 10px; font-weight: 850; }
.curriculum-systems-mode-switch small { margin-top: 2px; color: var(--eds-text-muted,var(--muted,#667085)); font-size: 8px; font-weight: 650; }
.curriculum-systems-workspace { width: 100%; min-width: 0; max-width: 100%; height: auto; max-height: none; overflow-x: clip; overflow-y: visible; }
.curriculum-systems-workspace > * { min-width: 0; max-width: 100%; }
.curriculum-systems-boot { min-height: 180px; display: grid; place-items: center; border: 1px solid var(--eds-border,rgba(15,23,42,.09)); border-radius: var(--eds-radius-card,16px); background: var(--eds-surface,#fff); color: var(--eds-text-muted,#667085); font-size: 11px; font-weight: 800; }
@media (max-width:760px) { .curriculum-systems-command { align-items: stretch; flex-direction: column; gap: 7px; padding: 8px; } .curriculum-systems-mode-switch { width: 100%; } .curriculum-systems-mode-switch button { min-width: 0; } }
@media (max-width:430px) { .curriculum-systems-command-copy small { white-space: normal; line-height: 1.35; } .curriculum-systems-mode-switch button { grid-template-columns: 24px minmax(0,1fr); gap: 5px; } .curriculum-systems-mode-switch button > span:first-child { width: 24px; height: 24px; border-radius: 8px; } .curriculum-systems-mode-switch small { display: none; } }



/* V36: retain a compact Curriculums / Pathways switch without a hero/title strip. */
.curriculum-systems-root {gap:5px;}
.curriculum-systems-command {padding:0;border:0;border-radius:0;background:transparent;box-shadow:none;backdrop-filter:none;justify-content:flex-start;}
.curriculum-systems-command-copy {display:none!important;}
.curriculum-systems-mode-switch {width:max-content;max-width:100%;gap:4px;border-radius:9px;padding:2px;box-shadow:none;}
.curriculum-systems-mode-switch button {min-height:31px;min-width:0;grid-template-columns:1fr;padding:4px 11px;}
.curriculum-systems-mode-switch button > span:first-child,.curriculum-systems-mode-switch small {display:none!important;}
.curriculum-systems-mode-switch strong {font-size:11px;}
@media(max-width:760px){.curriculum-systems-command{display:block;padding:0;}.curriculum-systems-mode-switch{width:100%;}.curriculum-systems-mode-switch button{width:auto;}}
`;
