"use client";



/**

 * app/components/excel/ExcelImportSheet.tsx

 * --------------------------------------------------------------------------

 * ELEEVEON EXCEL — IMPORT WORKFLOW SHEET

 * --------------------------------------------------------------------------

 *

 * Generic reusable shell around an Excel import workflow.

 *

 * It does NOT parse workbooks itself.

 * It does NOT know about students, attendance or assessments.

 *

 * Domain pages control:

 * - current step;

 * - parsing;

 * - sheet selection;

 * - mappings;

 * - validation;

 * - import commit.

 */



import type {

  ReactNode,

} from "react";



import {

  useEffect,

} from "react";

import { createPortal } from "react-dom";



export type ExcelImportStep =

  | "file"

  | "sheet"

  | "mapping"

  | "preview"

  | "result";



export interface ExcelImportSheetProps {

  open: boolean;



  onClose: () => void;



  title?: string;



  subtitle?: string;



  step?: ExcelImportStep;



  children: ReactNode;



  footer?: ReactNode;



  busy?: boolean;



  preventCloseWhileBusy?: boolean;



  width?: number;



  className?: string;

}



const STEP_ORDER: ExcelImportStep[] =

  [

    "file",

    "sheet",

    "mapping",

    "preview",

    "result",

  ];



const STEP_LABELS: Record<

  ExcelImportStep,

  string

> = {

  file: "File",

  sheet: "Sheet",

  mapping: "Match",

  preview: "Preview",

  result: "Done",

};



export default function ExcelImportSheet({

  open,

  onClose,

  title = "Import from Excel",

  subtitle =

    "Review the workbook before anything is added to Eleeveon.",

  step = "file",

  children,

  footer,

  busy = false,

  preventCloseWhileBusy = true,

  width = 760,

  className = "",

}: ExcelImportSheetProps) {

  useEffect(() => {

    if (!open) {

      return;

    }



    const previousBodyOverflow = document.body.style.overflow;
    const previousHtmlOverflow = document.documentElement.style.overflow;

    document.body.style.overflow = "hidden";
    document.documentElement.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = previousBodyOverflow;
      document.documentElement.style.overflow = previousHtmlOverflow;
    };

  }, [open]);



  useEffect(() => {

    if (!open) {

      return;

    }



    const onKeyDown = (

      event: KeyboardEvent,

    ) => {

      if (

        event.key !==

        "Escape"

      ) {

        return;

      }



      if (

        busy &&

        preventCloseWhileBusy

      ) {

        return;

      }



      onClose();

    };



    window.addEventListener(

      "keydown",

      onKeyDown,

    );



    return () => {

      window.removeEventListener(

        "keydown",

        onKeyDown,

      );

    };

  }, [

    busy,

    onClose,

    open,

    preventCloseWhileBusy,

  ]);



  if (!open || typeof document === "undefined") {
    return null;
  }



  const currentIndex =

    STEP_ORDER.indexOf(

      step,

    );



  const canClose =

    !busy ||

    !preventCloseWhileBusy;



  return createPortal(
    (

    <div
      style={{
        position: "fixed",
        inset: 0,
        width: "100vw",
        height: "100dvh",
        zIndex: 2147483000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        boxSizing: "border-box",
        padding: "max(12px, env(safe-area-inset-top, 0px)) 12px max(12px, env(safe-area-inset-bottom, 0px))",
        overflow: "hidden",
        background: "rgba(2, 6, 23, 0.76)",
        backdropFilter: "blur(5px)",
      }}

      className={[

        "excel-import-overlay",

        className,

      ]

        .filter(Boolean)

        .join(" ")}

      role="presentation"

      onMouseDown={(

        event,

      ) => {

        if (

          event.target !==

          event.currentTarget

        ) {

          return;

        }



        if (canClose) {

          onClose();

        }

      }}

    >

      <section

        className="excel-import-sheet"

        role="dialog"

        aria-modal="true"

        aria-label={title}

        style={{
          width: "min(100%, calc(100vw - 20px))",
          maxWidth: `${width}px`,
          height: "min(940px, calc(100dvh - 24px))",
          maxHeight: "100%",
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          margin: 0,
        }}

      >

        <header className="excel-import-header">

          <div className="excel-import-heading">

            <h2>

              {title}

            </h2>



            <p>

              {subtitle}

            </p>

          </div>



          <button

            type="button"

            className="excel-import-close"

            aria-label="Close"

            disabled={!canClose}

            onClick={

              onClose

            }

          >

            ×

          </button>

        </header>



        <div className="excel-import-progress">

          {STEP_ORDER.map(

            (

              item,

              index,

            ) => {

              const complete =

                index <

                currentIndex;



              const active =

                index ===

                currentIndex;



              return (

                <div

                  key={item}

                  className={[

                    "excel-import-progress-step",

                    complete

                      ? "complete"

                      : "",

                    active

                      ? "active"

                      : "",

                  ]

                    .filter(Boolean)

                    .join(" ")}

                >

                  <span>

                    {complete

                      ? "✓"

                      : index +

                        1}

                  </span>



                  <small>

                    {

                      STEP_LABELS[

                        item

                      ]

                    }

                  </small>

                </div>

              );

            },

          )}

        </div>



        <div className="excel-import-body">

          {children}

        </div>



        {footer && (

          <footer className="excel-import-footer">

            {footer}

          </footer>

        )}



        {busy && (

          <div

            className="excel-import-busy"

            aria-live="polite"

          >

            <span className="excel-import-spinner" />



            <span>

              Working…

            </span>

          </div>

        )}

      </section>



      <style jsx>{`
        .excel-import-overlay {
          --eds-bg: var(--bg, var(--background, #f7f8fb));
          --eds-surface: var(--surface, var(--card, var(--card-bg, #ffffff)));
          --eds-surface-soft: var(
            --surface-2,
            var(
              --muted-surface,
              color-mix(in srgb, var(--eds-surface) 92%, var(--eds-text) 8%)
            )
          );
          --eds-text: var(--text, var(--foreground, #172033));
          --eds-text-muted: var(
            --muted,
            var(
              --muted-foreground,
              color-mix(in srgb, var(--eds-text) 62%, transparent)
            )
          );
          --eds-border: var(
            --border,
            color-mix(in srgb, var(--eds-text) 14%, transparent)
          );
          --eds-accent: var(--primary-color, #2563eb);
          --eds-accent-soft: color-mix(
            in srgb,
            var(--eds-accent) 12%,
            var(--eds-surface)
          );
          color-scheme: normal;
          color: var(--eds-text);
          position: fixed;
          top: 0;
          right: 0;
          bottom: 0;
          left: 0;
          z-index: 120;

          display: flex;
          align-items: center;
          justify-content: center;
          box-sizing: border-box;
          padding: 12px;
          overflow: hidden;
          background:
            color-mix(
              in srgb,
              #020617 62%,
              transparent
            );
          -webkit-backdrop-filter: blur(10px) saturate(0.92);
          backdrop-filter: blur(10px) saturate(0.92);
        }

        .excel-import-overlay *,
        .excel-import-overlay *::before,
        .excel-import-overlay *::after {
          box-sizing: border-box;
        }

        .excel-import-overlay button,
        .excel-import-overlay input,
        .excel-import-overlay select,
        .excel-import-overlay textarea {
          font: inherit;
        }

        .excel-import-overlay input,
        .excel-import-overlay select,
        .excel-import-overlay textarea {
          background: var(--eds-surface);
          color: var(--eds-text);
          border-color: var(--eds-border);
        }

        .excel-import-overlay input::placeholder,
        .excel-import-overlay textarea::placeholder {
          color: var(--eds-text-muted);
          opacity: 1;
        }

        .excel-import-overlay select option {
          background: var(--eds-surface);
          color: var(--eds-text);
        }

        .excel-import-overlay strong,
        .excel-import-overlay h1,
        .excel-import-overlay h2,
        .excel-import-overlay h3 {
          color: var(--eds-text);
        }

        .excel-import-overlay small,
        .excel-import-overlay p,
        .excel-import-overlay label > span {
          color: var(--eds-text-muted);
        }

        .excel-import-overlay button:not(:disabled) {
          border-color: var(--eds-border);
        }

        .excel-import-overlay button.secondary,
        .excel-import-overlay button:not(.primary):not([class*="primary"]) {
          background: var(--eds-surface-soft);
          color: var(--eds-text);
        }

        .excel-import-overlay button.primary,
        .excel-import-overlay button[class*="primary"] {
          background: var(--eds-accent);
          color: #ffffff;
          border-color: var(--eds-accent);
        }

        .excel-import-sheet {
          position: relative;
          width: 100%;
          height: min(940px, calc(100dvh - 24px));
          max-height: 100%;
          min-height: 0;
          display: flex;
          flex-direction: column;
          overflow: hidden;
          border: 1px solid var(--eds-border, #e2e8f0);
          border-radius: 22px;
          background: var(--eds-bg, #f7f8fa);
          color: var(--eds-text, #172033);
          box-shadow: 0 26px 80px rgba(15, 23, 42, 0.24);
        }

        .excel-import-header {
          flex: 0 0 auto;
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 16px;
          padding: 18px 18px 12px;
          border-bottom: 1px solid var(--eds-border, #e2e8f0);
          background: var(--eds-surface, #ffffff);
        }

        .excel-import-heading {
          min-width: 0;
        }

        .excel-import-heading h2 {
          margin: 0;
          font-size: 18px;
          line-height: 1.2;
          color: var(--eds-text, #172033);
        }

        .excel-import-heading p {
          margin: 5px 0 0;
          max-width: 620px;
          font-size: 11px;
          line-height: 1.5;
          color: var(--eds-text-muted, #64748b);
        }

        .excel-import-close {
          flex: 0 0 auto;
          width: 36px;
          height: 36px;
          border: 1px solid var(--eds-border, #e2e8f0);
          border-radius: 50%;
          display: grid;
          place-items: center;
          background: var(--eds-surface-soft, #f1f5f9);
          color: var(--eds-text, #172033);
          cursor: pointer;
          font-size: 22px;
          line-height: 1;
        }

        .excel-import-close:disabled {
          opacity: 0.45;
          cursor: not-allowed;
        }

        .excel-import-progress {
          flex: 0 0 auto;
          display: grid;
          grid-template-columns: repeat(5, 1fr);
          gap: 4px;
          padding: 10px 18px 13px;
          border-bottom: 1px solid var(--eds-border, #e2e8f0);
          background: var(--eds-surface, #ffffff);
        }

        .excel-import-progress-step {
          min-width: 0;
          display: flex;
          align-items: center;
          gap: 5px;
          color: var(--eds-text-muted, #94a3b8);
        }

        .excel-import-progress-step span {
          flex: 0 0 auto;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          display: grid;
          place-items: center;
          background: var(--eds-surface-soft, #f1f5f9);
          font-size: 9px;
          font-weight: 800;
        }

        .excel-import-progress-step small {
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          font-size: 9px;
          font-weight: 700;
        }

        .excel-import-progress-step.active,
        .excel-import-progress-step.complete {
          color: var(--eds-accent, #315efb);
        }

        .excel-import-progress-step.active span,
        .excel-import-progress-step.complete span {
          background: var(--eds-accent-soft, #eaf0ff);
          color: var(--eds-accent, #315efb);
        }

        .excel-import-body {
          flex: 1 1 auto;
          min-height: 0;
          overflow-y: auto;
          overscroll-behavior: contain;
          -webkit-overflow-scrolling: touch;
          padding: 16px 18px 20px;
          background: var(--eds-bg, #f7f8fa);
          color: var(--eds-text, #172033);
        }

        .excel-import-footer {
          flex: 0 0 auto;
          padding: 12px 18px;
          border-top: 1px solid var(--eds-border, #e2e8f0);
          background: var(--eds-surface, #ffffff);
        }

        .excel-import-busy {
          position: absolute;
          inset: 0;
          z-index: 10;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          background: color-mix(
            in srgb,
            var(--eds-surface) 88%,
            transparent
          );
          backdrop-filter: blur(2px);
          color: var(--eds-text, #172033);
          font-size: 12px;
          font-weight: 700;
        }

        .excel-import-spinner {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          border: 2px solid var(--eds-border, #d7deea);
          border-top-color: var(--eds-accent, #315efb);
          animation: excel-spin 0.7s linear infinite;
        }

        @keyframes excel-spin {
          to {
            transform: rotate(360deg);
          }
        }

        @media (min-width: 980px) {
          .excel-import-overlay {
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            padding: 16px;
          }
        }

        @media (max-width: 520px) {
          .excel-import-overlay {
            padding: 10px;
          }

          .excel-import-sheet {
            max-width: calc(100vw - 20px) !important;
            max-height: 100%;
            border-radius: 20px;
          }

          .excel-import-header {
            padding: 14px 14px 10px;
          }

          .excel-import-progress {
            padding: 9px 14px 10px;
          }

          .excel-import-body {
            padding: 14px;
          }

          .excel-import-footer {
            padding: 10px 14px;
          }

          .excel-import-progress-step {
            justify-content: center;
          }

          .excel-import-progress-step small {
            display: none;
          }
        }

        
          .excel-import-close {
            width: 38px !important;
            height: 38px !important;
            border: 1px solid var(--eds-border, #cbd5e1) !important;
            border-radius: 999px !important;
            background: var(--eds-surface-soft, #f1f5f9) !important;
            color: var(--eds-text, #172033) !important;
            box-shadow: 0 4px 14px rgba(15, 23, 42, 0.08) !important;
            opacity: 1 !important;
            font-weight: 900 !important;
          }

          .excel-import-close:hover:not(:disabled) {
            background: var(--eds-accent-soft, #eaf0ff) !important;
            border-color: rgba(15, 23, 42, 0.24) !important;
          }

          .excel-import-close:disabled {
            opacity: 0.45 !important;
          }



          /* Mobile tap reliability */
          .excel-import-overlay {
            touch-action: manipulation;
          }

          .excel-import-sheet {
            pointer-events: auto;
          }

          .excel-import-close,
          .excel-import-footer button,
          .excel-import-body button,
          .excel-import-body input,
          .excel-import-body select,
          .excel-import-body textarea,
          .excel-import-body label {
            position: relative;
            z-index: 2;
            touch-action: manipulation;
            -webkit-tap-highlight-color: transparent;
            pointer-events: auto;
          }

          .excel-import-close {
            min-width: 44px;
            width: 44px !important;
            height: 44px !important;
          }

          .excel-import-footer {
            position: relative;
            z-index: 4;
            pointer-events: auto;
          }

          .excel-import-footer button {
            min-height: 46px;
            min-width: 92px;
          }

          .excel-import-body button {
            min-height: 44px;
          }

          .excel-import-body input,
          .excel-import-body select,
          .excel-import-body textarea {
            min-height: 44px;
          }

          @media (max-width: 520px) {
            .excel-import-footer {
              display: flex;
              gap: 8px;
              flex-wrap: wrap;
            }

            .excel-import-footer button {
              flex: 1 1 120px;
              min-height: 48px;
            }

            .excel-import-body button {
              min-height: 46px;
            }
          }

      
          /* Close control: fixed high-contrast pair in every theme. */
          .excel-import-close,
          .excel-import-close:hover:not(:disabled) {
            background: #1e293b !important;
            color: #ffffff !important;
            border: 1px solid #64748b !important;
            font-size: 24px !important;
            font-weight: 800 !important;
            opacity: 1 !important;
          }
          .excel-import-close:focus-visible {
            outline: 3px solid #60a5fa !important;
            outline-offset: 3px;
          }
          .excel-import-close:disabled { opacity: .48 !important; }
`}</style>

    <style>{`
/* Scoped, theme-aware action controls shared by every Excel importer. */
.excel-import-overlay .excel-import-footer {
  display: flex !important;
  align-items: center;
  justify-content: flex-end;
  gap: 10px !important;
  flex-wrap: wrap;
  min-width: 0;
}
.excel-import-overlay .excel-import-footer > :not(button) {
  display: flex !important;
  align-items: center;
  justify-content: flex-end;
  flex-wrap: wrap;
  gap: 10px !important;
  min-width: 0;
  width: 100%;
}
.excel-import-overlay .excel-import-footer button,
.excel-import-overlay .excel-import-body button,
.excel-import-overlay .excel-import-close {
  appearance: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  min-height: 42px;
  padding: 9px 14px;
  border: 1px solid var(--eds-border, #cbd5e1);
  border-radius: 9px;
  background: var(--eds-surface, #ffffff);
  color: var(--eds-text, #172033);
  font: inherit;
  font-weight: 700;
  line-height: 1.3;
  text-align: center;
  cursor: pointer;
  white-space: normal;
  overflow-wrap: anywhere;
  opacity: 1;
}
.excel-import-overlay .excel-import-footer button.primary,
.excel-import-overlay .excel-import-footer button[class*="primary"],
.excel-import-overlay .excel-import-footer button[class*="Primary"],
.excel-import-overlay .excel-import-footer button[class*="fh-primary"],
.excel-import-overlay .excel-import-body button.primary,
.excel-import-overlay .excel-import-body button[class*="fh-primary"] {
  background: var(--eds-accent, var(--primary-color, #2563eb)) !important;
  color: #ffffff !important;
  border-color: var(--eds-accent, var(--primary-color, #2563eb)) !important;
}
.excel-import-overlay .excel-import-footer button:not(.primary):not([class*="primary"]),
.excel-import-overlay .excel-import-footer button:not([class]) {
  background: var(--eds-surface-soft, #f1f5f9);
  color: var(--eds-text, #172033);
}
.excel-import-overlay button:disabled {
  opacity: .55;
  cursor: not-allowed;
}
.excel-import-overlay button:focus-visible,
.excel-import-overlay input:focus-visible,
.excel-import-overlay select:focus-visible,
.excel-import-overlay textarea:focus-visible {
  outline: 3px solid var(--eds-accent, #2563eb);
  outline-offset: 2px;
}
.excel-import-overlay .excel-file-selected-actions,
.excel-import-overlay .excel-error-filters,
.excel-import-overlay .excel-preview-head,
.excel-import-overlay .excel-mapping-row {
  column-gap: 9px;
}
.excel-import-overlay .excel-import-body select,
.excel-import-overlay .excel-import-body input:not([type="checkbox"]),
.excel-import-overlay .excel-import-body textarea {
  background-color: var(--eds-surface, #fff);
  color: var(--eds-text, #172033);
  border-color: var(--eds-border, #cbd5e1);
}
@media(max-width:520px) {
  .excel-import-overlay .excel-import-footer,
  .excel-import-overlay .excel-import-footer > :not(button) {
    gap: 9px !important;
  }
  .excel-import-overlay .excel-import-footer button {
    flex: 1 1 125px;
    min-width: 0;
    min-height: 46px;
  }
}
`}</style>
    </div>
    ),
    document.body,
  );
}
