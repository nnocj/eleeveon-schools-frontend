/**
 * app/lib/sync/syncEvents.ts
 * --------------------------------------------------------------------------
 * Sync/local-write helpers for selective revisions and cross-tab delivery.
 */

import {
  normalizeChangedTables,
  publishDataEvent,
} from "../events/dataEvents";

import {
  broadcastDataEvent,
  startCrossTabDataEvents,
} from "../events/crossTabEvents";

function publishAndBroadcast(input: {
  source:
    | "sync-pull-completed"
    | "sync-push-completed"
    | "local-write"
    | "manual";
  accountId?: string | null;
  changedTables?: readonly string[];
}) {
  const changedTables =
    normalizeChangedTables(input.changedTables);

  if (changedTables.length === 0) return null;

  startCrossTabDataEvents();

  const event = publishDataEvent({
    source: input.source,
    accountId: input.accountId,
    changedTables,
  });

  broadcastDataEvent(event);
  return event;
}

export function publishSyncPullCompleted(input: {
  accountId: string;
  changedTables?: readonly string[];
}) {
  return publishAndBroadcast({
    source: "sync-pull-completed",
    accountId: input.accountId,
    changedTables: input.changedTables,
  });
}

export function publishSyncPushCompleted(input: {
  accountId: string;
  changedTables?: readonly string[];
}) {
  return publishAndBroadcast({
    source: "sync-push-completed",
    accountId: input.accountId,
    changedTables: input.changedTables,
  });
}

export function publishLocalWrite(input: {
  accountId?: string | null;
  changedTables?: readonly string[];
}) {
  return publishAndBroadcast({
    source: "local-write",
    accountId: input.accountId,
    changedTables: input.changedTables,
  });
}

export function publishManualDataRefresh(input: {
  accountId?: string | null;
  changedTables?: readonly string[];
}) {
  return publishAndBroadcast({
    source: "manual",
    accountId: input.accountId,
    changedTables: input.changedTables,
  });
}