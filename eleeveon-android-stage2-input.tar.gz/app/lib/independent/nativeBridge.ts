/** Contract for an OS-protected, trusted native plugin. NOT PROVIDED by Capacitor out of the box.
 * Do not fake this API in window JavaScript or store the installation ID in localStorage.
 * The implementation must be an audited native plugin with app-specific key storage.
 */
import type { OfflineLicenseEnvelope } from './offlineLicense';
import { Capacitor, registerPlugin } from '@capacitor/core';
export interface IndependentNativeBridge {
  getInstallationId(): Promise<string>; // backed by OS secure storage
  loadOfflineLicense(): Promise<OfflineLicenseEnvelope | null>; // signed envelope, no issuer private key
  loadPinnedIssuerPublicKeys(): Promise<Record<string, string>>; // bundled trusted public key list
  getLicensedAccountId(): Promise<string>; // provisioned via owner-controlled installation process
  storeEncryptedDatabaseSnapshot?(input: {accountId:string;database:string;snapshot:string}): Promise<{saved:boolean;sha256:string;bytes:number;accountId:string;database:string}>;
  loadEncryptedDatabaseSnapshot?(options: {previous:boolean}): Promise<{accountId:string;database:string;sha256:string;bytes:number;previous:boolean;createdAt:string;indexedDBVersion:number;stores:number;records:number}>;
}
type NativeMethods = {
  getInstallationId(): Promise<{installationId:string}>;
  loadOfflineLicense(): Promise<{envelope:OfflineLicenseEnvelope|null}>;
  loadPinnedIssuerPublicKeys(): Promise<{keys:Record<string,string>}>;
  getLicensedAccountId(): Promise<{accountId:string}>;
  storeEncryptedDatabaseSnapshot(input:{accountId:string;database:string;snapshot:string}): Promise<{saved:boolean;sha256:string;bytes:number;accountId:string;database:string}>;
  loadEncryptedDatabaseSnapshot(input:{previous:boolean}): Promise<{snapshot:string;sha256:string;bytes:number;accountId:string;database:string;previous:boolean}>;
};
const native = registerPlugin<NativeMethods>('EleeveonIndependent');
const androidBridge: IndependentNativeBridge = {
  async getInstallationId() { return (await native.getInstallationId()).installationId; },
  async loadOfflineLicense() { return (await native.loadOfflineLicense()).envelope; },
  async loadPinnedIssuerPublicKeys() { return (await native.loadPinnedIssuerPublicKeys()).keys; },
  async getLicensedAccountId() { return (await native.getLicensedAccountId()).accountId; },
  storeEncryptedDatabaseSnapshot: (input) => native.storeEncryptedDatabaseSnapshot(input),
  // The existing desktop contract returns metadata only. Android needs a separate
  // restore adapter to consume the decrypted snapshot; don't pretend it is wired.
};
export function getIndependentNativeBridge(): IndependentNativeBridge | null {
  if (typeof window !== 'undefined' && Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android') return androidBridge;
  if (typeof window === 'undefined') return null;
  // This is an integration interface ONLY: real native side must be supplied and audited.
  const candidate = (window as Window & { EleeveonIndependentNative?: IndependentNativeBridge }).EleeveonIndependentNative;
  if (!candidate || typeof candidate.getInstallationId !== 'function' || typeof candidate.loadOfflineLicense !== 'function' || typeof candidate.loadPinnedIssuerPublicKeys !== 'function' || typeof candidate.getLicensedAccountId !== 'function') return null;
  return candidate;
}
