package com.eleeveon.schools;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.KeyStore;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.regex.Pattern;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Native storage foundation. Not a complete security audit or release approval. */
@CapacitorPlugin(name = "EleeveonIndependent")
public class EleeveonIndependentPlugin extends Plugin {
  private static final String KEY_ALIAS = "eleeveon-independent-snapshot-v1";
  private static final int MAX_BYTES = 50 * 1024 * 1024;
  private static final int APP_MAJOR_VERSION = 1; // Update with each incompatible major release.
  private static final long CLOCK_SKEW_SECONDS = 300;
  private static final Pattern SAFE_ID = Pattern.compile("[A-Za-z0-9_.:-]{1,160}");
  private static final String[] LIMIT_KEYS = {"schools", "branches", "users", "students", "teachers", "devices"};

  private boolean localOnly(PluginCall call) {
    // Capacitor invokes plugin methods on a worker thread. WebView.getUrl()
    // must be accessed on the Android main thread.
    try {
      final AtomicReference<String> currentUrl = new AtomicReference<>();
      final AtomicReference<Throwable> readFailure = new AtomicReference<>();
      final CountDownLatch done = new CountDownLatch(1);
      Runnable readUrl = () -> {
        try {
          currentUrl.set(getBridge().getWebView().getUrl());
        } catch (Throwable failure) {
          readFailure.set(failure);
        } finally {
          done.countDown();
        }
      };

      if (Looper.myLooper() == Looper.getMainLooper()) {
        readUrl.run();
      } else {
        if (!new Handler(Looper.getMainLooper()).post(readUrl)) {
          call.reject("Unable to schedule local origin verification");
          return false;
        }
        if (!done.await(3, TimeUnit.SECONDS)) {
          call.reject("Timed out checking local application origin");
          return false;
        }
      }

      if (readFailure.get() != null) {
        call.reject("Unable to read local application origin");
        return false;
      }

      String url = currentUrl.get();
      if (url == null) {
        call.reject("Independent native operations require a local page");
        return false;
      }
      java.net.URI origin = new java.net.URI(url);
      String scheme = origin.getScheme();
      String host = origin.getHost();
      int port = origin.getPort();
      boolean local = "localhost".equalsIgnoreCase(host)
          && (("https".equalsIgnoreCase(scheme) && (port == -1 || port == 443))
              || ("http".equalsIgnoreCase(scheme) && (port == -1 || port == 80)))
          && origin.getUserInfo() == null;
      if (!local) {
        call.reject("Independent native operations are unavailable to remote pages");
        return false;
      }
      return true;
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      call.reject("Local origin verification interrupted", e);
      return false;
    } catch (Exception e) {
      call.reject("Unable to verify local application origin", e);
      return false;
    }
  }
  private File secureDir() throws Exception {
    File dir = new File(getContext().getNoBackupFilesDir(), "eleeveon-independent");
    if (!dir.isDirectory() && !dir.mkdirs()) throw new Exception("Cannot create protected storage");
    return dir;
  }
  private byte[] read(File f) throws Exception { return Files.readAllBytes(f.toPath()); }
  private void atomicWrite(File dest, byte[] bytes) throws Exception {
    File temp = File.createTempFile("write-", ".tmp", secureDir());
    try {
      Files.write(temp.toPath(), bytes);
      try { Files.move(temp.toPath(), dest.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
      catch (java.nio.file.AtomicMoveNotSupportedException ex) { Files.move(temp.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING); }
    } finally { temp.delete(); }
  }
  private SecretKey key() throws Exception {
    KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
    if (store.containsAlias(KEY_ALIAS)) return ((KeyStore.SecretKeyEntry)store.getEntry(KEY_ALIAS, null)).getSecretKey();
    KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
    generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
      .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
      .setRandomizedEncryptionRequired(true).build());
    return generator.generateKey();
  }
  private String hash(byte[] bytes) throws Exception {
    byte[] digest = MessageDigest.getInstance("SHA-256").digest(bytes);
    StringBuilder s = new StringBuilder(); for(byte b:digest) s.append(String.format("%02x", b & 255)); return s.toString();
  }
  private String installationId() throws Exception {
    File f = new File(secureDir(),"installation.id");
    if (f.exists()) return new String(read(f),StandardCharsets.UTF_8);
    String id=UUID.randomUUID().toString();
    atomicWrite(f,id.getBytes(StandardCharsets.UTF_8)); return id;
  }
  private JSONObject pinnedKeys() throws Exception {
    try (java.io.InputStream in = getContext().getAssets().open("eleeveon-issuer-public-keys.json");
         java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
      byte[] buf = new byte[4096]; int n;
      while ((n = in.read(buf)) != -1) {
        if (out.size() + n > 32768) throw new Exception("Key asset too large");
        out.write(buf, 0, n);
      }
      return new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
    }
  }
  private byte[] b64url(String encoded) throws Exception {
    if (encoded == null || encoded.isEmpty() || !encoded.matches("[A-Za-z0-9_-]+"))
      throw new Exception("Invalid base64url");
    return Base64.decode(encoded, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
  }
  // WebCrypto ES256 signatures are IEEE P1363 (r || s), whereas Android's
  // SHA256withECDSA expects ASN.1 DER-encoded (r,s).
  private byte[] rawEs256ToDer(byte[] raw) throws Exception {
    if (raw.length != 64) throw new Exception("Invalid ES256 signature length");
    byte[] r = new java.math.BigInteger(1, Arrays.copyOfRange(raw, 0, 32)).toByteArray();
    byte[] t = new java.math.BigInteger(1, Arrays.copyOfRange(raw, 32, 64)).toByteArray();
    int length = 2 + r.length + 2 + t.length;
    if (length > 127) throw new Exception("Unexpected signature length");
    java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
    out.write(0x30); out.write(length);
    out.write(0x02); out.write(r.length); out.write(r);
    out.write(0x02); out.write(t.length); out.write(t);
    return out.toByteArray();
  }
  private JSONObject verifyLicense(JSONObject envelope) throws Exception {
    if (!"ES256".equals(envelope.getString("alg"))) throw new Exception("Unsupported signature algorithm");
    String kid = envelope.getString("kid");
    String payload = envelope.getString("payload");
    String signature = envelope.getString("signature");
    if (kid.isEmpty() || kid.length() > 120 || payload.length() > 20000 || signature.length() > 1024)
      throw new Exception("Invalid certificate size");
    JSONObject keys = pinnedKeys();
    String pem = keys.optString(kid, "");
    if (pem.isEmpty()) throw new Exception("Unknown issuer signing key");
    String body = pem.replace("-----BEGIN PUBLIC KEY-----", "")
      .replace("-----END PUBLIC KEY-----", "").replaceAll("\\s", "");
    byte[] der = Base64.decode(body, Base64.DEFAULT);
    PublicKey publicKey = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(der));
    Signature verifier = Signature.getInstance("SHA256withECDSA");
    verifier.initVerify(publicKey);
    verifier.update(payload.getBytes(StandardCharsets.UTF_8));
    if (!verifier.verify(rawEs256ToDer(b64url(signature)))) throw new Exception("License signature invalid");
    JSONObject claims = new JSONObject(payload);
    if (claims.getInt("v") != 1) throw new Exception("Unsupported license version");
    for (String field : new String[]{"licenseId", "accountId", "installationId"}) {
      String value = claims.getString(field);
      if (!SAFE_ID.matcher(value).matches()) throw new Exception("Invalid " + field);
    }
    if (!installationId().equals(claims.getString("installationId"))) throw new Exception("Wrong installation");
    String edition = claims.getString("edition");
    if (!"independent_essentials".equals(edition) && !"independent_multi_device".equals(edition))
      throw new Exception("Unsupported edition");
    long now = System.currentTimeMillis() / 1000;
    long issued = claims.getLong("issuedAt"), notBefore = claims.getLong("notBefore");
    if (issued < 0 || notBefore < 0 || issued > now + CLOCK_SKEW_SECONDS || notBefore > now + CLOCK_SKEW_SECONDS)
      throw new Exception("License not yet valid");
    if (!claims.isNull("expiresAt") && claims.getLong("expiresAt") <= now)
      throw new Exception("License expired");
    if (claims.getInt("entitledMajorVersion") < APP_MAJOR_VERSION)
      throw new Exception("App major version not entitled");
    JSONObject limits = claims.getJSONObject("limits");
    for (String field : LIMIT_KEYS) {
      if (!limits.has(field)) throw new Exception("Missing limit: " + field);
      if (!limits.isNull(field) && limits.getLong(field) < 0) throw new Exception("Invalid limit: " + field);
    }
    return claims;
  }
  private JSONObject verifiedInstalledLicense() throws Exception {
    File file = new File(secureDir(), "license.json");
    if (!file.exists()) throw new Exception("License not installed");
    return verifyLicense(new JSONObject(new String(read(file), StandardCharsets.UTF_8)));
  }
  @PluginMethod public void getInstallationId(PluginCall call) {
    if (!localOnly(call)) return;
    try { JSObject o = new JSObject(); o.put("installationId",installationId()); call.resolve(o); } catch(Exception e) { call.reject("Installation identity unavailable",e); }
  }
  @PluginMethod public void loadOfflineLicense(PluginCall call) {
    if (!localOnly(call)) return;
    try {
      File f = new File(secureDir(),"license.json"); JSObject o = new JSObject();
      o.put("envelope",f.exists() ? new JSONObject(new String(read(f),StandardCharsets.UTF_8)) : JSONObject.NULL);
      call.resolve(o);
    } catch(Exception e) { call.reject("License cannot be loaded",e); }
  }
  @PluginMethod public void getLicensedAccountId(PluginCall call) {
    if (!localOnly(call)) return;
    try {
      File f = new File(secureDir(),"license.json"); if (!f.exists()) { call.reject("License not installed"); return; }
      JSONObject claims = verifiedInstalledLicense();
      String accountId = claims.getString("accountId");
      if (!accountId.matches("[A-Za-z0-9_.:-]{1,160}")) throw new Exception("Invalid account ID");
      JSObject o = new JSObject(); o.put("accountId",accountId); call.resolve(o);
    } catch(Exception e) { call.reject("License account unavailable",e); }
  }
  @PluginMethod public void loadPinnedIssuerPublicKeys(PluginCall call) {
    if (!localOnly(call)) return;
    try {
      JSObject o = new JSObject(); o.put("keys",pinnedKeys());
 call.resolve(o);
    } catch(Exception e) { call.reject("Trusted public keys unavailable",e); }
  }
  /** Explicit import only. The calling UI must verify the signature before import;
   * all access gates verify it again on every startup. Never treat import as activation. */
  @PluginMethod public void importOfflineLicense(PluginCall call) {
    if (!localOnly(call)) return;
    try {
      JSObject envelope=call.getObject("envelope");
      if(envelope==null) throw new Exception("Missing certificate");
      verifyLicense(envelope);
      atomicWrite(new File(secureDir(),"license.json"),envelope.toString().getBytes(StandardCharsets.UTF_8));
      JSObject o=new JSObject(); o.put("stored",true); call.resolve(o);
    } catch(Exception e) { call.reject("License import rejected",e); }
  }
  @PluginMethod public void storeEncryptedDatabaseSnapshot(PluginCall call) {
    if (!localOnly(call)) return;
    try {
      String accountId=call.getString("accountId"), database=call.getString("database"), snapshot=call.getString("snapshot");
      if(accountId==null || !accountId.matches("[A-Za-z0-9_.:-]{1,160}") || database==null || !database.matches("[A-Za-z0-9_.:-]{1,160}") || snapshot==null) throw new Exception("Invalid snapshot request");
      JSONObject claims = verifiedInstalledLicense();
      if (!accountId.equals(claims.getString("accountId"))) throw new Exception("Account mismatch");
      byte[] plain=snapshot.getBytes(StandardCharsets.UTF_8);
      if(plain.length==0 || plain.length>MAX_BYTES) throw new Exception("Snapshot size unsupported");
      Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,key());
      byte[] iv=cipher.getIV(), encrypted=cipher.doFinal(plain);
      JSONObject wrapper=new JSONObject(); wrapper.put("v",1); wrapper.put("accountId",accountId); wrapper.put("database",database);
      wrapper.put("iv",Base64.encodeToString(iv,Base64.NO_WRAP)); wrapper.put("ciphertext",Base64.encodeToString(encrypted,Base64.NO_WRAP));
      File current=new File(secureDir(),"snapshot.json"), previous=new File(secureDir(),"snapshot.previous.json");
      if(current.exists()) Files.copy(current.toPath(),previous.toPath(),StandardCopyOption.REPLACE_EXISTING);
      atomicWrite(current,wrapper.toString().getBytes(StandardCharsets.UTF_8));
      JSObject result=new JSObject(); result.put("saved",true); result.put("sha256",hash(plain)); result.put("bytes",plain.length);
      result.put("accountId",accountId); result.put("database",database); call.resolve(result);
    } catch(Exception e) { call.reject("Encrypted snapshot save failed",e); }
  }
  @PluginMethod public void loadEncryptedDatabaseSnapshot(PluginCall call) {
    if (!localOnly(call)) return;
    try {
      JSONObject licenseClaims = verifiedInstalledLicense();
      boolean previous=Boolean.TRUE.equals(call.getBoolean("previous"));
      File f=new File(secureDir(),previous?"snapshot.previous.json":"snapshot.json");
      if(!f.exists()) { call.reject("Snapshot not found"); return; }
      JSONObject wrapper=new JSONObject(new String(read(f),StandardCharsets.UTF_8));
      if (!licenseClaims.getString("accountId").equals(wrapper.getString("accountId")))
        throw new Exception("Snapshot belongs to another account");
      Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(wrapper.getString("iv"),Base64.NO_WRAP)));
      byte[] plain=cipher.doFinal(Base64.decode(wrapper.getString("ciphertext"),Base64.NO_WRAP));
      if(plain.length>MAX_BYTES) throw new Exception("Snapshot too large");
      JSObject o=new JSObject(); o.put("snapshot",new String(plain,StandardCharsets.UTF_8));
      o.put("sha256",hash(plain)); o.put("bytes",plain.length); o.put("accountId",wrapper.getString("accountId"));
      o.put("database",wrapper.getString("database")); o.put("previous",previous); call.resolve(o);
    } catch(Exception e) { call.reject("Encrypted snapshot load failed",e); }
  }
}
